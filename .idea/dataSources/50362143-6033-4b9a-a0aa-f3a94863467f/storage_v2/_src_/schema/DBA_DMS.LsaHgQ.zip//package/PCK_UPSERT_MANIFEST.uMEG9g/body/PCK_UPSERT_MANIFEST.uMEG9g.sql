create PACKAGE BODY PCK_UPSERT_MANIFEST IS

  FUNCTION fn_insert_MANIFEST(p_MANIFEST_tbl PCK_UPSERT_MANIFEST.MANIFEST_tbl
       )
        RETURN NUMBER
    AS
        SQL_STMT  VARCHAR2(32767);
        sql_count NUMBER;
    BEGIN
        FORALL i IN p_MANIFEST_tbl.first .. p_MANIFEST_tbl.LAST
                INSERT INTO MANIFEST (
                FULL_CAMPAIGN
                ,SHIPPED_AT
                ,EXPECT_ARRIVAL_AT
                ,TRUCK_NUMBER
                ,TRUCK_DRIVER
                ,NOTES
                ,ORDER_COUNT
                ,BOX_COUNT
                ,SHIPPED_ORDER_COUNT
                ,BILLED_ORDER_COUNT
                ,COD_COUNT
                ,OTHER_COUNT
                ,DOCUMENT_COUNT
                ,TOTAL_BOX_COUNT )
            VALUES ( 
                p_MANIFEST_tbl(i).FULL_CAMPAIGN
                ,p_MANIFEST_tbl(i).SHIPPED_AT
                ,p_MANIFEST_tbl(i).EXPECT_ARRIVAL_AT
                ,p_MANIFEST_tbl(i).TRUCK_NUMBER
                ,p_MANIFEST_tbl(i).TRUCK_DRIVER
                ,p_MANIFEST_tbl(i).NOTES
                ,p_MANIFEST_tbl(i).ORDER_COUNT
                ,p_MANIFEST_tbl(i).BOX_COUNT
                ,p_MANIFEST_tbl(i).SHIPPED_ORDER_COUNT
                ,p_MANIFEST_tbl(i).BILLED_ORDER_COUNT
                ,p_MANIFEST_tbl(i).COD_COUNT
                ,p_MANIFEST_tbl(i).OTHER_COUNT
                ,p_MANIFEST_tbl(i).DOCUMENT_COUNT
                ,p_MANIFEST_tbl(i).TOTAL_BOX_COUNT );
               SQL_COUNT:=sql%rowcount;
      RETURN SQL_COUNT;
    end;




END PCK_UPSERT_MANIFEST;
/

