create PACKAGE BODY PCK_DBA_DDL_LOG IS
  /******************************************************************************
   NAME:       INSERT_DBA_DDL_LOG
   PURPOSE:    LOGS ORACLE DDL CHANGES TO A TABLE AND DOES NOT COMMIT

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        19/04/2021  JUAN C LOZANO     1. Created this Store Procedure.

******************************************************************************/

  PROCEDURE INSERT_DBA_DDL_LOG
    (
     I_OBJECT   IN VARCHAR2,
     I_AUTHOR   IN VARCHAR2,
     I_SQL_TEXT IN VARCHAR2,
     I_SQLCODE  IN VARCHAR2,
     I_SQLERRM  IN VARCHAR2
    ) IS
    V_APPLICATION_DATA   VARCHAR2(500);
  BEGIN
    SELECT 'SID:'||
      SYS_CONTEXT('USERENV', 'SID') ||',USERID:'||
      SYS_CONTEXT('USERENV', 'SESSION_USERID') ||',SESSIONID:'||
      SYS_CONTEXT('USERENV', 'SESSIONID') ||',HOST:'||
      SYS_CONTEXT('USERENV', 'SERVER_HOST')||',IP_ADDRESS:'||
      SYS_CONTEXT('USERENV', 'IP_ADDRESS')|| ',MODULE:'||
      SYS_CONTEXT('USERENV','MODULE') || ',OS_USER:' ||
      SYS_CONTEXT('USERENV','OS_USER') ||',CURRENT_SQL:'||
      SYS_CONTEXT('USERENV', 'CURRENT_SQL')
    INTO V_APPLICATION_DATA
    FROM
    dual;
    INSERT INTO DBA_DMS.DBA_DDL_LOG
      (
       ID_LOG
      ,OBJECT_NAME
      ,CREATED_BY
      ,SQL_TEXT
      ,SQLCODE_
      ,SQLERRM_
      ,APPLICATION_DATA
      )
    VALUES
      (
       DBA_DMS.DBA_DDL_LOG_SEQ.NEXTVAL
      ,SUBSTR (NVL(I_OBJECT, '-'), 0,80)
      ,SUBSTR (NVL(I_AUTHOR,'-'), 0,40)
      ,SUBSTR (NVL(I_SQL_TEXT,'-'), 0,500)
      ,SUBSTR (NVL(I_SQLCODE, '-'), 0,120)
      ,SUBSTR (NVL(I_SQLERRM, '-'), 0,120)
      ,SUBSTR (NVL( V_APPLICATION_DATA, '-'), 0,500)
      );
  END INSERT_DBA_DDL_LOG;
END PCK_DBA_DDL_LOG;
/

