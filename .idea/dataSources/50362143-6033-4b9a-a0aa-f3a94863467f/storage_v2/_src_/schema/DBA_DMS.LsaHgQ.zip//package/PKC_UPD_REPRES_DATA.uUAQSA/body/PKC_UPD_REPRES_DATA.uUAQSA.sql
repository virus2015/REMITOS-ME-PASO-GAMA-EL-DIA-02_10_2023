create PACKAGE BODY         PKC_UPD_REPRES_DATA
AS
    PROCEDURE SP_UPD_REPRES_DATA (P_DATE            IN     VARCHAR2, --- fechas, sepadas por comas DD/MM/YYYY
                                  P_ERROR_FLAG         OUT VARCHAR2, ---N sin error, S error
                                  P_ERROR_CODE         OUT VARCHAR2, --- SQLCODE
                                  P_ERROR_MESSAGE      OUT VARCHAR2, --- mensaje del error Oracle
                                  P_TOTAL_UPDATE       OUT NUMBER, --- total de datos a procesar
                                  P_REAL_UPDATE        OUT NUMBER) --- total de datos procesados
    AS
        V_DATE             VARCHAR2 (40) := P_DATE;
        V_TOTAL_UPDATE     NUMBER (6) := 0;      --- total de datos a procesar
        V_REAL_UPDATE      NUMBER (6) := 0;      --- total de datos procesados
        V_ACCOUNT_REP      NUMBER (12);
        V_ADDRESS_REP        VARCHAR2 (150);
        V_C_ADDRESS1         NUMBER (2);
        V_ADDRESS3_REP       VARCHAR2 (150);
        V_C_ADDRESS2         NUMBER (2);
        V_MUNICIPALITY       VARCHAR2 (150);
        V_C_ADDRESS3         NUMBER (2);
        V_STATE_NAME_REP   VARCHAR2 (50);
        V_C_STATE_NAME       NUMBER (2);
        V_TELEPHONE_REAL   VARCHAR2 (20);
        V_TELEPHONE_HED    VARCHAR2 (20);
        V_ZIP_REP          VARCHAR2 (20);
        V_C_ZIP              NUMBER (2);
        V_NAME_REP         VARCHAR2 (150);
        V_C_NAME             NUMBER (2);
        V_EMAIL_REP        VARCHAR2 (100);
        V_ORDER_ID         NUMBER (19);
        V_UPD_X_ORDER_ID     NUMBER (19);
        V_C_TELEPHONE_REAL   NUMBER (2) := 0;

        ---- REEMPLAZA LA CADENA DE FECHAS

        --- OBTIENE TODAS LAS ÓRDENES DE LAS FECHAS DEL PARÁMETRO
        CURSOR CUR_ORDERS_REPRES
        IS
             SELECT ACCOUNT_REP,
                   ADDRESS_REP,
                   C_ADDRESS1,
                   ADDRESS3_REP,
                   C_ADDRESS2,
                   MUNICIPALITY,
                   C_ADDRESS3,
                   STATE_NAME_REP,
                   C_STATE_NAME,
                   TELEPHONE_REAL,
                   TELEPHONE_HED,
                   DECODE (TELEPHONE_REAL, TELEPHONE_HED,0,
                    0,0, 1) as V_C_TELEPHONE_REAL,
                   ZIP_REP,
                   C_ZIP,
                   NAME_REP,
                   C_NAME,
                   EMAIL_REP,
                   ORDER_ID
              FROM (SELECT R.ACCOUNT
                               AS ACCOUNT_REP,
                           R.ADDRESS1 || ' ' || R.ADDRESS2
                               AS ADDRESS_REP,
                           H.ADDRESS1
                               AS ADDRESS1_HED,
                           DECODE (H.ADDRESS1,
                                   R.ADDRESS1 || ' ' || R.ADDRESS2, 0,
                                   1)
                               C_ADDRESS1,
                           R.ADDRESS2
                               AS ADDRESS2_REP,
                           H.ADDRESS2
                               AS ADDRESS2_HED,
                           R.ADDRESS3
                               AS ADDRESS3_REP,
                           DECODE (H.ADDRESS2,  R.ADDRESS3, 0,  NULL, 0,  1)
                               C_ADDRESS2,
                           H.ADDRESS3
                               AS ADDRESS3_HED,
                           R.MUNICIPALITY,
                           DECODE (H.ADDRESS3,
                                   R.MUNICIPALITY, 0,
                                   NULL, 0,
                                   1)
                               C_ADDRESS3,
                           R.STATE_NAME
                               AS STATE_NAME_REP,
                           H.STATE_NAME
                               AS STATE_NAME_HED,
                           DECODE (H.STATE_NAME, H.STATE_NAME, 0, 1)
                               C_STATE_NAME,
                           DECODE (TO_NUMBER (R.CELLPHONE),
                                   0, TO_NUMBER (R.TELEPHONE),
                                   NULL, TO_NUMBER (R.TELEPHONE),
                                   TO_NUMBER (R.CELLPHONE))
                               TELEPHONE_REAL,
                           NVL (TO_NUMBER (R.CELLPHONE), 0)
                               AS CELLPHONE_REP,
                           NVL (TO_NUMBER (R.TELEPHONE), 0)
                               AS TELEPHONE_REP,
                           NVL (TO_NUMBER (H.TELEPHONE), 0)
                               AS TELEPHONE_HED,
                           TO_NUMBER (R.ZIP)
                               AS ZIP_REP,
                           H.ZIP
                               AS ZIP_HED,
                           DECODE (H.ZIP, TO_NUMBER (R.ZIP), 0, 1)
                               C_ZIP,
                           R.ACCOUNT_NAME
                               AS NAME_REP,
                           H.ACC_NAME
                               AS NAME_HED,
                           DECODE (H.ACC_NAME, R.ACCOUNT_NAME, 0, 1)
                               C_NAME,
                           R.EMAIL
                               AS EMAIL_REP,
                           H.ORDER_ID
                      FROM SCPI_ORDER_HEADERS  H
                           INNER JOIN ORDERS O ON O.ORDER_ID = H.ORDER_ID
                           INNER JOIN REPRESENTATIVES R
                               ON H.ACCOUNT = R.ACCOUNT
                     WHERE H.ORDER_ID IN
                               (SELECT ORDER_ID
                                  FROM ORDERS
                                 WHERE TO_CHAR (CREATED_AT, 'DD/MM/YYYY') IN
                                           (    SELECT TRIM (
                                                           REGEXP_SUBSTR (
                                                               str,
                                                               '[^,]+',
                                                               1,
                                                               LEVEL))
                                                           str
                                                  FROM (SELECT P_DATE str
                                                          FROM DUAL) t
                                            CONNECT BY INSTR (str,
                                                              ',',
                                                              1,
                                                              LEVEL - 1) > 0)))
             WHERE (   C_ADDRESS1 > 0
                    OR C_ADDRESS2 > 0
                    OR C_ADDRESS3 > 0
                    OR C_STATE_NAME > 0
                    OR C_ZIP > 0
                    OR C_NAME > 0
                    OR TELEPHONE_REAL <> TELEPHONE_HED);
        BEGIN

        P_ERROR_FLAG := 'N';


        OPEN CUR_ORDERS_REPRES;

        LOOP
            FETCH CUR_ORDERS_REPRES
                INTO V_ACCOUNT_REP,
                     V_ADDRESS_REP,
                     V_C_ADDRESS1,
                     V_ADDRESS3_REP,
                     V_C_ADDRESS2,
                     V_MUNICIPALITY,
                     V_C_ADDRESS3,
                     V_STATE_NAME_REP,
                     V_C_STATE_NAME ,
                     V_TELEPHONE_REAL,
                     V_TELEPHONE_HED,
                     V_C_TELEPHONE_REAL,
                     V_ZIP_REP,
                     V_C_ZIP,
                     V_NAME_REP,
                     V_C_NAME ,
                     V_EMAIL_REP,
                     V_ORDER_ID;


             ---- VALIDA QUE NO ACTUALICE EL TELÉFONO A CERO SI YA TIENE UN NÚMERO DE TELÉFONO
         --    IF V_TELEPHONE_REAL = 0 AND V_TELEPHONE_HED > 0
          --    THEN
          --        V_TELEPHONE_REAL := V_TELEPHONE_HED;
           --   END IF;
            
            ---- VALIDA QUE NO ACTUALICE EL TELÉFONO A CERO SI YA TIENE UN NÚMERO DE TELÉFONO
         /* IF V_TELEPHONE_REAL != '0'
            THEN
               V_C_TELEPHONE_REAL := 0;
           END IF;*/
             --- VALIDA LOS REGISTROS A ACTUALIZAR POR ORDEN , SI NO HAY REGISTROS NO ENVÍA A SIMPLY
            V_UPD_X_ORDER_ID :=
                  V_C_ADDRESS1
                + V_C_ADDRESS2
                + V_C_ADDRESS3
                + V_C_STATE_NAME
                + V_C_ZIP
                + V_C_TELEPHONE_REAL
                + V_C_NAME;

            IF V_UPD_X_ORDER_ID > 0
            THEN
            --- ACUMULA LOS REGISTROS
                V_REAL_UPDATE := V_REAL_UPDATE + 1;
                -- ACTUALIZA EL REGISTRO EN LAS DOS TABLAS
                UPDATE SCPI_ORDER_HEADERS
                   SET ADDRESS1 = V_ADDRESS_REP,
                       ADDRESS2 = V_ADDRESS3_REP,
                       ADDRESS3 = V_MUNICIPALITY,
                       STATE_NAME = V_STATE_NAME_REP,
                       ZIP = V_ZIP_REP,
                       TELEPHONE = DECODE (V_TELEPHONE_REAL , '0', TELEPHONE, V_TELEPHONE_REAL),
                       ACC_NAME = V_NAME_REP,
                       EMAIL = V_EMAIL_REP
                 WHERE ORDER_ID = V_ORDER_ID;

                UPDATE ORDERS
                   SET TRANSFER_FLAG = 'E'
                 WHERE ORDER_ID = V_ORDER_ID;

                
                ELSE 
                V_REAL_UPDATE := V_REAL_UPDATE ;
            END IF;
            
            COMMIT;
            
            EXIT WHEN CUR_ORDERS_REPRES%NOTFOUND;
        END LOOP;
        V_TOTAL_UPDATE := CUR_ORDERS_REPRES%ROWCOUNT;
        CLOSE CUR_ORDERS_REPRES;
       -- IMPRIME TOTAL DE REGISTROS PROCESADOS
        P_TOTAL_UPDATE := V_TOTAL_UPDATE;

        --- IMRIME TOTAL DE REEGISTROS ENVIADOS A SIMPLI
        P_REAL_UPDATE := V_REAL_UPDATE ;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            ROLLBACK;
            P_TOTAL_UPDATE := V_TOTAL_UPDATE;
            P_REAL_UPDATE := V_REAL_UPDATE;
            P_ERROR_CODE := SQLCODE;
            P_ERROR_MESSAGE :=
                CONCAT (CONCAT (SQLERRM, '  '),
                        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
            P_ERROR_FLAG := 'S';
        WHEN OTHERS
        THEN
            ROLLBACK;
            P_TOTAL_UPDATE := V_TOTAL_UPDATE;
            P_REAL_UPDATE := V_REAL_UPDATE;
            P_ERROR_CODE := SQLCODE;
            P_ERROR_MESSAGE :=
                CONCAT (CONCAT (SQLERRM, '  '),
                        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
            P_ERROR_FLAG := 'S';
    END SP_UPD_REPRES_DATA;
END PKC_UPD_REPRES_DATA;
/

