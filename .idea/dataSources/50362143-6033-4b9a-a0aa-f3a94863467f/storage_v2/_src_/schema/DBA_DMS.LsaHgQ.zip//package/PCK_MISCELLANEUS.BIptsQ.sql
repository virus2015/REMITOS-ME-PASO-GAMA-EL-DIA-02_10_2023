create PACKAGE         PCK_MISCELLANEUS AS
/******************************************************************************
   NAME:       PCK_COD_MESSAGES
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        28/02/2022      reyesros       1. Created this package.
******************************************************************************/


  FUNCTION FN_EDITION_DEADLINE  (P_FULL_CAMPAIGN  NUMBER,
                                 P_ZONE NUMBER,
                                 P_HOUR  VARCHAR2)
                                 RETURN VARCHAR2;
  FUNCTION FN_EDITION_DEADLINE_T  (P_FULL_CAMPAIGN  NUMBER,
                                 P_ZONE NUMBER,
                                 P_HOUR  VARCHAR2)
                                 RETURN TIMESTAMP;
 PROCEDURE SP_MISCELANEUSGZ_DL ( P_ROWS              OUT VARCHAR2,--- REGISTROS PROCESADOS
                                P_ERROR_CODE         OUT VARCHAR2,--- NUM DE ERROR
                                P_ERROR_MESSAGE      OUT VARCHAR2);--- ERROR ORACLE
 PROCEDURE SP_COD_MESSAGES_DL ( P_ROWS              OUT VARCHAR2,--- REGISTROS PROCESADOS
                                P_ERROR_CODE         OUT VARCHAR2,--- NUM DE ERROR
                                P_ERROR_MESSAGE      OUT VARCHAR2);--- ERROR ORACLE

END PCK_MISCELLANEUS;
/

