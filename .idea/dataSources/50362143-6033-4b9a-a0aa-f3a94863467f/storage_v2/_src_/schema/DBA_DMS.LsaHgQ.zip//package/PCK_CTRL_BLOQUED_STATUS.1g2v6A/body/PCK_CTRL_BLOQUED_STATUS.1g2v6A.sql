create PACKAGE BODY         PCK_CTRL_BLOQUED_STATUS
AS
    PROCEDURE SP_CTRL_BLOQUED_STATUS_0 (P_BLOCKED_STATUS_0   OUT NUMBER,
                                        P_ERROR_FLAG         OUT VARCHAR2, --- S = error, N = éxito
                                        P_ERROR_CODE         OUT VARCHAR2, --- Código SQL
                                        P_ERROR_MESSAGE      OUT VARCHAR2) --- mensaje de salida)
    AS
        V_COUNT_BLOCKED_STATUS_0   NUMBER (10) := 0;
        V_CAMPAIGN                 NUMBER (6);
    BEGIN
        P_ERROR_FLAG := 'N';
        P_ERROR_CODE := '-';
        P_ERROR_MESSAGE := '-';

       select fn_get_previous_campaign(2) INTO V_CAMPAIGN from dual;

        ----------------- DELIVERY1ST IN ('04', '06', '07', '08','09', '10', '11', '12','13',  '15', '16','17' )  THEN BLOCKED_STATUS = 0 ROUND_NUM = 1 THEN BLOCKED_STATUS = 0

        SELECT COUNT (*)
          INTO V_COUNT_BLOCKED_STATUS_0
          FROM DBA_DMS.ORDERS O
         WHERE     (   ROUND_NUM = 1
                    OR DELIVERY1ST IN ('04',
                                       '06',
                                       '07',
                                       '08',
                                       '09',
                                       '10',
                                       '11',
                                       '12',
                                       '13',                         --- '14',
                                       '15',
                                       '16',
                                       '17'))
               AND ORDER_ID IN
                       (SELECT ORDER_ID
                          FROM DBA_DMS.SCPI_ORDER_HEADERS  H
                               INNER JOIN
                               (SELECT Z.ZONE,
                                       Z.CAMPAIGN_YEAR|| LPAD(Z.CAMPAIGN,2,0)
                                           AS FULL_CAMPAIGN,
                                       Z.ON_PORTEO_UNTIL
                                  FROM ZONE_CAMPAIGNS Z
                                 WHERE TRUNC (ON_PORTEO_UNTIL) <=
                                       TRUNC (SYSDATE - 1)) ZC
                                   ON     ZC.FULL_CAMPAIGN =
                                          h.full_campaign
                                      AND h.zone = ZC.ZONE
                         WHERE     h.full_campaign >= V_CAMPAIGN --- MAYORES A TRES CAMPAÑAS
                               AND ORDER_ID NOT IN
                                       (SELECT ORDER_ID
                                          FROM DBA_DMS.CONTROL_BLOCKED_STATUS
                                         WHERE PROCESSED = 'Y'));

        IF V_COUNT_BLOCKED_STATUS_0 > 0
        THEN
            ----------- INICIA PROCESO, INSERTA EN CONTROL
            INSERT INTO DBA_DMS.CONTROL_BLOCKED_STATUS (ORDER_ID, BLOCKED_STATUS_FIRST)
                SELECT O.ORDER_ID,
                       O.BLOCKED_STATUS AS BLOCKED_STATUS_FIRST
                  FROM DBA_DMS.ORDERS O
                 WHERE     (   ROUND_NUM = 1
                            OR DELIVERY1ST IN ('04',
                                               '06',
                                               '07',
                                               '08',
                                               '09',
                                               '10',
                                               '11',
                                               '12',
                                               '13',                 --- '14',
                                               '15',
                                               '16',
                                               '17'))
                       AND ORDER_ID IN
                               (SELECT ORDER_ID
                                  FROM DBA_DMS.SCPI_ORDER_HEADERS  H
                                       INNER JOIN
                                       (SELECT Z.ZONE,
                                                  Z.CAMPAIGN_YEAR
                                              || LPAD(Z.CAMPAIGN,2,0)
                                                   AS FULL_CAMPAIGN,
                                               Z.ON_PORTEO_UNTIL
                                          FROM ZONE_CAMPAIGNS Z
                                         WHERE TRUNC (
                                                   ON_PORTEO_UNTIL) <=
                                               TRUNC (SYSDATE - 1))
                                       ZC
                                           ON     ZC.FULL_CAMPAIGN =
                                                  h.full_campaign
                                              AND h.zone = ZC.ZONE
                                 WHERE     h.full_campaign >= V_CAMPAIGN --- MAYORES A TRES CAMPAÑAS
                                       AND ORDER_ID NOT IN
                                               (SELECT ORDER_ID
                                                  FROM DBA_DMS.CONTROL_BLOCKED_STATUS
                                                 WHERE PROCESSED = 'Y'));

            COMMIT;

            ------------------ACTUALIZA ORDENES
            UPDATE DBA_DMS.ORDERS
               SET BLOCKED_STATUS = 0
             WHERE ORDER_ID IN
                       (SELECT O.ORDER_ID
                          FROM DBA_DMS.ORDERS O
                         WHERE     (   ROUND_NUM = 1
                                    OR (    DELIVERY1ST IN ('04',
                                                            '06',
                                                            '07',
                                                            '08',
                                                            '09',
                                                            '10',
                                                            '11',
                                                            '12',
                                                            '13',    --- '14',
                                                            '15',
                                                            '16',
                                                            '17')
                                        AND BLOCKED_STATUS != -99))
                               AND ORDER_ID IN
                                       (SELECT ORDER_ID
                                          FROM DBA_DMS.SCPI_ORDER_HEADERS  H
                                               INNER JOIN
                                               (SELECT Z.ZONE,
                                                          Z.CAMPAIGN_YEAR
                                                      || LPAD(Z.CAMPAIGN,2,0)
                                                           AS FULL_CAMPAIGN,
                                                       Z.ON_PORTEO_UNTIL
                                                  FROM ZONE_CAMPAIGNS Z
                                                 WHERE TRUNC (
                                                           ON_PORTEO_UNTIL) <=
                                                       TRUNC (SYSDATE - 1))
                                               ZC
                                                   ON     ZC.FULL_CAMPAIGN =
                                                          h.full_campaign
                                                      AND h.zone = ZC.ZONE
                                         WHERE     h.full_campaign >=
                                                   V_CAMPAIGN --- MAYORES A TRES CAMPAÑAS
                                               AND ORDER_ID NOT IN
                                                       (SELECT ORDER_ID
                                                          FROM DBA_DMS.CONTROL_BLOCKED_STATUS
                                                         WHERE PROCESSED =
                                                               'Y')));

            COMMIT;

            ---ACTUALIZA TABLA DE CONTROL
            UPDATE DBA_DMS.CONTROL_BLOCKED_STATUS C
               SET UPDATE_AT =
                       CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City',
                   PROCESSED = 'Y',
               C.BLOCKED_STATUS_NEW =
                       (SELECT O.BLOCKED_STATUS
                          FROM DBA_DMS.ORDERS O
                         WHERE     (   O.ROUND_NUM = 1
                                    OR O.DELIVERY1ST IN ('04',
                                                         '06',
                                                         '07',
                                                         '08',
                                                         '09',
                                                         '10',
                                                         '11',
                                                         '12',
                                                         '13',       --- '14',
                                                         '15',
                                                         '16',
                                                         '17'))
                               AND O.ORDER_ID IN
                                       (SELECT ORDER_ID
                                          FROM DBA_DMS.SCPI_ORDER_HEADERS  H
                                               INNER JOIN
                                               (SELECT Z.ZONE,
                                                          Z.CAMPAIGN_YEAR
                                                      || LPAD(Z.CAMPAIGN,2,0)
                                                           AS FULL_CAMPAIGN,
                                                       Z.ON_PORTEO_UNTIL
                                                  FROM ZONE_CAMPAIGNS Z
                                                 WHERE TRUNC (
                                                           ON_PORTEO_UNTIL) <=
                                                       TRUNC (SYSDATE - 1))
                                               ZC
                                                   ON     ZC.FULL_CAMPAIGN =
                                                          h.full_campaign
                                                      AND h.zone = ZC.ZONE
                                         WHERE     h.full_campaign >=
                                                   V_CAMPAIGN --- MAYORES A TRES CAMPAÑAS
                                               AND ORDER_ID NOT IN
                                                       (SELECT ORDER_ID
                                                          FROM DBA_DMS.CONTROL_BLOCKED_STATUS
                                                         WHERE PROCESSED =
                                                               'Y'))
                               AND C.ORDER_ID = O.ORDER_ID)
                                WHERE PROCESSED = 'N'
                               AND UPDATE_AT IS NULL;



            COMMIT;


            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_CTRL_BLOQUED_STATUS.SP_CTRL_BLOQUED_STATUS',
                'ORDENES ACTUALIZADAS A CERO ' || V_COUNT_BLOCKED_STATUS_0,
                SQLCODE,
                SQLERRM);
        END IF;
         P_BLOCKED_STATUS_0 := V_COUNT_BLOCKED_STATUS_0;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            P_ERROR_FLAG := 'N';
            ROLLBACK;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_CTRL_BLOQUED_STATUS.SP_CTRL_BLOQUED_STATUS',
                'NO HAY DATOS ',
                SQLCODE,
                SQLERRM);
        WHEN OTHERS
        THEN
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_CTRL_BLOQUED_STATUS.SP_CTRL_BLOQUED_STATUS',
                'ERROR AL ACTUALIZAR BLOQUED_STATUS, NO SE EJECUTÓ EL PROCESO ',
                SQLCODE,
                SQLERRM);
            P_ERROR_CODE := SQLCODE;
            P_ERROR_FLAG := 'S';
            P_ERROR_MESSAGE :=
                CONCAT (CONCAT (SQLERRM, '  '),
                        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
            ROLLBACK;
    END SP_CTRL_BLOQUED_STATUS_0;

    PROCEDURE SP_CTRL_BLOQUED_STATUS_INC (
        P_BLOCKED_STATUS_INC   OUT NUMBER,
        P_ERROR_FLAG           OUT VARCHAR2,          --- S = error, N = éxito
        P_ERROR_CODE           OUT VARCHAR2,                    --- Código SQL
        P_ERROR_MESSAGE        OUT VARCHAR2)
    IS
        V_COUNT_BLOCKED_STATUS_INC   NUMBER (19) := 0;
        V_CAMPAIGN                   NUMBER (6);
    BEGIN
        P_ERROR_FLAG := 'N';
        P_ERROR_CODE := '-';
        P_ERROR_MESSAGE := '-';

        select fn_get_previous_campaign(2) INTO V_CAMPAIGN from dual;

        ---- DELIVERY1ST IN ('01', '02', '03', '05' ) THEN BLOCKED_STATUS = BLOCKED_STATUS + 1
        P_ERROR_FLAG := 'N';

        SELECT COUNT (*)
          INTO V_COUNT_BLOCKED_STATUS_INC
          FROM DBA_DMS.ORDERS O
         WHERE     (O.ROUND_NUM = 2 OR O.ROUND_NUM IS NULL)
               AND O.BLOCKED_STATUS NOT IN (-99, 3)
               AND O.DELIVERY1ST IN ('01',
                                     '02',
                                     '03',
                                     '05') ---THEN BLOCKED_STATUS = BLOCKED_STATUS + 1
               AND O.ORDER_ID IN
                       (SELECT ORDER_ID --, ORDER_NUMBER, H.FULL_CAMPAIGN FULL_CAMPAIGN_H, H.ZONE ZONE_H, ZC.ZONE ZONE_ZC, ZC.FULL_CAMPAIGN FULL_CAMPAIGN_ZC --  ORDER_ID
                          FROM DBA_DMS.SCPI_ORDER_HEADERS  H
                               INNER JOIN
                               (SELECT Z.ZONE,
                                          Z.CAMPAIGN_YEAR
                                      || LPAD(Z.CAMPAIGN,2,0)
                                           AS FULL_CAMPAIGN,
                                       Z.ON_PORTEO_UNTIL
                                  FROM ZONE_CAMPAIGNS Z
                                 WHERE TRUNC (ON_PORTEO_UNTIL) <=
                                       TRUNC (SYSDATE - 1)) ZC
                                   ON     ZC.FULL_CAMPAIGN =
                                          h.full_campaign
                                      AND h.zone = ZC.ZONE
                         WHERE     zc.full_campaign > V_CAMPAIGN --- MAYORES A DOS CAMPAÑAS
                               AND ORDER_ID NOT IN
                                       (SELECT ORDER_ID
                                          FROM DBA_DMS.CONTROL_BLOCKED_STATUS
                                         WHERE PROCESSED = 'Y'));

 IF V_COUNT_BLOCKED_STATUS_INC >0 THEN
 -----INSERTA EN CONTROL

         INSERT INTO DBA_DMS.CONTROL_BLOCKED_STATUS (ORDER_ID, BLOCKED_STATUS_FIRST)
            SELECT O.ORDER_ID,
                    O.BLOCKED_STATUS AS BLOCKED_STATUS_FIRST
              FROM DBA_DMS.ORDERS O
             WHERE     (O.ROUND_NUM = 2 OR O.ROUND_NUM IS NULL)
                   AND O.BLOCKED_STATUS NOT IN (-99, 3)
                   AND O.DELIVERY1ST IN ('01',
                                         '02',
                                         '03',
                                         '05') ---THEN BLOCKED_STATUS = BLOCKED_STATUS + 1
                   AND O.ORDER_ID IN
                           (SELECT ORDER_ID --, ORDER_NUMBER, H.FULL_CAMPAIGN FULL_CAMPAIGN_H, H.ZONE ZONE_H, ZC.ZONE ZONE_ZC, ZC.FULL_CAMPAIGN FULL_CAMPAIGN_ZC --  ORDER_ID
                              FROM DBA_DMS.SCPI_ORDER_HEADERS  H
                                   INNER JOIN
                                   (SELECT Z.ZONE,
                                              Z.CAMPAIGN_YEAR
                                          || LPAD(Z.CAMPAIGN,2,0)
                                               AS FULL_CAMPAIGN,
                                           Z.ON_PORTEO_UNTIL
                                      FROM ZONE_CAMPAIGNS Z
                                     WHERE TRUNC (ON_PORTEO_UNTIL) <=
                                           TRUNC (SYSDATE - 1)) ZC
                                       ON     ZC.FULL_CAMPAIGN =
                                              h.full_campaign
                                          AND h.zone = ZC.ZONE
                             WHERE     zc.full_campaign > V_CAMPAIGN
                                   AND ORDER_ID NOT IN
                                           (SELECT ORDER_ID
                                              FROM DBA_DMS.CONTROL_BLOCKED_STATUS
                                             WHERE PROCESSED = 'Y'));

        COMMIT;
     ----- ACTUALIZA ORDENES   
        UPDATE DBA_DMS.ORDERS
           SET BLOCKED_STATUS = (BLOCKED_STATUS + 1)
         WHERE ORDER_ID IN
                   (SELECT O.ORDER_ID
                      FROM DBA_DMS.ORDERS O
                     WHERE     (O.ROUND_NUM = 2 OR O.ROUND_NUM IS NULL)
                           AND O.BLOCKED_STATUS NOT IN (-99, 3)
                           AND O.DELIVERY1ST IN ('01',
                                                 '02',
                                                 '03',
                                                 '05') ---THEN BLOCKED_STATUS = BLOCKED_STATUS + 1
                           AND O.ORDER_ID IN
                                   (SELECT ORDER_ID --, ORDER_NUMBER, H.FULL_CAMPAIGN FULL_CAMPAIGN_H, H.ZONE ZONE_H, ZC.ZONE ZONE_ZC, ZC.FULL_CAMPAIGN FULL_CAMPAIGN_ZC --  ORDER_ID
                                      FROM DBA_DMS.SCPI_ORDER_HEADERS  H
                                           INNER JOIN
                                           (SELECT Z.ZONE,
                                                      Z.CAMPAIGN_YEAR
                                                  || LPAD(Z.CAMPAIGN,2,0)
                                                       AS FULL_CAMPAIGN,
                                                   Z.ON_PORTEO_UNTIL
                                              FROM ZONE_CAMPAIGNS Z
                                             WHERE TRUNC (ON_PORTEO_UNTIL) <=
                                                   TRUNC (SYSDATE - 1)) ZC
                                               ON     ZC.FULL_CAMPAIGN =
                                                      h.full_campaign
                                                  AND h.zone = ZC.ZONE
                                     WHERE     zc.full_campaign > V_CAMPAIGN --- MAYORES A DOS CAMPAÑAS
                                           AND ORDER_ID NOT IN
                                                   (SELECT ORDER_ID
                                                      FROM DBA_DMS.CONTROL_BLOCKED_STATUS
                                                     WHERE PROCESSED = 'Y')));

        COMMIT;

            ---ACTUALIZA TABLA DE CONTROL
            UPDATE DBA_DMS.CONTROL_BLOCKED_STATUS C
               SET UPDATE_AT =
                       CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City',
                   PROCESSED = 'Y',
               C.BLOCKED_STATUS_NEW =
                       (SELECT O.BLOCKED_STATUS
              FROM DBA_DMS.ORDERS O
             WHERE     (O.ROUND_NUM = 2 OR O.ROUND_NUM IS NULL)
                   AND O.BLOCKED_STATUS NOT IN (-99)---se saca el 3 por el incremento
                   AND O.DELIVERY1ST IN ('01',
                                         '02',
                                         '03',
                                         '05') ---THEN BLOCKED_STATUS = BLOCKED_STATUS + 1
                   AND O.ORDER_ID IN
                           (SELECT ORDER_ID --, ORDER_NUMBER, H.FULL_CAMPAIGN FULL_CAMPAIGN_H, H.ZONE ZONE_H, ZC.ZONE ZONE_ZC, ZC.FULL_CAMPAIGN FULL_CAMPAIGN_ZC --  ORDER_ID
                              FROM DBA_DMS.SCPI_ORDER_HEADERS  H
                                   INNER JOIN
                                   (SELECT Z.ZONE,
                                              Z.CAMPAIGN_YEAR
                                          || LPAD(Z.CAMPAIGN,2,0)
                                               AS FULL_CAMPAIGN,
                                           Z.ON_PORTEO_UNTIL
                                      FROM ZONE_CAMPAIGNS Z
                                     WHERE TRUNC (ON_PORTEO_UNTIL) <=
                                           TRUNC (SYSDATE - 1)) ZC
                                       ON     ZC.FULL_CAMPAIGN =
                                              h.full_campaign
                                          AND h.zone = ZC.ZONE
                             WHERE     zc.full_campaign > V_CAMPAIGN
                                   AND ORDER_ID NOT IN
                                           (SELECT ORDER_ID
                                              FROM DBA_DMS.CONTROL_BLOCKED_STATUS
                                             WHERE PROCESSED = 'Y'))
                               AND C.ORDER_ID = O.ORDER_ID)
                               WHERE PROCESSED = 'N'
                               AND UPDATE_AT IS NULL;

        COMMIT;

     DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
         'DBA_DMS.PCK_CTRL_BLOQUED_STATUS.SP_CTRL_BLOQUED_STATUS',
            'SE ACTUALIZARON ORDENES CON INCREMENTO: '
         || V_COUNT_BLOCKED_STATUS_INC
         ,
         SQLCODE,
         SQLERRM);
         END IF;
          P_BLOCKED_STATUS_INC := V_COUNT_BLOCKED_STATUS_INC;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            P_ERROR_FLAG := 'N';
            ROLLBACK;
           DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_CTRL_BLOQUED_STATUS.SP_CTRL_BLOQUED_STATUS',
                'NO HAY DATOS ',
                SQLCODE,
                SQLERRM);
        WHEN OTHERS
        THEN
              DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                  'DBA_DMS.PCK_CTRL_BLOQUED_STATUS.SP_CTRL_BLOQUED_STATUS',
                  'ERROR AL ACTUALIZAR BLOQUED_STATUS, NO SE EJECUTÓ EL PROCESO ',
                  SQLCODE,
                  SQLERRM);
            P_ERROR_CODE := SQLCODE;
            P_ERROR_FLAG := 'S';
            P_ERROR_MESSAGE :=
                CONCAT (CONCAT (SQLERRM, '  '),
                        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
            ROLLBACK;
    END SP_CTRL_BLOQUED_STATUS_INC;
END PCK_CTRL_BLOQUED_STATUS;
/

