create TYPE           "REJECT_ORDER_ROW"                                          AS OBJECT 
(
    REJECTED_ID VARCHAR2(20),
    MESSAGE VARCHAR2(4000)
)
/

