create PACKAGE BODY         PCK_SIMPLI_DELIVERY
AS
    PROCEDURE SP_INS_ORDER_SIMPLI_DELIVERY (P_ORDER_ID        IN NUMBER,
                                            P_ZONE            IN NUMBER,
                                            P_ACCOUNT         IN NUMBER,
                                            P_FULL_CAMPAIGN   IN NUMBER)
    AS
        V_ORDER_ID                NUMBER (19) := P_ORDER_ID;
        V_ZONE                    NUMBER (4) := P_ZONE;
        V_ACCOUNT                 NUMBER (8) := P_ACCOUNT;
        V_FULL_CAMPAIGN           NUMBER (6) := P_FULL_CAMPAIGN;
        V_COUNT_REPRE             NUMBER (3) := 0;
        V_ZONE_CONFIG             NUMBER (4) := 0;
        V_ACCOUNT_CONFIG          NUMBER (8) := 0;
        V_SOURCE_CONFIG           VARCHAR2 (3) := 0;
        V_SOURCE_ORDER            VARCHAR2 (1);
        V_ZONE_SCORE              NUMBER (3) := 0;
        V_FULL_CAMPAIGN_CONFG_I   NUMBER (6) := 0;
        V_FULL_CAMPAIGN_CONFG_E   NUMBER (6) := 0;
        V_ZONE_LOA                NUMBER (6) := 0;
        V_ENABLED                 NUMBER (1) := 0;
        V_CURRENT_CAMPAIGN        NUMBER (6) := 0;
        V_SCORE_REPRE             NUMBER (3) := 0;
        V_LOA_REPRE               NUMBER (5) := 0;
        V_EXISTE_SIMPLI_D         NUMBER (3) := 0;

        --- OBTIENE VALORES DE REPRESENTNATE Y ZONA
        CURSOR CUR_CONFIG_BEHAVIOR_SC IS
              SELECT ZONE_ID,
                     ACCOUNT,
                     SOURCE,
                     ZONE_SCORE,
                     FULL_CAMPAIGN_START,
                     FULL_CAMPAIGN_END,
                     ZONE_LOA,
                     ENABLED
                FROM DBA_DMS.CONFIG_BEHAVIOR_SCORE C
                     LEFT JOIN
                     (SELECT *
                        FROM DBA_DMS.BEHAVIOR_SCORE_RECORD U
                       WHERE (U.BH_SCORE_RECORD_ID, U.CONFIG_BH_ID) IN
                                 (  SELECT MAX (M.BH_SCORE_RECORD_ID)
                                               AS BH_SCORE_RECORD_ID,
                                           M.CONFIG_BH_ID
                                      FROM DBA_DMS.BEHAVIOR_SCORE_RECORD M
                                  GROUP BY M.CONFIG_BH_ID)) R
                         ON R.CONFIG_BH_ID = C.CONFIG_BH_ID
               WHERE     (ZONE_ID = V_ZONE OR ACCOUNT = V_ACCOUNT)
                   -- AND C.ENABLED = 1                     --- QUE ESTÉ ACTIVO
            --  AND
            ORDER BY ZONE_ID DESC;
    BEGIN
        SELECT COUNT (*)           -- OBTIENE CALIFICACIÓN DE LA REPRESENTANTE
          INTO V_COUNT_REPRE
          FROM DBA_DMS.BEHAVIOR_SCORE
         WHERE ACCOUNT = V_ACCOUNT AND ENABLED = 1;

        IF V_COUNT_REPRE > 0
        THEN
            SELECT NVL (SCORE, 0)  -- OBTIENE CALIFICACIÓN DE LA REPRESENTANTE
              INTO V_SCORE_REPRE
              FROM DBA_DMS.BEHAVIOR_SCORE
             WHERE ACCOUNT = V_ACCOUNT AND ENABLED = 1;
        ELSE
            V_SCORE_REPRE := 0;
        END IF;

        SELECT NVL (LOA, 0)                 -- OBTIENE LOA DE LA REPRESENTANTE
          INTO V_LOA_REPRE
          FROM DBA_DMS.REPRESENTATIVES
         WHERE ACCOUNT = V_ACCOUNT;

        OPEN CUR_CONFIG_BEHAVIOR_SC;

        LOOP
            FETCH CUR_CONFIG_BEHAVIOR_SC
                INTO V_ZONE_CONFIG,
                     V_ACCOUNT_CONFIG,
                     V_SOURCE_CONFIG,
                     V_ZONE_SCORE,
                     V_FULL_CAMPAIGN_CONFG_I,
                     V_FULL_CAMPAIGN_CONFG_E,
                     V_ZONE_LOA,
                     V_ENABLED;

            SELECT COUNT (*)
              INTO V_EXISTE_SIMPLI_D
              FROM DBA_DMS.ORDER_SIMPLI_DELIVERY
             WHERE ORDER_ID = V_ORDER_ID;

            EXIT WHEN    CUR_CONFIG_BEHAVIOR_SC%NOTFOUND
                      OR V_EXISTE_SIMPLI_D > 0; --- CUANDO YA TIENE REGISTRO ESA ÓRDEN EN SIMPLI ENTREGA

            ---- ASINGNA EL DATO DE ORIGEN DE LA INFORMACIÓN PARA INSERTARLO EN LA ÓRDEN

            SELECT DECODE (V_SOURCE_CONFIG,  'UBH', 'C',  'UZR', 'N')
              INTO V_SOURCE_ORDER
              FROM DUAL;

            CASE
                WHEN V_ZONE_CONFIG IS NOT NULL --- POR CONFIGURACIÓN DE ZONA
                AND V_ENABLED = 1 --- SIEMPRE HABILITADO
                THEN
                    ---EVALÚAR EL TIPO DE ZONA
                    IF V_SOURCE_CONFIG = 'UBH' --- POR CALIFICACIÓN MÍNIMA POR ZONA
                    THEN
                        IF (    V_SCORE_REPRE >= V_ZONE_SCORE
                            AND V_LOA_REPRE >= V_ZONE_LOA)
                        THEN
                            INSERT INTO DBA_DMS.ORDER_SIMPLI_DELIVERY (
                                            ORDER_ID,
                                            DATA_SOURCE,
                                            SCORE)
                                     VALUES (V_ORDER_ID,
                                             V_SOURCE_ORDER,
                                             V_SCORE_REPRE);

                            COMMIT;
                        END IF;
                    ELSIF V_SOURCE_CONFIG = 'UZR' --- ESTABLECIDO POR NEGOCIO PARA TODA LA ZONA
                    THEN
                        IF (    V_FULL_CAMPAIGN >= V_FULL_CAMPAIGN_CONFG_I
                            AND V_FULL_CAMPAIGN <= V_FULL_CAMPAIGN_CONFG_E)
                        THEN
                            INSERT INTO DBA_DMS.ORDER_SIMPLI_DELIVERY (
                                            ORDER_ID,
                                            DATA_SOURCE,
                                            SCORE)
                                     VALUES (V_ORDER_ID,
                                             V_SOURCE_ORDER,
                                             V_SCORE_REPRE);

                            COMMIT;
                        END IF;
                    END IF;
                WHEN V_ACCOUNT IS NOT NULL               --- ENTRA POR ACCOUNT
                THEN
                    IF     V_FULL_CAMPAIGN >= V_FULL_CAMPAIGN_CONFG_I
                       AND V_FULL_CAMPAIGN <= V_FULL_CAMPAIGN_CONFG_E
                    THEN
                        INSERT INTO DBA_DMS.ORDER_SIMPLI_DELIVERY (
                                        ORDER_ID,
                                        DATA_SOURCE,
                                        SCORE)
                                 VALUES (V_ORDER_ID,
                                         V_SOURCE_ORDER,
                                         V_SCORE_REPRE);

                        COMMIT;
                    END IF;
            END CASE;
        END LOOP;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            ROLLBACK;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_BEHAVIOR_SCORE.SP_INS_ORDER_BEHAVIOR_SCORE',
                'NO HAY DATOS ',
                SQLCODE,
                SQLERRM);
        WHEN OTHERS
        THEN
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_BEHAVIOR_SCORE.SP_INS_ORDER_BEHAVIOR_SCORE',
                'ERROR AL INSERTAR LOS SCORES DE LA REPRESENTANTE, NO SE EJECUTÓ EL PROCESO ',
                SQLCODE,
                SQLERRM);

            ROLLBACK;
    END SP_INS_ORDER_SIMPLI_DELIVERY;

    /******************************************************************************
   NAME:       FN_EDITION_DEADLINE_SD
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        01/08/2022      reyesros     1. Obtiene la fecha y hora límite para editar un registro en simpl entrega
******************************************************************************/

    FUNCTION FN_EDITION_DEADLINE_SD (P_FULL_CAMPAIGN   NUMBER,
                                     P_ZONE            NUMBER,
                                     V_HOUR            VARCHAR2)
        RETURN VARCHAR2
    AS
        --V_EDITION_DEADLINE  VARCHAR2 (30) := '00/00/00 00:00:00.000000000';
        V_EDITION_DEADLINE   VARCHAR2 (30) := '00/00/00 00:00:00.000000000';
    BEGIN
        SELECT TO_CHAR (BILLED_AT, 'dd/mm/yy') || ' ' || V_HOUR || '.000000'
          INTO V_EDITION_DEADLINE --- el neogicio lo cambia al mismo día de la factura 19/04/2022
          FROM DBA_DMS.ZONE_CAMPAIGNS Z
         WHERE FULL_CAMPAIGN = P_FULL_CAMPAIGN AND ZONE = P_ZONE;

        RETURN V_EDITION_DEADLINE;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN '00/00/00 00:00:00.000000000';
    END FN_EDITION_DEADLINE_SD;

     /******************************************************************************
   NAME:       FN_DEADLINE_SD_REPRE
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        02/08/2022      reyesros     1. Obtiene la fecha y hora límite para editar un registro por account en simpl entrega
******************************************************************************/

    FUNCTION FN_DEADLINE_SD_REPRE (P_FULL_CAMPAIGN NUMBER, P_ACOOUNT NUMBER)
        RETURN TIMESTAMP
    AS
        -- V_EDITION_DEADLINE  VARCHAR2 (30) := '00/00/00 00:00:00.000000000';
        V_EDITION_DEADLINE   TIMESTAMP (6);
        V_ZONE               NUMBER (4) := 0;
        V_HOUR               VARCHAR2 (8);
    BEGIN
        -- OBTIENE ZONA
        SELECT DEFAULT_ZONE
          INTO V_ZONE
          FROM DBA_DMS.REPRESENTATIVES
         WHERE ACCOUNT = P_ACOOUNT;

        --- OBTIENE HORA POR PARÁMETRO
        SELECT parameters.string_value
          INTO V_HOUR
          FROM DBA_DMS.PARAMETERS
         WHERE ID = 37;

        SELECT TO_CHAR (BILLED_AT, 'dd/mm/yyyy') || ' ' || V_HOUR
          INTO V_EDITION_DEADLINE --- el neogicio lo cambia al mismo día de la factura 19/04/2022
          FROM DBA_DMS.ZONE_CAMPAIGNS Z
         WHERE FULL_CAMPAIGN = P_FULL_CAMPAIGN AND ZONE = V_ZONE;

        RETURN V_EDITION_DEADLINE;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END FN_DEADLINE_SD_REPRE;

    FUNCTION FN_EDITION_DEADLINE_T (P_FULL_CAMPAIGN NUMBER, P_ACOOUNT NUMBER)
        RETURN TIMESTAMP
    AS
        V_COUNT                NUMBER (6);
        V_EDITION_DEADLINE_T   TIMESTAMP (6);
        V_ZONE                 NUMBER (4) := 0;
    BEGIN
        -- OBTIENE ZONA
        SELECT DEFAULT_ZONE
          INTO V_ZONE
          FROM DBA_DMS.REPRESENTATIVES
         WHERE ACCOUNT = P_ACOOUNT;

        SELECT     ---ZONE, CAMPAIGN_YEAR, CAMPAIGN, FULL_CAMPAIGN, BILLED_AT,
                 (BILLED_AT + NUMTODSINTERVAL (10, 'hour'))
               - NUMTODSINTERVAL (1, 'DAY')
          INTO V_EDITION_DEADLINE_T
          FROM ZONE_CAMPAIGNS Z
         WHERE FULL_CAMPAIGN = P_FULL_CAMPAIGN AND ZONE = v_ZONE;

        V_EDITION_DEADLINE_T :=
            TO_TIMESTAMP (
                TO_CHAR (V_EDITION_DEADLINE_T, 'DD/MM/YYYY HH24:MI:SS'),
                'DD/MM/YYYY HH24:MI:SS');
        RETURN V_EDITION_DEADLINE_T;
    END FN_EDITION_DEADLINE_T;
END PCK_SIMPLI_DELIVERY;
/

