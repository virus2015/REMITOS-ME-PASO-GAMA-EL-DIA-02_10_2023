create TYPE           "PACKAGE_STATUSES_ROW"                                          AS object(
	 ORDER_ID NUMBER(19),
	STATUS NUMBER(4),
	PACKAGE_ID NUMBER(19))
/

