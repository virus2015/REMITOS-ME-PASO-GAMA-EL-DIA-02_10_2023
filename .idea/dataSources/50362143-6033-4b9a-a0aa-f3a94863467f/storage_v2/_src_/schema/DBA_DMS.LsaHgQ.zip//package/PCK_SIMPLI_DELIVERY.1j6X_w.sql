create PACKAGE         PCK_SIMPLI_DELIVERY AS
/******************************************************************************
   NAME:       PCK_BEHAVIOR_SCORE
   PURPOSE:   INSERTA EN LA TABLA ORDER_BEHAVIOR_SCORE PARA APLICAR SIMPLI ENTREGA A REPRESENTANTES

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        21/07/2022      reyesros       1. Created this package.
******************************************************************************/


    PROCEDURE SP_INS_ORDER_SIMPLI_DELIVERY  (
                                 P_ORDER_ID     IN NUMBER, 
                                 P_ZONE            IN NUMBER, 
                                 P_ACCOUNT         IN NUMBER,
                                 P_FULL_CAMPAIGN   IN NUMBER); 
                                 
     FUNCTION FN_EDITION_DEADLINE_SD  (P_FULL_CAMPAIGN  NUMBER,
                                 P_ZONE NUMBER,
                                 V_HOUR  VARCHAR2)
                                 RETURN VARCHAR2;
                                 
   FUNCTION FN_DEADLINE_SD_REPRE  (P_FULL_CAMPAIGN  NUMBER,
                                 P_ACOOUNT NUMBER)
                                 RETURN timestamp;
  FUNCTION FN_EDITION_DEADLINE_T  (P_FULL_CAMPAIGN  NUMBER,
                                 P_ACOOUNT NUMBER)
                                 RETURN TIMESTAMP;                                 

END PCK_SIMPLI_DELIVERY;
/

