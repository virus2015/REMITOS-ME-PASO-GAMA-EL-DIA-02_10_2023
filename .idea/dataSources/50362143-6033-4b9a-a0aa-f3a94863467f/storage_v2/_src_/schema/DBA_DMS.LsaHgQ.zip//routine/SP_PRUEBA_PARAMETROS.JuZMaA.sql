create PROCEDURE SP_PRUEBA_PARAMETROS 
(
  p_parametro_tbl PARAMETRO_TBL 
) AS 
BEGIN
  FORALL I IN p_parametro_tbl.FIRST .. p_parametro_tbl.LAST
  
    update parameters set string_value = p_parametro_tbl(I).STRING_VALUE
    WHERE KEY = p_parametro_tbl(I).KEY;
    
END SP_PRUEBA_PARAMETROS;
/

