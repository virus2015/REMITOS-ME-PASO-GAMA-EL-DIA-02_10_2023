create PACKAGE BODY         PCK_DELETE_DATA_UTILS
AS
    PROCEDURE SP_DELETING_LOG (PA_GROUPED_BY                IN NUMBER, ---AGRUPADOS
                               PA_DELETE_DATA_ID            IN NUMBER,   ---ID
                               PA_ITERATION_ID              IN NUMBER, ---ITERACIÓN
                               PA_STARTING_DATA_COUNT       IN NUMBER, -- CONTEO INICIAL DE DATOS
                               PA_DELETING_DATA_COUNT       IN NUMBER, -- CONTEO DE DATOS PARA BORRAR
                               PA_SUCCESSFUL_BACKUP         IN NUMBER, -- TERMINA  BACKUP
                               PA_FILE_CREATION             IN NUMBER, -- COMIENZA A CREAR EL ARCHIVO DE RESPALDO
                               PA_SUCCESSFUL_FILE           IN NUMBER, -- TERMINA A CREAR EL ARCHIVO DE RESPALDO
                               PA_REMAINING_DATA_COUNT      IN NUMBER, -- CONTEO FINAL DE DATOS EN TABLA DESPUES DE BORRADO
                               PA_SUCCESSFUL_REINDEXATION   IN NUMBER, --- MOMENTO DE TÉRMINO DEL LA REINDEXACIÓN
                               PA_END                       IN NUMBER -- FLAG PARA PONER ESTAMPA DE TIEMPO AL FINAL DEL PROCESO
                                                                     --,PA_STATUS                  OUT NUMBER----0 EXITOSO, 1 ALGO PASÓ
                                                                     )
    AS
        V_EXIST_REG              NUMBER (2) := 0;           ---CUENTA REGISTRO
        V_DELETE_DATA_ID         NUMBER (8) := PA_DELETE_DATA_ID; --- ID DE TABLA EN DELETE_DATA
        V_ITERATION_ID           NUMBER (10) := PA_ITERATION_ID; --- ID DE TABLA EN DELETE_DATA
        V_GROUPED_BY             NUMBER (8) := PA_GROUPED_BY;    --- AGRUPADOS
        V_STARTING_DATA_COUNT    NUMBER (25) := PA_STARTING_DATA_COUNT; -- CONTEO INICIAL DE DATOS
        V_DELETING_DATA_COUNT    NUMBER (25) := PA_DELETING_DATA_COUNT; -- CONTEO DE DATOS PARA BORRAR
        V_SUCCESSFUL_BACKUP      NUMBER (1) := PA_SUCCESSFUL_BACKUP; -- TERMINA  BACKUP
        V_FILE_CREATION          NUMBER (1) := PA_FILE_CREATION; -- COMIENZA A CREAR EL ARCHIVO DE RESPALDO
        V_SUCCESSFUL_FILE        NUMBER (1) := PA_SUCCESSFUL_FILE; ---TERMINA A CREAR EL ARCHIVO DE RESPALDO
        V_SUCCESSFUL_REINDEX     NUMBER (1) := PA_SUCCESSFUL_REINDEXATION; --MOMENTO DE TÉRMINO DEL LA REINDEXACIÓN
        V_REMAINING_DATA_COUNT   NUMBER (25) := PA_REMAINING_DATA_COUNT; -- CONTEO FINAL DE DATOS
        V_END                    NUMBER (1) := PA_END;
    BEGIN
        IF V_GROUPED_BY > 0 AND V_ITERATION_ID > 0 AND V_END >= 0
        THEN
            INSERT INTO DBA_DMS.DEP_DELETING_LOG (DELETE_DATA_ID,
                                                  ITERATION_ID,
                                                  END_PROCESS)
                SELECT DELETE_DATA_ID, V_ITERATION_ID, V_END
                  FROM DBA_DMS.DEP_DELETE_DATA DD
                 WHERE     GROUPED_BY = V_GROUPED_BY
                       AND (DELETE_DATA_ID, V_ITERATION_ID) NOT IN
                               ((SELECT LD.DELETE_DATA_ID, LD.ITERATION_ID
                                   FROM DBA_DMS.DEP_DELETE_DATA  DD
                                        INNER JOIN
                                        DBA_DMS.DEP_DELETING_LOG LD
                                            ON (DD.DELETE_DATA_ID =
                                                LD.DELETE_DATA_ID)
                                  WHERE     GROUPED_BY = V_GROUPED_BY
                                        AND LD.ITERATION_ID = V_ITERATION_ID));

            COMMIT;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_DELETING_LOG',
                   'SE INSERTÓ LOG EN EL GRUPO: '
                || PA_GROUPED_BY
                || ', ITERACIÓN: '
                || PA_ITERATION_ID,
                SQLCODE,
                SQLERRM);

            --- ACTUALIZA POR COMPORTAMIENTO

            IF V_END = 2                         ---- RESTRICCIONES EN CASCADA
            THEN
                UPDATE DBA_DMS.DEP_DELETING_LOG
                   SET END_PROCESS = 2
                 WHERE     ITERATION_ID = V_ITERATION_ID
                       AND DELETE_DATA_ID IN
                               (SELECT DELETE_DATA_ID
                                  FROM DBA_DMS.DEP_DELETE_DATA DD
                                 WHERE GROUPED_BY = V_GROUPED_BY);

                COMMIT;
            ELSIF V_END = 3                           ---- FALTAN DEPENDENCIAS
            THEN
                UPDATE DBA_DMS.DEP_DELETING_LOG
                   SET END_PROCESS = 3
                 WHERE     ITERATION_ID = V_ITERATION_ID
                       AND DELETE_DATA_ID IN
                               (SELECT DELETE_DATA_ID
                                  FROM DBA_DMS.DEP_DELETE_DATA DD
                                 WHERE GROUPED_BY = V_GROUPED_BY);

                COMMIT;
            ELSIF V_END = 0                                    ---- EN PROCESO
            THEN
                UPDATE DBA_DMS.DEP_DELETING_LOG
                   SET END_PROCESS = 0
                 WHERE     ITERATION_ID = V_ITERATION_ID
                       AND DELETE_DATA_ID IN
                               (SELECT DELETE_DATA_ID
                                  FROM DBA_DMS.DEP_DELETE_DATA DD
                                 WHERE GROUPED_BY = V_GROUPED_BY);

                COMMIT;

                DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                    'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_DELETING_LOG',
                       'SE ACTUALIZÓ LOG EN EL GRUPO: '
                    || PA_GROUPED_BY
                    || ', ITERACIÓN: '
                    || PA_ITERATION_ID
                    || ' CON PROCESO:'
                    || PA_END,
                    SQLCODE,
                    SQLERRM);
            END IF;
        ELSIF V_DELETE_DATA_ID > 0 AND V_ITERATION_ID >= 0
        THEN
            ---CONSULTA ID DE TABLA POR NOMBRE Y ESQUEMA
            SELECT COUNT (*)
              INTO V_EXIST_REG
              FROM DBA_DMS.DEP_DELETE_DATA  DD
                   INNER JOIN DBA_DMS.DEP_DELETING_LOG LD
                       ON DD.DELETE_DATA_ID = LD.DELETE_DATA_ID
             WHERE (    LD.DELETE_DATA_ID = V_DELETE_DATA_ID
                    AND ITERATION_ID = V_ITERATION_ID);

            CASE V_EXIST_REG
                WHEN 0                      --- NO TIENE REGISTRO LOG, INSERTA
                THEN
                    INSERT INTO DBA_DMS.DEP_DELETING_LOG (
                                    DELETE_DATA_ID,
                                    ITERATION_ID,
                                    START_PROCESS,
                                    STARTING_DATA_COUNT,
                                    DELETING_DATA_COUNT,
                                    END_PROCESS)
                             VALUES (
                                        V_DELETE_DATA_ID,
                                        V_ITERATION_ID,
                                        CURRENT_TIMESTAMP
                                            AT TIME ZONE 'America/Mexico_City',
                                        V_STARTING_DATA_COUNT,
                                        V_DELETING_DATA_COUNT,
                                        0);

                    COMMIT;
                    DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                        'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_DELETING_LOG',
                           'SE INSERTÓ LOG DE LA TABLA: '
                        || PA_DELETE_DATA_ID
                        || ', ITERACIÓN: '
                        || PA_ITERATION_ID,
                        SQLCODE,
                        SQLERRM);
                WHEN 1                      ---  TIENE REGISTRO LOG, ACTUALIZA
                THEN
                    --- ACTUALIZA POR COMPORTAMIENTO
                    IF V_SUCCESSFUL_BACKUP = 1 ---TERMINA CREACIÓN DE TABLA BACKUP
                    THEN
                        UPDATE DBA_DMS.DEP_DELETING_LOG
                           SET SUCCESSFUL_BACKUP =
                                   CURRENT_TIMESTAMP
                                       AT TIME ZONE 'America/Mexico_City'
                         WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                               AND ITERATION_ID = V_ITERATION_ID;

                        COMMIT;
                    END IF;

                    /*   IF V_FILE_CREATION = 1 ---  COMIENZA RESPALDO EN ARCHIVO
                       THEN
                           UPDATE DBA_DMS.DEP_DELETING_LOG
                              SET FILE_CREATION =
                                      CURRENT_TIMESTAMP
                                          AT TIME ZONE 'America/Mexico_City'
                            WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                                  AND ITERATION_ID = V_ITERATION_ID;

                           COMMIT;
                           END IF;
                       IF V_SUCCESSFUL_FILE = 1 ---  TERMINA RESPALDO EN ARCHIVO
                       THEN
                           UPDATE DBA_DMS.DEP_DELETING_LOG
                              SET SUCCESSFUL_FILE =
                                      CURRENT_TIMESTAMP
                                          AT TIME ZONE 'America/Mexico_City'
                            WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                                  AND ITERATION_ID = V_ITERATION_ID;

                           COMMIT;
                           END IF
                       ELSIF V_SUCCESSFUL_REINDEX = 1 ---  TERMINA RESPALDO EN ARCHIVO
                       THEN
                           UPDATE DBA_DMS.DEP_DELETING_LOG
                              SET SUCCESSFUL_REINDEXATION =
                                      CURRENT_TIMESTAMP
                                          AT TIME ZONE 'America/Mexico_City'
                            WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                                  AND ITERATION_ID = V_ITERATION_ID;

                           COMMIT;*/
                    IF V_REMAINING_DATA_COUNT > 0   --- ACTUALIZA CONTEO FINAL
                    THEN
                        UPDATE DBA_DMS.DEP_DELETING_LOG
                           SET REMAINING_DATA_COUNT = V_REMAINING_DATA_COUNT
                         WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                               AND ITERATION_ID = V_ITERATION_ID;

                        COMMIT;
                    END IF;

                    IF V_END IS NOT NULL
                    THEN
                        UPDATE DBA_DMS.DEP_DELETING_LOG --- ESTAMPA EL MOMENTO DE TERMINACIÓN DE LA INDEXACIÓN
                           SET END_PROCESS = V_END
                         WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                               AND ITERATION_ID = V_ITERATION_ID;

                        COMMIT;
                        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                            'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_DELETING_LOG',
                               'SE ACTUALIZÓ LOG DE LA LA TABLA: '
                            || PA_DELETE_DATA_ID
                            || ', ITERACIÓN: '
                            || PA_ITERATION_ID,
                            SQLCODE,
                            SQLERRM);
                    END IF;
                ELSE
                    DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                        'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_DELETING_LOG',
                           'NO SE EJECUTÓ NINGUNA SENTENCIA, ERROR EN DE LA TABLA: '
                        || PA_DELETE_DATA_ID
                        || ' O GRUPO:'
                        || PA_GROUPED_BY
                        || ', ITERACIÓN: '
                        || PA_ITERATION_ID,
                        SQLCODE,
                        SQLERRM);
                    ROLLBACK;
            END CASE;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            ROLLBACK;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_DELETING_LOG',
                   'NO SE INSERTÓ O ACTUALIZÓ REGISTRO EN DELETING_LOG, NO HAY DATOS, DE LA TABLA: '
                || PA_DELETE_DATA_ID
                || ' O GRUPO:'
                || PA_GROUPED_BY
                || ', ITERACIÓN: '
                || PA_ITERATION_ID,
                SQLCODE,
                SQLERRM);
        WHEN OTHERS
        THEN
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_DELETING_LOG',
                   'NO SE INSERTÓ O ACTUALIZÓ REGISTRO EN DELETING_LOG, ERROR INSESPERADO DE LA TABLA: '
                || PA_DELETE_DATA_ID
                || ' O GRUPO:'
                || PA_GROUPED_BY
                || ', ITERACIÓN: '
                || PA_ITERATION_ID,
                SQLCODE,
                SQLERRM);
            ROLLBACK;
    END SP_DELETING_LOG;

    PROCEDURE SP_GET_GROUP (PA_OWNER          IN     VARCHAR2,    ---- ESQUEMA
                            PA_ITERATION_ID   IN     NUMBER,      ---ITERACIÓN
                            PA_LIST              OUT VARCHAR2, --- LISTA DE GRUPOS PARA PROCESAR
                            PA_EXECUTION         OUT NUMBER, --  1 - TODO OK, 0 - ALGO SALÍO MAL
                            PA_PROCESS           OUT VARCHAR2   -- IMPRIME LOG
                                                             )
    AS
        V_OWNER          CONSTANT VARCHAR (80) := PA_OWNER;       ---- ESQUEMA
        V_ITERATION_ID   CONSTANT NUMBER (10) := PA_ITERATION_ID; ---ITERACIÓN
        V_LIST                    VARCHAR2 (2500) := '0';
        V_EXECUTION               NUMBER (1) := '0';
        V_PROCESS                 VARCHAR2 (2500) := NULL;
        V_PROCESS_CASCADE         VARCHAR2 (2500);
        V_PROCESS_DEPENDE         VARCHAR2 (2500);
        V_CASCADE                 NUMBER (8);
        V_C_EXISTS_CASCADE        NUMBER (8);
        V_DEPENDENCY              NUMBER (8);
        V_C_EXISTS_DEPENDENCY     NUMBER (8);

        CURSOR CUR_SELECT_CASCADE
        IS
            SELECT GROUPED_BY
              FROM all_constraints  c
                   INNER JOIN DBA_DMS.DEP_DELETE_DATA DD
                       ON (    C.owner = DD.TABLE_OWNER
                           AND C.table_name = DD.table_name)
             WHERE DD.TABLE_OWNER = USER AND DELETE_RULE = 'CASCADE';

        CURSOR CUR_SELECT_DEPENDE
        IS
            SELECT (SELECT dep_delete_data.GROUPED_BY
                      FROM DBA_DMS.DEP_DELETE_DATA
                     WHERE TABLE_OWNER = USER AND TABLE_NAME = c.table_name)
                       AS GROUPED_BY
              FROM all_cons_columns  cC
                   INNER JOIN all_constraints c
                       ON     c.r_constraint_name = cc.constraint_name
                          AND c.r_owner = cc.owner
                          AND cc.owner = USER
                          AND cc.table_name IN
                                  (SELECT TABLE_NAME
                                     FROM DBA_DMS.DEP_DELETE_DATA
                                    WHERE TABLE_OWNER = USER AND STATUS = 1)
                          AND c.table_name NOT IN
                                  (SELECT TABLE_NAME
                                     FROM DBA_DMS.DEP_DELETE_DATA
                                    WHERE TABLE_OWNER = USER AND STATUS = 1);
    BEGIN
        IF V_OWNER = USER
        THEN
            SELECT COUNT (*)
              INTO V_C_EXISTS_CASCADE
              FROM all_constraints  c
                   INNER JOIN DBA_DMS.DEP_DELETE_DATA DD
                       ON (    C.owner = DD.TABLE_OWNER
                           AND C.table_name = DD.table_name)
             WHERE DD.TABLE_OWNER = V_OWNER AND DELETE_RULE = 'CASCADE';

            IF V_C_EXISTS_CASCADE > 0
            THEN
                OPEN CUR_SELECT_CASCADE;

                LOOP
                    FETCH CUR_SELECT_CASCADE INTO V_CASCADE;

                    EXIT WHEN CUR_SELECT_CASCADE%NOTFOUND;
                    DBA_DMS.PCK_DELETE_DATA_UTILS.SP_DELETING_LOG (
                        V_CASCADE,                         ---SI GRUPO ID NULL
                        NULL,                              ---SI ID GRUPO NULL
                        V_ITERATION_ID,                           ---ITERACIÓN
                        NULL,                                         --- NULL
                        NULL,                                         --- NULL
                        NULL,                                         --- NULL
                        NULL,                                         --- NULL
                        NULL,                                         --- NULL
                        NULL,                                         --- NULL
                        NULL,                                         --- NULL
                        2);
                    DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                        'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_GET_GROUP',
                           'SE INSERTÓ O ACTUALIZÓ LOG DEL GRUPO: '
                        || V_CASCADE
                        || ' PORQUE SE ENCONTRÓ RESTRICCIÓN EN CASCADA',
                        SQLCODE,
                        SQLERRM);
                END LOOP;

                COMMIT;

                CLOSE CUR_SELECT_CASCADE;

                  SELECT DBA_DMS.FN_STRING_CONCAT (
                                DELETE_DATA_ID
                             || ':'
                             || DD.table_name
                             || '->CASCADE ON CONSTRAINT '
                             || R_CONSTRAINT_NAME)
                    INTO V_PROCESS_CASCADE
                    FROM all_constraints c
                         INNER JOIN DBA_DMS.DEP_DELETE_DATA DD
                             ON (    C.owner = DD.TABLE_OWNER
                                 AND C.table_name = DD.table_name)
                   WHERE DD.TABLE_OWNER = USER AND DELETE_RULE = 'CASCADE'
                GROUP BY DD.TABLE_OWNER, DELETE_RULE;

                V_EXECUTION := 1;

                SELECT COUNT (*)
                  INTO V_C_EXISTS_DEPENDENCY
                  FROM all_cons_columns  cC
                       INNER JOIN all_constraints c
                           ON     c.r_constraint_name = cc.constraint_name
                              AND c.r_owner = cc.owner
                              AND cc.owner = USER
                              AND cc.table_name IN
                                      (SELECT TABLE_NAME
                                         FROM DBA_DMS.DEP_DELETE_DATA
                                        WHERE     TABLE_OWNER = USER
                                              AND STATUS = 1)
                              AND c.table_name NOT IN
                                      (SELECT TABLE_NAME
                                         FROM DBA_DMS.DEP_DELETE_DATA
                                        WHERE     TABLE_OWNER = USER
                                              AND STATUS = 1);

                IF V_C_EXISTS_DEPENDENCY > 0
                THEN
                    OPEN CUR_SELECT_DEPENDE;

                    LOOP
                        FETCH CUR_SELECT_DEPENDE INTO V_DEPENDENCY;

                        EXIT WHEN CUR_SELECT_DEPENDE%NOTFOUND;
                        DBA_DMS.PCK_DELETE_DATA_UTILS.SP_DELETING_LOG (
                            V_DEPENDENCY,                  ---SI GRUPO ID NULL
                            NULL,                          ---SI ID GRUPO NULL
                            V_ITERATION_ID,                       ---ITERACIÓN
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            3);
                        COMMIT;
                        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                            'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_GET_GROUP',
                               'SE INSERTÓ O ACTUALIZÓ LOG DEL GRUPO: '
                            || V_CASCADE
                            || 'PORQUE SE ENCONTRÓ RESTRICCIÓN EN CASCADA',
                            SQLCODE,
                            SQLERRM);
                    END LOOP;

                    V_EXECUTION := 1;

                    CLOSE CUR_SELECT_DEPENDE;

                    SELECT    CHR (44)
                           || DBA_DMS.FN_STRING_CONCAT (
                                     '0:'
                                  || CD.TABLE_NAME
                                  || '->FALTA MAPEO DE DATOS EN DELETE_DATA')
                      INTO V_PROCESS_DEPENDE
                      FROM (SELECT c.TABLE_NAME
                              FROM all_cons_columns  cC
                                   INNER JOIN all_constraints c
                                       ON     c.r_constraint_name =
                                              cc.constraint_name
                                          AND c.r_owner = cc.owner
                                          AND cc.owner = USER
                                          AND cc.table_name IN
                                                  (SELECT TABLE_NAME
                                                     FROM DBA_DMS.DEP_DELETE_DATA
                                                    WHERE     TABLE_OWNER =
                                                              USER
                                                          AND STATUS = 1)
                                          AND c.table_name NOT IN
                                                  (SELECT TABLE_NAME
                                                     FROM DBA_DMS.DEP_DELETE_DATA
                                                    WHERE     TABLE_OWNER =
                                                              USER
                                                          AND STATUS = 1)) CD;
                END IF;
            END IF;
        ELSE
            V_PROCESS :=
                   'NO SE INSERTÓ O ACTUALIZÓ REGISTRO, EL USUARIO: '
                || PA_OWNER
                || ' NO TIENE PERMISO DE EJECUCIÓN EN: '
                || USER;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_GET_GROUP',
                   'NO SE INSERTÓ O ACTUALIZÓ REGISTRO, EL USUARIO: '
                || PA_OWNER
                || ' NO TIENE PERMISO DE EJECUCIÓN EN: '
                || USER,
                SQLCODE,
                SQLERRM);
        END IF;

        SELECT DBA_DMS.FN_STRING_CONCAT (LISTA)
          INTO V_LIST
          FROM (  SELECT DISTINCT (GROUPED_BY) AS LISTA
                    FROM DBA_DMS.DEP_DELETE_DATA DD
                   WHERE     TABLE_OWNER = USER
                         AND dd.status = 1
                         AND STATUS = 1
                         AND DELETE_DATA_ID NOT IN
                                 (SELECT DELETE_DATA_ID
                                    FROM DBA_DMS.DEP_DELETING_LOG
                                   WHERE     ITERATION_ID = V_ITERATION_ID
                                         AND END_PROCESS IN (2, 3, 10))
                ORDER BY dd.grouped_by DESC);

        V_EXECUTION := 1;
        V_PROCESS := V_PROCESS_CASCADE || V_PROCESS_DEPENDE;
        PA_EXECUTION := V_EXECUTION;
        PA_PROCESS := V_PROCESS;
        PA_LIST := V_LIST;
        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
            'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_GET_GROUP',
            V_PROCESS,
            SQLCODE,
            SQLERRM);
        COMMIT;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            PA_EXECUTION := 0;
            PA_PROCESS := V_PROCESS;
            PA_LIST := 0;
            ROLLBACK;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_GET_GROUP',
                   'NO SE INSERTÓ O ACTUALIZÓ REGISTRO, NO HAY DATOS: '
                || PA_OWNER
                || ' CON LA ITERACION: '
                || PA_ITERATION_ID,
                SQLCODE,
                SQLERRM);
        WHEN OTHERS
        THEN
            PA_EXECUTION := 0;
            PA_PROCESS := V_PROCESS;
            PA_LIST := 0;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_GET_GROUP',
                   'NO SE INSERTÓ O ACTUALIZÓ REGISTRO, ERROR INSESPERADO DE LA TABLA: '
                || PA_OWNER,
                SQLCODE,
                SQLERRM);
            ROLLBACK;
    END SP_GET_GROUP;
END PCK_DELETE_DATA_UTILS;

/

