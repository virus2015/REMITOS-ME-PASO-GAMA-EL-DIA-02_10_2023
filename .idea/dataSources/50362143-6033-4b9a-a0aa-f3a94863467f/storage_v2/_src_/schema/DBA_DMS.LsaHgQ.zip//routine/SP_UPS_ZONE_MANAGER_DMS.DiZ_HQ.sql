create procedure         sp_ups_zone_manager_dms
(	p_id            in varchar2, 
	p_zone_id       in number, 
	p_given_name    in varchar2, 
	p_last_name     in varchar2, 
	p_second_last_name in varchar2, 
	p_email         in varchar2, 
	p_zone_status   in number,
    p_inserted_row out number,
    p_error_flag out varchar2,
    p_error_code out varchar2,
    p_error_message out varchar2
)
is
begin

 p_error_flag := 'N';

    select count(id) into p_inserted_row from ZONE_MANAGER 
    where id = p_id
    and zone_id = p_zone_id;

    IF ( p_inserted_row = 0 ) THEN
        insert into ZONE_MANAGER (ID,ZONE_ID,GIVEN_NAME,LAST_NAME,SECOND_LAST_NAME,EMAIL,ZONE_STATUS) values 
        (	p_id, 
            p_zone_id, 
            p_given_name, 
            p_last_name, 
            p_second_last_name, 
            p_email, 
            p_zone_status
        );
        commit;
    END IF;

     IF ( p_inserted_row >= 1 ) THEN
           update ZONE_MANAGER zm set
            zm.id = p_id, 
            zm.zone_id  = p_zone_id, 
            zm.given_name = p_given_name, 
            zm.last_name = p_last_name, 
            zm.second_last_name = p_second_last_name, 
            zm.email = p_email, 
            zm.zone_status = p_zone_status
          where zm.id = p_id
                and zm.zone_id = p_zone_id;
          commit;
    END IF;

    EXCEPTION
          WHEN OTHERS THEN
         rollback;
         p_error_code := SQLCODE;
         p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
         p_error_flag := 'S';

end sp_ups_zone_manager_dms;
/

