create PROCEDURE SP_UPD_SLT_REASON_DMS (
  P_LONG_VALUE IN VARCHAR2)
  IS
  
  V_LONG_VALUE NUMBER(19,0);

BEGIN

  if P_LONG_VALUE is not null then
     if P_LONG_VALUE = '' then
         V_LONG_VALUE := null;
     else
         V_LONG_VALUE := to_number(P_LONG_VALUE);
     end if;
  else
    V_LONG_VALUE := null;
  end if;

  if ( V_LONG_VALUE is not null ) then

    update PARAMETERS
    set LONG_VALUE = V_LONG_VALUE
        where ID = 17;

        commit;

  end if;

  EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20001,
                            'HA OCURRIDO UN ERROR AL INTENTAR ACTUALIZAR  ' || V_LONG_VALUE ||' - ' ||
                            SQLCODE || ' -ERROR- ' || SQLERRM);



END SP_UPD_SLT_REASON_DMS;
/

