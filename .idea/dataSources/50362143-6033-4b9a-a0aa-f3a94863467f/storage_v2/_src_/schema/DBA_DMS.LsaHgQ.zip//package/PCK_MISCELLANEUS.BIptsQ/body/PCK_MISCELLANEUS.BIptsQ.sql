create PACKAGE BODY         PCK_MISCELLANEUS AS
/******************************************************************************
   NAME:       FN_EDITION_DEADLINE
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        28/02/2022      reyesros     1. Obtiene la fecha y hora límite para editar un registro en mensajes de COD
******************************************************************************/

    FUNCTION FN_EDITION_DEADLINE  (P_FULL_CAMPAIGN  NUMBER,
                                 P_ZONE NUMBER,
                                 P_HOUR  VARCHAR2)
                                 RETURN VARCHAR2
                                 AS
    V_EDITION_DEADLINE  VARCHAR2 (30) := '00/00/00 00:00:00.000000000';

  BEGIN


    SELECT ---ZONE, CAMPAIGN_YEAR, CAMPAIGN, FULL_CAMPAIGN, BILLED_AT, 
   -- TO_CHAR (BILLED_AT - 1 )||' '||P_HOUR||'.000000'  INTO V_EDITION_DEADLINE 
    --TO_CHAR (FIRST_ATTEMPT_AT - 1 )||' '||P_HOUR||'.000000'  INTO V_EDITION_DEADLINE --- fecha de primer reparto -1
     TO_CHAR (BILLED_AT,'DD-MON-YYYY')||' '||P_HOUR||'.000000'  INTO V_EDITION_DEADLINE --- el neogicio lo cambia al mismo día de la factura 19/04/2022
    FROM ZONE_CAMPAIGNS Z
    WHERE FULL_CAMPAIGN = P_FULL_CAMPAIGN 
    AND ZONE = P_ZONE;
    RETURN V_EDITION_DEADLINE;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
         RETURN  '00/00/00 00:00:00.000000000';
 END FN_EDITION_DEADLINE;
 /******************************************************************************
   NAME:       FN_EDITION_DEADLINE
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        28/02/2022      reyesros     1. Obtiene la fecha y hora límite para editar un registro en miscelaneos GZ
******************************************************************************/

    FUNCTION FN_EDITION_DEADLINE_T  (P_FULL_CAMPAIGN  NUMBER,
                                 P_ZONE NUMBER,
                                 P_HOUR  VARCHAR2)
                                 RETURN TIMESTAMP
                                 AS
    V_COUNT                 NUMBER (6);
    V_EDITION_DEADLINE_T  TIMESTAMP (6);
  BEGIN

    SELECT ---ZONE, CAMPAIGN_YEAR, CAMPAIGN, FULL_CAMPAIGN, BILLED_AT, 
 (BILLED_AT  + numtodsinterval (14,'hour')) -numtodsinterval (1,'DAY')  INTO V_EDITION_DEADLINE_T
    FROM ZONE_CAMPAIGNS Z
    WHERE FULL_CAMPAIGN = P_FULL_CAMPAIGN 
    AND ZONE = P_ZONE;
        V_EDITION_DEADLINE_T  := TO_TIMESTAMP(TO_CHAR( V_EDITION_DEADLINE_T, 'DD/MM/YYYY HH24:MI:SS'), 'DD/MM/YYYY HH24:MI:SS');
    RETURN V_EDITION_DEADLINE_T;

  END FN_EDITION_DEADLINE_T;
 /******************************************************************************
   NAME:       SP_MISCELANEUSGZ_DL
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        02/03/2022      reyesros     1. Actualiza el transfer flag para boqueo de registros de acuerdo a su fecha límite de edición
******************************************************************************/

  PROCEDURE SP_MISCELANEUSGZ_DL (   P_ROWS              OUT VARCHAR2,
                                    P_ERROR_CODE         OUT VARCHAR2,
                                    P_ERROR_MESSAGE      OUT VARCHAR2)AS
       V_ROWS  NUMBER (19) := 0;                             
    BEGIN

    UPDATE DBA_DMS.MISCELLANEOUS_GZ SET TRANSFER_FLAG = 'F', UPDATED_AT = CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City'
    WHERE TRANSFER_FLAG = 'N' AND EDITION_DEADLINE <= CURRENT_TIMESTAMP;
    V_ROWS := SQL%ROWCOUNT;
    COMMIT;
    P_ROWS := V_ROWS;
    EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
                      P_ROWS := 0;
    WHEN OTHERS
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ROWS := 0;

  END SP_MISCELANEUSGZ_DL;
   PROCEDURE SP_COD_MESSAGES_DL ( P_ROWS              OUT VARCHAR2,--- REGISTROS PROCESADOS
                                P_ERROR_CODE         OUT VARCHAR2,--- NUM DE ERROR
                                P_ERROR_MESSAGE      OUT VARCHAR2)
                            AS

        V_ROWS  NUMBER (19) := 0;                             
    BEGIN

    UPDATE DBA_DMS.COD_MESSAGES SET TRANSFER_FLAG = 'F', UPDATED_AT = CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City'
    WHERE TRANSFER_FLAG = 'N' AND EDITION_DEADLINE <= CURRENT_TIMESTAMP;
    V_ROWS := SQL%ROWCOUNT;
    COMMIT;
    P_ROWS := V_ROWS;
    EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
                      P_ROWS := 0;
    WHEN OTHERS
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
 END SP_COD_MESSAGES_DL;

END PCK_MISCELLANEUS;
/

