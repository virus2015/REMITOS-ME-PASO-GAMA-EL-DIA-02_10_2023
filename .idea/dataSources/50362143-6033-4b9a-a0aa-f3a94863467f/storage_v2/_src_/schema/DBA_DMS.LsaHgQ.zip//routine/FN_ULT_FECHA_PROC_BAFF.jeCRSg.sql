create Function         FN_ULT_FECHA_PROC_BAFF
   RETURN date
IS
    Fecha_Actualizacion DATE;
BEGIN
    SELECT TRUNC(MAX(Updated_At)) INTO Fecha_Actualizacion
    FROM   Bids_Amounts_From_File;

    RETURN Fecha_Actualizacion;
END;
/

