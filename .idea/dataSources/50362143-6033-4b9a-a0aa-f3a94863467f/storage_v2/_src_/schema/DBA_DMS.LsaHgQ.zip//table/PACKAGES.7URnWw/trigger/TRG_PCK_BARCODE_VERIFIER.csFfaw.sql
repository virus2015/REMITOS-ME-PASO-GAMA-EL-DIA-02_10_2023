create trigger TRG_PCK_BARCODE_VERIFIER
    before insert or update
    on PACKAGES
    for each row
    when (LENGTH(new.BARCODE) = 11)
BEGIN
    :new.BARCODE := concat(:new.BARCODE,FN_DIGITO_VERIFICADOR(:NEW.BARCODE));
END;
/

