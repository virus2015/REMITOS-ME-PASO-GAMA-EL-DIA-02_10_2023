create trigger TRG_ORDERS_UPDATE_TRANSFER
    before update
    on ORDERS
    for each row
    when (OLD.TRANSFER_FLAG = 'F' AND NEW.TRANSFER_FLAG IN ('D', 'E'))
BEGIN
    :NEW.TRANSFER_FLAG := (:OLD.TRANSFER_FLAG);
END;
/

