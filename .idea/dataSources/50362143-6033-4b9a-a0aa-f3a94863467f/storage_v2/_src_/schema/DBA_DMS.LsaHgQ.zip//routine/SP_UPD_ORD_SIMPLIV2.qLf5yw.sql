create PROCEDURE SP_UPD_ORD_SIMPLIV2 
(
  P_ORDER_UPD_TBL ORDER_UPD_TBL,
  P_ERROR_FLAG OUT VARCHAR2,
  P_ERROR_MESSAGE OUT VARCHAR2
  --P_ERROR_MESSAGE OUT orders_id_array
) AS
 
BEGIN

  P_ERROR_FLAG := 'N';
  
  FORALL I IN P_ORDER_UPD_TBL.FIRST .. P_ORDER_UPD_TBL.LAST SAVE EXCEPTIONS
  

      update orders set
                  payment_value = P_ORDER_UPD_TBL(I).P_PAYMENT_VALUE,
                  bank_code = P_ORDER_UPD_TBL(I).P_BANK_CODE,
                  payment_date = P_ORDER_UPD_TBL(I).P_PAYMENT_DATE,
                  round_num = P_ORDER_UPD_TBL(I).P_ROUND_NUM,
                  return_reason = P_ORDER_UPD_TBL(I).P_RETURN_REASON,
                  notes = P_ORDER_UPD_TBL(I).P_NOTES,
                  dlv_typ = P_ORDER_UPD_TBL(I).P_DLV_TYP,
                  delivery1st = P_ORDER_UPD_TBL(I).P_DELIVERY1ST,
                  return_val = P_ORDER_UPD_TBL(I).P_RETURN_VAL,
                  pick_up_point_id = P_ORDER_UPD_TBL(I).P_PICK_UP_POINT_ID,
                  blocked_status = P_ORDER_UPD_TBL(I).P_BLOCKED_STATUS,
                  stolen = P_ORDER_UPD_TBL(I).P_STOLEN,
                  change_flag = 'T',
                  UPDATED_AT = CURRENT_TIMESTAMP
        where order_id = P_ORDER_UPD_TBL(I).P_ORDER_ID;
        
        
   FORALL I IN P_ORDER_UPD_TBL.FIRST .. P_ORDER_UPD_TBL.LAST SAVE EXCEPTIONS
  

        insert into orders_statuses(order_id, updated_at, status)
        VALUES
        (P_ORDER_UPD_TBL(I).P_ORDER_ID,CURRENT_TIMESTAMP,P_ORDER_UPD_TBL(I).P_STATUSES);
        
   commit;
  
   EXCEPTION  
   WHEN std_errs.failure_in_forall  
   THEN  
   
   P_ERROR_FLAG := 'S';
   
      DBMS_OUTPUT.put_line (SQLERRM);  
      DBMS_OUTPUT.put_line (  
         'Updated ' || SQL%ROWCOUNT || ' rows.');  
  
      FOR indx IN 1 .. SQL%BULK_EXCEPTIONS.COUNT  
      LOOP  
      
         --DBMS_OUTPUT.put_line (
         
         P_ERROR_MESSAGE := P_ORDER_UPD_TBL( SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX).P_ORDER_ID
            || SQLERRM ( -1 * SQL%BULK_EXCEPTIONS (indx).ERROR_CODE);
         /*
        P_ERROR_MESSAGE :=       'Error '  
            || indx  
            || ' occurred on index '  
            || SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX  
            || ' attempting to update name to "'  
          --  || P_ORDER_UPD_TBL (  SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX)  
            || P_ORDER_UPD_TBL( SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX).P_ORDER_ID
            || '"'  
    --     DBMS_OUTPUT.put_line (  
             ||  'Oracle error is '  
            || SQLERRM ( -1 * SQL%BULK_EXCEPTIONS (indx).ERROR_CODE);
             --     );  
             */
          /*   
              P_ERROR_MESSAGE (  SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX)  :=  'Error '  
            || indx  
            || ' occurred on index '  
            || SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX  
            || ' attempting to update name to "'  
          --  || P_ORDER_UPD_TBL (  SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX)  
            || P_ORDER_UPD_TBL( SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX).P_ORDER_ID
            || '"'  
    --     DBMS_OUTPUT.put_line (  
             ||  'Oracle error is '  
            || SQLERRM ( -1 * SQL%BULK_EXCEPTIONS (indx).ERROR_CODE);     */
          
             
      END LOOP;
      ROLLBACK;
END SP_UPD_ORD_SIMPLIV2;
/

