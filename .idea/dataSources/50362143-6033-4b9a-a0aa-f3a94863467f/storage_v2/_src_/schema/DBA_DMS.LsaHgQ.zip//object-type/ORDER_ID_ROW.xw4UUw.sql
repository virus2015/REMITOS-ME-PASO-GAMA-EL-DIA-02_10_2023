create TYPE           "ORDER_ID_ROW"                                          AS OBJECT 
(
    P_ORDER_ID NUMBER
)
/

