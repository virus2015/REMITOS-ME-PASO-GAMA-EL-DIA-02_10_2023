create FUNCTION FN_DIGITO_VERIFICADOR (BOX_BARCODE in VARCHAR2)
RETURN NUMBER
AS
    V_RESULT NUMBER;
BEGIN
    V_RESULT := 0;
    FOR i IN 1 .. 12 LOOP
        V_RESULT := (V_RESULT
            + (nvl(to_number((substr(BOX_BARCODE,i, 1))),0) * nvl(MOD(i+1,2),0))
            + (nvl(to_number((substr(BOX_BARCODE,i, 1))),0) * 3 * nvl(MOD(i,2),0) ));
        V_RESULT := NVL(V_RESULT,0);
        --DBMS_OUTPUT.PUT_LINE(to_char(V_RESULT));
    END LOOP;
    V_RESULT := MOD(10 - MOD(V_RESULT,10),10);
    --DBMS_OUTPUT.PUT_LINE(to_char(V_RESULT));
  RETURN V_RESULT;
END;
/

