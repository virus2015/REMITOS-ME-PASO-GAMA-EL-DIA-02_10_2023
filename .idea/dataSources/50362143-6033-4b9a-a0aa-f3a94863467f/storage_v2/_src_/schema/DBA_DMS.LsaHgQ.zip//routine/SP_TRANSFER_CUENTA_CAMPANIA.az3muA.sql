create procedure SP_TRANSFER_CUENTA_CAMPANIA
(	p_transaction_id    in char,
    p_account           out number, 
    p_campaign_year     out number, 
    p_campaign          out number, 
    p_payment_value     out number, 
    p_error_flag        out varchar2,
    p_error_code        out varchar2,
    p_error_message     out varchar2
)
is
begin
      SELECT PT.ACCOUNT, SUBSTR(PT.FULL_CAMPAIGN,4,2) CAMPAIGN_YEAR, SUBSTR(PT.FULL_CAMPAIGN,1,4) CAMPAIGN, O.PAYMENT_VALUE 
       INTO p_account, p_campaign_year, p_campaign, p_payment_value
        FROM PAYMENT_REQUESTS R      
        JOIN SCPI_ORDER_HEADERS PT  ON R.ZONE = PT.ZONE
        JOIN BIDS_AMOUNTS_FROM_FILE BF ON BF.ACCOUNT = PT.ACCOUNT
        JOIN ORDERS O               ON O.ORDER_ID = PT.ORDER_ID
        JOIN BANK_CODES B 		    ON O.BANK_CODE = B.BANK_CODE 
        WHERE R.ANALYST_ID = p_transaction_id
        AND   R.IN_PROCESS='T'  
        AND   B.CASH_FLAG='T' 
        AND   O.BLOCK_FLAG<>'T' 
        ;

    EXCEPTION
        WHEN OTHERS THEN
         p_error_code := SQLCODE;
         p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
         p_error_flag := 'S';


 end  SP_TRANSFER_CUENTA_CAMPANIA;
/

