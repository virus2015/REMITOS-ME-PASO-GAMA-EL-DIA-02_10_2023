create procedure sp_transfer_bank_codes
(	p_transfer_flag  out char,
    p_error_flag out varchar2,
    p_error_code out varchar2,
    p_error_message out varchar2
 )
is
    p_BANK_CODE CHAR(3 BYTE); 
	p_BANK_NAME VARCHAR2(50 BYTE); 
	p_CASH_FLAG CHAR(1 BYTE); 
	p_CHANGE_FLAG CHAR(1 BYTE); 
	p_DELETE_FLAG CHAR(1 BYTE); 
	p_UPDATED_AT TIMESTAMP (6); 
begin
    SELECT 
        bank_code, bank_name, cash_flag, change_flag, delete_flag, updated_at
    INTO
        p_bank_code, p_bank_name, p_cash_flag, p_change_flag, p_delete_flag, p_updated_at
    FROM BANK_CODES;

      p_transfer_flag := 1;
    --UPDATE BANK_CODES SET transfer_flag = 1;
    --COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
         p_error_code := SQLCODE;
         p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
         p_error_flag := 'S';


 end sp_transfer_bank_codes;
/

