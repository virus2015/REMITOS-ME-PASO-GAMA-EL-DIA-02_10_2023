create procedure sp_ins_zone_dms
(	zone_id       in number, 
	zone_status   in number, 
	is_border     in char,
    inserted_row out number,
    p_error_flag out varchar2,
    p_error_code out varchar2,
    p_error_message out varchar2
) is

BEGIN

p_error_flag := 'N';

    insert into zone (ZONE_ID,ZONE_STATUS,IS_BORDER) values
    (	zone_id, 
        zone_status, 
        is_border
    );

    EXCEPTION
          WHEN OTHERS THEN
             p_error_code := SQLCODE;
             p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
             p_error_flag := 'S';
             inserted_row := 1;

end sp_ins_zone_dms;
/

