create PACKAGE BODY         PCK_DELETE_DATA
AS
    FUNCTION FN_ITERATION (PA_OWNER VARCHAR2)
        RETURN NUMBER
    IS
        V_ITERATION     NUMBER (10);
        V_C_ITERATION   NUMBER (1);    --- CUENTA MOMENTO DE EJEUCIÓN EN TABLA
        V_OWNER         VARCHAR2 (40) := PA_OWNER;

        PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
        SELECT COUNT (*)
          INTO V_C_ITERATION
          FROM DBA_DMS.DEP_ITERATIONS
         WHERE STATUS = 1 AND TABLE_OWNER = V_OWNER;

        IF V_C_ITERATION = 0
        THEN
              INSERT INTO DBA_DMS.DEP_ITERATIONS@SCPIP (ITERATION_ID,
                                                     FULL_CAMPAIGN,
                                                     TABLE_OWNER)
                SELECT DBA_DMS.DEP_ITERATIONS_SEQ.NEXTVAL,
                       FULL_CAMPAIGN,
                       V_OWNER
                  FROM (  SELECT (CAMPAIGN_YEAR * 100 + CAMPAIGN) - 100     FULL_CAMPAIGN
                          FROM DBA_DMS.CAMPAIGNS
                          WHERE     CURRENT_TIMESTAMP BETWEEN START_DATE AND END_DATE
                         AND CAMPAIGN BETWEEN 1 AND 20);
            COMMIT;
        END IF;

        SELECT ITERATION_ID
          INTO V_ITERATION
          FROM DBA_DMS.DEP_ITERATIONS
         WHERE STATUS = 1 AND TABLE_OWNER = V_OWNER;             -- EN PROCESO

        RETURN V_ITERATION;
    END;

    -------------------------------------------------------------------------------------------
    PROCEDURE SP_BACKUP_DELETE (PA_DELETE_DATA_ID   IN     NUMBER, --- ID DELETE_DATA
                                PA_ITERATION_ID     IN     NUMBER, ---- ID DE ITERACIÓN
                                PA_TABLE_NAME       IN     VARCHAR2, ---NOMBRE DE LA TABLA
                                PA_GROUPED_BY       IN     NUMBER,    ---GRUPO
                                PA_SQL_DELETE       IN     VARCHAR2, ---SELECT COUNT DATOS DE RESPALDO
                                PA_EXCUTE_VAR       IN     VARCHAR2, ---VARIABLE PARA TIPO DE DEPURACIÓN
                                PA_EXECUTION           OUT NUMBER, --  1 - TODO OK, 0 - ALGO SALÍO MAL
                                PA_PROCESS             OUT VARCHAR2, -- IMPRIME LOG
                                PA_ROWCOUNT            OUT NUMBER -- IMPRIME CONTEO DE DATOS A ELIMINAR
                                                                 )
    AS
        V_ROWCOUNT                  NUMBER (20) := 0; --- CUENTA DATOS DE SELECCIÓN PARA EL BORRADO
        V_EXECUTION                 NUMBER (1) := 0;       --- PROCESO APAGADO
        V_PROCESS                   VARCHAR2 (500) := 'NO SE INICIO EL PROCESO';
        V_SQL_DELETE                VARCHAR2 (4000) := PA_SQL_DELETE; ---SELECT DE BORRADO
        V_SQL_CONFIRMA              VARCHAR2 (4000)
                                        := REPLACE (V_SQL_DELETE, '*', 'COUNT (*)'); --- SELECT DE CONTEO DE DATOS PARA BORRADO
        V_TABLE_NAME       CONSTANT VARCHAR2 (80) := PA_TABLE_NAME; --- NOMRE DE TABLA PARA BORRAR DATOS
        V_ITERATION_ID     CONSTANT NUMBER (10) := PA_ITERATION_ID; --- ID DE ITERACIÓN
        V_DELETE_DATA_ID   CONSTANT NUMBER (8) := PA_DELETE_DATA_ID; --- ID DE LA TABLA
        V_GROUPED_BY       CONSTANT NUMBER (8) := PA_GROUPED_BY;
        V_COUNT_ALL                 VARCHAR2 (4000)
            := 'SELECT COUNT (*) FROM ' || PA_TABLE_NAME; --- SELECT DE CONTEO DE TODA LA TABLA
        V_C_COUNT_ALL               NUMBER (20) := 0; --- CONTEO DE TODA LA TABLA
        V_EXCUTE_VAR                VARCHAR2 (80) := PA_EXCUTE_VAR; --- VARIABLE PARA EXECUTAR EL SELECT
        V_SEL_CONFIRMA              VARCHAR2 (4000); --- SELECT DE CONTEO VS REGISTROS DE TABLA DE RESPALDO
        V_C_SQL_DELETE              NUMBER (20) := 0; --- VALIDA SCRIPT MAYOR A 0
        V_C_SQL_DELETE2             NUMBER (20) := 0; --- VALIDA NUMERO DE REGISTROS IGUAL AL CONTEO
        V_SQL_TABLE_2               VARCHAR2 (4000); --- NOMBRE DE NUEVA TABLA
        V_FULLCAMPAIGN              NUMBER (6); ---  DATOS DE CAMPAÑA PARA BORRADO
        V_TABLE_NAME_2              VARCHAR2 (200)
                                        := PA_TABLE_NAME || '_DEL_TBL'; ---Reasigna nombre para la tabla temporal para el respaldo
        V_EXIST_TABLE               NUMBER (1) := 0;
        V_CMP_TRUNCATE     CONSTANT VARCHAR2 (20) := ' WHERE ROWNUM >0';
        V_C_DEPENDENCY              NUMBER (3) := 0;    ---CUENTA DEPENDENCIAS
        V_EXISTS_CASCADE            NUMBER (3); ---TIENE RESTRICCIONES EN CASCADA
        V_EXECUTED_AT               VARCHAR2 (80);
    BEGIN
        --- VALIDA TABLAS EN DELETE_DATA VS CONSULTA POR RESTRICCIONES
        SELECT COUNT (c.TABLE_NAME)
          INTO V_C_DEPENDENCY
          FROM all_cons_columns  cC
               INNER JOIN all_constraints c
                   ON     c.r_constraint_name = cc.constraint_name
                      AND c.r_owner = cc.owner
                      AND cc.owner = USER
                      AND cc.table_name = V_TABLE_NAME
                      AND c.table_name NOT IN
                              (SELECT TABLE_NAME
                                 FROM DBA_DMS.DEP_DELETE_DATA
                                WHERE TABLE_OWNER = USER AND STATUS = 1);

        IF V_C_DEPENDENCY <> 0
        THEN                        ----FALTA DETALLE DE DEPENDENCIAS EN TABLA
            V_EXECUTION := 0;                              --- PROCESO APAGADO
            V_PROCESS :=
                   'NO SE INICIO EL PROCESO. FALTA DETALLE DE DEPENDENCIAS EN TABLA: '
                || V_TABLE_NAME;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
                   'NO SE INICIO EL PROCESO. FALTA DETALLE DE DEPENDENCIAS EN TABLA: '
                || V_TABLE_NAME,
                SQLCODE,
                SQLERRM);
        ELSE                                 --- VALIDA CONSTRAINTS EN CASCADA
            SELECT COUNT (*)
              INTO V_EXISTS_CASCADE
              FROM all_constraints c
             WHERE     owner = USER
                   AND table_name = V_TABLE_NAME
                   AND DELETE_RULE = 'CASCADE';

            IF V_EXISTS_CASCADE > 0
            THEN
                V_EXECUTION := 0;                          --- PROCESO APAGADO
                V_PROCESS :=
                       'NO SE INICIO EL PROCESO. EXISTEN RESTRICCIONES EN CASCADA EN: '
                    || V_TABLE_NAME;
                DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                    'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
                       'NO SE INICIO EL PROCESO. EXISTEN RESTRICCIONES EN CASCADA EN: '
                    || V_TABLE_NAME,
                    SQLCODE,
                    SQLERRM);
            ELSE
                IF V_EXCUTE_VAR = 'V_FULLCAMPAIGN_DEL'
                THEN                                     --- POR FULL CAMPAING
                    SELECT FULL_CAMPAIGN
                      INTO V_FULLCAMPAIGN
                      FROM DBA_DMS.DEP_ITERATIONS I
                     WHERE I.ITERATION_ID = V_ITERATION_ID;

                    -----REMPLAZA FULLCAMPAIGN
                    SELECT REGEXP_REPLACE (V_SQL_DELETE,
                                           'V_FULLCAMPAIGN_DEL', ---VARIBLE EN SELECT
                                           V_FULLCAMPAIGN)
                      INTO V_SQL_DELETE
                      FROM DBA_DMS.DEP_DELETE_DATA
                     WHERE delete_data_id = V_DELETE_DATA_ID;

                    SELECT REGEXP_REPLACE (V_SQL_CONFIRMA,
                                           'V_FULLCAMPAIGN_DEL',
                                           V_FULLCAMPAIGN)
                      INTO V_SQL_CONFIRMA
                      FROM DBA_DMS.DEP_DELETE_DATA
                     WHERE delete_data_id = V_DELETE_DATA_ID;
                ELSIF V_EXCUTE_VAR = 'V_TRUNCATE'
                THEN
                    V_SQL_DELETE := PA_SQL_DELETE || V_CMP_TRUNCATE;
                    V_SQL_CONFIRMA := V_SQL_CONFIRMA || V_CMP_TRUNCATE;
                ELSIF V_EXCUTE_VAR = 'V_SELECT'
                THEN
                    V_SQL_DELETE := PA_SQL_DELETE;

                    ---- CONSULTA LA FECHA DE INICIO DEL PROCESO DE ITERACIÓN
                    SELECT TO_CHAR (
                                  'TO_DATE('''
                               || (TO_CHAR (EXECUTED_AT, 'YYYY/MM/DD'))
                               || ''',''YYYY/MM/DD'')')
                      INTO V_EXECUTED_AT
                      FROM DBA_DMS.DEP_ITERATIONS I
                     WHERE I.ITERATION_ID = V_ITERATION_ID;

                    SELECT REGEXP_REPLACE (V_SQL_DELETE,
                                           'SYSDATE',
                                           V_EXECUTED_AT)
                      INTO V_SQL_DELETE
                      FROM DBA_DMS.DEP_DELETE_DATA
                     WHERE delete_data_id = V_DELETE_DATA_ID;

                    SELECT REGEXP_REPLACE (V_SQL_CONFIRMA,
                                           'SYSDATE',
                                           V_EXECUTED_AT)
                      INTO V_SQL_CONFIRMA
                      FROM DBA_DMS.DEP_DELETE_DATA
                     WHERE delete_data_id = V_DELETE_DATA_ID;
                ELSE
                    V_EXECUTION := 0;                      --- PROCESO APAGADO
                    V_PROCESS := 'VARIABLE NO RECONOCIDA: ' || V_SQL_DELETE;
                    DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                        'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
                        'VARIABLE NO RECONOCIDA: ' || V_SQL_DELETE,
                        SQLCODE,
                        SQLERRM);
                END IF;

                ---Valida que haya datos en la tabla original para el respaldo

                EXECUTE IMMEDIATE V_SQL_CONFIRMA INTO V_C_SQL_DELETE;

                ---Si la tabla tiene datos
                DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                    'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
                    PA_TABLE_NAME || ' # DE REG RESP:' || V_C_SQL_DELETE,
                    SQLCODE,
                    SQLERRM);

                IF V_C_SQL_DELETE > 0 ---SI HAY REGISTROS PARA RESPALDO Y EL SELECT ES CORRECTO VALIDA QUE NO EXISTA LA TABLA DUPLICADA
                THEN                   ---Valida que no existe tabla duplicada
                    V_ROWCOUNT := V_C_SQL_DELETE;

                    SELECT COUNT (*)
                      INTO V_EXIST_TABLE
                      FROM USER_TABLES
                     WHERE TABLE_NAME = V_TABLE_NAME_2;

                    IF V_EXIST_TABLE = 0      ---SI LA TABLA NO EXISTE LA CREA
                    THEN
                        V_SQL_TABLE_2 :=
                               'CREATE TABLE '
                            || V_TABLE_NAME_2
                            || ' AS '
                            || V_SQL_DELETE;

                        EXECUTE IMMEDIATE V_SQL_TABLE_2;

                        COMMIT;

                        ---INSERTA EN LOG DE BACKUP PARA INICIO DE PROCESO PARA EL GRUPO

                        DBA_DMS.PCK_DELETE_DATA_UTILS.SP_DELETING_LOG (
                            V_GROUPED_BY,                  ---SI GRUPO ID NULL
                            NULL,                          ---SI ID GRUPO NULL
                            V_ITERATION_ID,                       ---ITERACIÓN
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            0);
                        COMMIT;
                        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                            'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_BACKUP_DELETE',
                               'SE INSERTÓ O ACTUALIZÓ A CERO LOG DEL GRUPO: '
                            || V_GROUPED_BY
                            || ' EN LA ITERACIÓN '
                            || V_ITERATION_ID,
                            SQLCODE,
                            SQLERRM);

                        COMMIT;

                        -----ACTUALIZA LOG PARA GUARDAR ESTAMP DE TIEMPO DE INICIO DEL PROCESO DE LA TABLA
                        UPDATE DBA_DMS.DEP_DELETING_LOG
                           SET START_PROCESS =
                                   CURRENT_TIMESTAMP
                                       AT TIME ZONE 'America/Mexico_City'
                         WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                               AND ITERATION_ID = V_ITERATION_ID;

                        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                            'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
                            'SE CREA:' || V_SQL_TABLE_2,
                            SQLCODE,
                            SQLERRM);

                        COMMIT;
                    ELSE ---SI LA TABLA YA EXISTE COMPLETA RESPALDO A PARTIR DEL SELECT
                        V_SQL_TABLE_2 :=
                               'INSERT INTO '
                            || V_TABLE_NAME_2
                            || ' '
                            || V_SQL_DELETE
                            || ' AND NOT EXISTS ( SELECT * FROM '
                            || V_TABLE_NAME_2
                            || ')';

                        ---INSERTA EN LOG DE BACKUP PARA INICIO DE PROCESO PARA EL GRUPO

                        DBA_DMS.PCK_DELETE_DATA_UTILS.SP_DELETING_LOG (
                            V_GROUPED_BY,                  ---SI GRUPO ID NULL
                            NULL,                          ---SI ID GRUPO NULL
                            V_ITERATION_ID,                       ---ITERACIÓN
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            NULL,                                     --- NULL
                            0);
                        COMMIT;
                        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                            'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_BACKUP_DELETE',
                               'SE INSERTÓ O ACTUALIZÓ A CERO LOG DEL GRUPO: '
                            || V_GROUPED_BY
                            || ' EN LA ITERACIÓN '
                            || V_ITERATION_ID,
                            SQLCODE,
                            SQLERRM);

                        COMMIT;

                        -----ACTUALIZA LOG PARA GUARDAR ESTAMP DE TIEMPO DE INICIO DEL PROCESO DE LA TABLA
                        UPDATE DBA_DMS.DEP_DELETING_LOG
                           SET START_PROCESS =
                                   CURRENT_TIMESTAMP
                                       AT TIME ZONE 'America/Mexico_City'
                         WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                               AND ITERATION_ID = V_ITERATION_ID;

                        COMMIT;
                        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                            'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_BACKUP_DELETE',
                               'SE INICIÓ EL PROCESO DEPURACIÓN DE LA TABLA: '
                            || V_TABLE_NAME
                            || ' ID:'
                            || V_DELETE_DATA_ID
                            || ', ITERA:'
                            || V_ITERATION_ID,
                            SQLCODE,
                            SQLERRM);


                        EXECUTE IMMEDIATE V_SQL_TABLE_2;

                        COMMIT;
                        --------------- INSERTA DATOS QUE FALTAN PARA COMPLETAR RESPALDO
                        V_EXECUTION := 1;                --- PROCESO ENCENDIDO
                        V_PROCESS :=
                            'LA TABLA YA EXISTE. SE COMPLEMENTA INSERCIÓN DE DATOS';
                        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                            'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
                               'LA TABLA YA EXISTE. SE COMPLEMENTA INSERCIÓN DE DATOS:'
                            || V_TABLE_NAME_2,
                            SQLCODE,
                            SQLERRM);
                    END IF;

                    V_SEL_CONFIRMA :=
                        'SELECT COUNT (*) from ' || V_TABLE_NAME_2;

                    EXECUTE IMMEDIATE V_SEL_CONFIRMA INTO V_C_SQL_DELETE2;

                    EXECUTE IMMEDIATE V_COUNT_ALL INTO V_C_COUNT_ALL;

                    IF V_C_SQL_DELETE2 = V_C_SQL_DELETE -- VALIDA RESGISTROS DE RESPALDO
                    THEN
                        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                            'DBA_DMS.PCK_DELETE_DATA_UTILS.SP_BACKUP_DELETE',
                               'SE INICIÓ EL PROCESO DEPURACIÓN DE LA TABLA: '
                            || V_TABLE_NAME
                            || ' ID:'
                            || V_DELETE_DATA_ID
                            || ', ITERA:'
                            || V_ITERATION_ID,
                            SQLCODE,
                            SQLERRM);
                        COMMIT;

                        -----ACTUALIZA LOG  PROCESO DE RECUPERACIÓN EXITOSA DE LA TABLA
                        UPDATE DBA_DMS.DEP_DELETING_LOG
                           SET SUCCESSFUL_BACKUP =
                                   CURRENT_TIMESTAMP
                                       AT TIME ZONE 'America/Mexico_City', --- BACKUP OK
                               STARTING_DATA_COUNT = V_C_COUNT_ALL, --- CONTEO DE DATOS TOTAL
                               DELETING_DATA_COUNT = V_C_SQL_DELETE --- CONTEO DE DATOS DELETE
                         WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                               AND ITERATION_ID = V_ITERATION_ID;

                        COMMIT;
                        V_EXECUTION := 1;                --- PROCESO ENCENDIDO
                        V_PROCESS :=
                               'COMPRUEBA # DE REGISTROS IGUALES:'
                            || PA_TABLE_NAME
                            || '='
                            || V_TABLE_NAME_2
                            || ' REGISTROS';
                        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                            'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
                               'COMPRUEBA # DE REGISTROS IGUALES:'
                            || PA_TABLE_NAME
                            || '= T2 '
                            || V_TABLE_NAME_2
                            || ' REGISTROS',
                            SQLCODE,
                            SQLERRM);
                    ELSE
                        V_EXECUTION := 0;                  --- PROCESO APAGADO
                        V_PROCESS :=
                               'LOS REGISTROS SON DIFERENTES '
                            || V_C_SQL_DELETE2
                            || '='
                            || V_C_SQL_DELETE
                            || ' NO SE PUEDE REALIZAR EL BORRADO DE DATOS';
                        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                            'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
                               'LOS REGISTROS SON DIFERENTES '
                            || V_C_SQL_DELETE2
                            || '='
                            || V_C_SQL_DELETE
                            || ' NO SE PUEDE REALIZAR EL BORRADO',
                            SQLCODE,
                            SQLERRM);
                    END IF;
                --- SELECT INCORRECTO O NO SE ENECONTRARON DATOS
                ELSE
                    V_EXECUTION := 2;                                      ---
                    V_PROCESS :=
                           'EL PROCESO FUE EXITOSO. NO SE ENCONTRARON DATOS: '
                        || V_C_SQL_DELETE;
                    DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                        'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
                           'EL PROCESO FUE EXITOSO. NO SE ENCONTRARON DATOS: '
                        || V_C_SQL_DELETE,
                        SQLCODE,
                        SQLERRM);
                END IF;
            END IF;
        END IF;

        COMMIT;
        PA_EXECUTION := V_EXECUTION;
        PA_PROCESS := V_PROCESS;
        PA_ROWCOUNT := V_ROWCOUNT;
        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
            'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
            'ÉXITO EN CREACIÓN DE RESPALDO: ' || PA_TABLE_NAME,
            SQLCODE,
            SQLERRM);
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            PA_EXECUTION := V_EXECUTION;
            PA_PROCESS := V_PROCESS;
            PA_ROWCOUNT := V_ROWCOUNT;
            ROLLBACK;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
                   'TABLA: '
                || PA_TABLE_NAME
                || ', SCRIPT DE BORRADO: '
                || PA_SQL_DELETE
                || ', EJECUCIÓN: '
                || PA_EXECUTION
                || ', PROCESO: '
                || PA_PROCESS,
                SQLCODE,
                SQLERRM);
        WHEN OTHERS
        THEN
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA.SP_BACKUP_DELETE',
                   'TABLA: '
                || PA_TABLE_NAME
                || ', SCRIPT DE BORRADO: '
                || PA_SQL_DELETE
                || ', EJECUCIÓN: '
                || PA_EXECUTION
                || ', PROCESO: '
                || PA_PROCESS,
                SQLCODE,
                SQLERRM);
            PA_EXECUTION := V_EXECUTION;
            PA_PROCESS := V_PROCESS;
            PA_ROWCOUNT := V_ROWCOUNT;
            ROLLBACK;
    END SP_BACKUP_DELETE;

    -----------------------------------*****************************************************-------------------------------------
    PROCEDURE SP_DELETE_DATA (PA_DELETE_DATA_ID   IN     NUMBER,         ---ID
                              PA_ITERATION_ID     IN     NUMBER, ---- ITERACIÓN
                              PA_TABLE_NAME       IN     VARCHAR2, ---NOMBRE DE LA TABLA
                              PA_SQL_DELETE       IN     VARCHAR2, ---SELECT COUNT DATOS DE RESPALDO
                              PA_EXCUTE_VAR       IN     VARCHAR2, ---VARIABLE PARA TIPO DE DEPURACIÓN
                              PA_EXECUTION           OUT NUMBER, --  1 - TODO OK, 0 - ALGO SALÍO MAL
                              PA_PROCESS             OUT VARCHAR2 -- IMPRIME LOG
                                                                 )
    AS
        V_DELETE_DATA_ID   CONSTANT NUMBER (8) := PA_DELETE_DATA_ID; --- ID DE LA TABLA
        V_ITERATION_ID     CONSTANT NUMBER (10) := PA_ITERATION_ID; --- ID DE LA TABLA
        V_EXECUTION                 NUMBER (1) := 0;       --- PROCESO APAGADO
        V_PROCESS                   VARCHAR2 (500)
                                        := 'NO SE INICIO EL PROCESO';
        V_SQL_DELETE                VARCHAR2 (4000) := PA_SQL_DELETE; ---SELECT DE BORRADO
        V_COUNT_ALL                 VARCHAR2 (4000)
            := 'SELECT COUNT (*) FROM ' || PA_TABLE_NAME; --- SELECT DE CONTEO DE TODA LA TABLA
        V_C_COUNT_ALL               NUMBER (20) := 0; --- CONTEO DE TODA LA TABLA DESPÚES DE LA ELIMINACIÓN DE DATOS
        V_EXCUTE_VAR                VARCHAR2 (80) := PA_EXCUTE_VAR; --- VARIABLE PARA EXECUTAR EL SELECT
        V_TABLE_NAME                VARCHAR2 (200) := PA_TABLE_NAME; ---TABLA PARA BORRADO
        V_C_SQL_DELETE              NUMBER (20) := 0; --- VALIDA SCRIPT MAYOR A 0
        V_C_SQL_DELETE2             NUMBER (20) := 0; --- VALIDA NUMERO DE REGISTROS IGUAL AL CONTEO
        V_FULLCAMPAIGN              NUMBER (6); ---  DATOS DE CAMPAÑA PARA BORRADO
        V_TABLE_NAME_2              VARCHAR2 (200)
                                        := PA_TABLE_NAME || '_DEL_TBL'; ---Reasigna nombre para la tabla temporal para el respaldo
        V_EXECUTED_AT               VARCHAR2 (80);

        V_C_SQL_DELETE_T2           NUMBER (20) := 0; -- CANTIDAD DE DATOS EN TABLA DE RESPALDO
        V_REPLEACE_SEL              VARCHAR2 (4000); ---REMPLAZA SELECT * POR DELETE
        V_DROP_TABLE                VARCHAR2 (300);      --- SCRIPT DE BORRADO
        V_SQL_CONFIRMA              VARCHAR2 (4000)
            := REPLACE (V_SQL_DELETE, '*', 'COUNT (*)'); --- SELECT DE CONTEO PARA LA CONFIRMACIÓN DEL TOTAL DE REGISTROS
        V_SQL_CONFIRMA_T2           VARCHAR2 (1000)
            := 'SELECT COUNT (*) FROM ' || V_TABLE_NAME_2; --- SELECT DE CONTEO PARA LA CONFIRMACIÓN DEL TOTAL DE REGISTROS EN TABLA _DEL_TBL
            V_SQL_CONFIRMA_C          NUMBER (20) := 0; -- CANTIDAD DE DATOS EN TABLA PARA ITERAR LOS MAYORES A 10 MILLONES  
    BEGIN
        ---- CONSULTA LA CAMPAÑA PARA BORRADO
        SELECT FULL_CAMPAIGN
          INTO V_FULLCAMPAIGN
          FROM DBA_DMS.DEP_ITERATIONS I
         WHERE ITERATION_ID = V_ITERATION_ID;

        IF V_EXCUTE_VAR = 'V_FULLCAMPAIGN_DEL'
        THEN                                             --- POR FULL CAMPAING
            -----REMPLAZA FULLCAMPAIGN
            SELECT REGEXP_REPLACE (V_SQL_DELETE,
                                   'V_FULLCAMPAIGN_DEL',  ---VARIBLE EN SELECT
                                   V_FULLCAMPAIGN)
              INTO V_SQL_DELETE
              FROM DBA_DMS.DEP_DELETE_DATA
             WHERE delete_data_id = V_DELETE_DATA_ID;

            SELECT REGEXP_REPLACE (V_SQL_CONFIRMA,
                                   'V_FULLCAMPAIGN_DEL',
                                   V_FULLCAMPAIGN)
              INTO V_SQL_CONFIRMA
              FROM DBA_DMS.DEP_DELETE_DATA
             WHERE delete_data_id = V_DELETE_DATA_ID;
        ------------
        ELSIF V_EXCUTE_VAR = 'V_SELECT'
        THEN                                                    --- POR SELECT
            SELECT TO_CHAR (
                          'TO_DATE('''
                       || (TO_CHAR (EXECUTED_AT, 'YYYY/MM/DD'))
                       || ''',''YYYY/MM/DD'')')
              INTO V_EXECUTED_AT
              FROM DBA_DMS.DEP_ITERATIONS I
             WHERE I.ITERATION_ID = V_ITERATION_ID;

            SELECT REGEXP_REPLACE (V_SQL_DELETE, 'SYSDATE', V_EXECUTED_AT)
              INTO V_SQL_DELETE
              FROM DBA_DMS.DEP_DELETE_DATA
             WHERE delete_data_id = V_DELETE_DATA_ID;

            SELECT REGEXP_REPLACE (V_SQL_CONFIRMA, 'SYSDATE', V_EXECUTED_AT)
              INTO V_SQL_CONFIRMA
              FROM DBA_DMS.DEP_DELETE_DATA
             WHERE delete_data_id = V_DELETE_DATA_ID;
        END IF;

        --- COMPARA EL CONTEO DE DATOS
        EXECUTE IMMEDIATE V_SQL_CONFIRMA INTO V_C_SQL_DELETE;

        EXECUTE IMMEDIATE V_SQL_CONFIRMA_T2 INTO V_C_SQL_DELETE_T2;

        IF V_C_SQL_DELETE = V_C_SQL_DELETE_T2
        THEN                                 ---BORRA DATOS EN TABLA PRINCIPAL
            IF    V_EXCUTE_VAR = 'V_FULLCAMPAIGN_DEL'
               OR V_EXCUTE_VAR = 'V_SELECT'
            THEN
                SELECT    (SELECT REPLACE (
                                      REPLACE (
                                          UPPER (
                                              SUBSTR (
                                                  V_SQL_DELETE,
                                                  1,
                                                  (SELECT INSTR (
                                                              V_SQL_DELETE,
                                                              '*',
                                                              1,
                                                              1)
                                                     FROM DUAL))),
                                          'SELECT ',
                                          'DELETE'),
                                      '*',
                                      '')
                             FROM DUAL)
                       || (SELECT (SUBSTR (V_SQL_DELETE,
                                             (INSTR (V_SQL_DELETE,
                                                     '* ',
                                                     1,
                                                     1))
                                           + 1))
                             FROM DUAL)
                  INTO V_REPLEACE_SEL
                  FROM DUAL;
            ELSIF V_EXCUTE_VAR = 'V_TRUNCATE'
            THEN
                V_REPLEACE_SEL := 'TRUNCATE TABLE ' || V_TABLE_NAME;
            ELSE
                V_EXECUTION := 0;
                V_PROCESS :=
                    'NO SE ENCONTRÓ NIGUNA VARIABLE: ' || V_EXCUTE_VAR;
            END IF;

            ---ACTUALIZA EN LOG INICIO DE DELETE
            UPDATE DBA_DMS.DEP_DELETING_LOG
               SET START_DELETE =
                       CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City'
             WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                   AND ITERATION_ID = V_ITERATION_ID;

            COMMIT;
            
            IF  V_EXCUTE_VAR = 'V_TRUNCATE'
            THEN 
            EXECUTE IMMEDIATE V_REPLEACE_SEL; ---- BORRA TODO SI DEBE TRUNCAR
            ELSE 
            IF V_C_SQL_DELETE < 10000000 
            THEN 
            EXECUTE IMMEDIATE V_REPLEACE_SEL; ---- BORRA TODO SI ES MENOR A 20 MILLONES
            ELSE 
            V_REPLEACE_SEL := V_REPLEACE_SEL || ' AND ROWNUM <= 10000000';
            
           
            ---- BORRA POR BLOQUES
            BEGIN
              EXECUTE IMMEDIATE V_SQL_CONFIRMA INTO V_SQL_CONFIRMA_C;
            
              WHILE (V_SQL_CONFIRMA_C > 0) LOOP
                EXECUTE IMMEDIATE V_REPLEACE_SEL      ; --- BORRA LOS PRIMEROS 10 MILLONES
            
                COMMIT;--- LIBERA EAPACIO EN EL UNDO
                EXECUTE IMMEDIATE V_SQL_CONFIRMA INTO V_SQL_CONFIRMA_C;
              END LOOP;
            END;
            
           

            EXECUTE IMMEDIATE V_COUNT_ALL INTO V_C_COUNT_ALL;

            ---ACTUALIZA CONTEO DE DATOS EN TABLA DESPUÉS DEL BORRADO Y DELETE EXITOSO
            UPDATE DBA_DMS.DEP_DELETING_LOG
               SET SUCCESSFUL_DELETE =
                       CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City',
                   REMAINING_DATA_COUNT = V_C_COUNT_ALL
             WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                   AND ITERATION_ID = V_ITERATION_ID;

            COMMIT;

            -----INSERTA ÍNDICES
            INSERT INTO DBA_DMS.DEP_REBUILDING_INDEX (REBUILDINGINDEX_ID,
                                                      DELETE_DATA_ID,
                                                      ITERATION_ID,
                                                      CONSTRAINT_NAME)
                SELECT DBA_DMS.DEP_REBUILDING_INDEX_SEQ.NEXTVAL,
                       V_DELETE_DATA_ID,
                       V_ITERATION_ID,
                       INDEX_NAME
                  FROM all_indexes c
                 WHERE owner = USER AND TABLE_NAME = V_TABLE_NAME;

            COMMIT;

            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA.SP_DELETE_DATA',
                   'SE ELIMINARON '
                || V_C_SQL_DELETE
                || ' REG EN: '
                || V_TABLE_NAME,
                SQLCODE,
                SQLERRM);
            /* V_DROP_TABLE := 'DROP TABLE ' || V_TABLE_NAME_2;

             EXECUTE IMMEDIATE V_DROP_TABLE;*/

            V_EXECUTION := 1;                              --- PROCESO ÉXITOSO
            V_PROCESS :=
                   'SE ELIMINARON '
                || V_C_SQL_DELETE
                || ' REG EN: '
                || V_TABLE_NAME
                || ', SE ELIMINÓ TABLA '
                || V_TABLE_NAME_2;

            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA.SP_DELETE_DATA',
                'SE ELIMINÓ TABLA ' || V_TABLE_NAME_2,
                SQLCODE,
                SQLERRM);
                END IF;
        END IF;
        ELSE
            V_EXECUTION := 0;                              --- PROCESO APAGADO
            V_PROCESS :=
                   'LOS CONTEOS EN TABLA SON DIFERENTES '
                || V_C_SQL_DELETE2
                || '='
                || V_C_SQL_DELETE
                || ', NO SE PUEDE REALIZAR EL BORRADO';
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA.SP_DELETE_DATA',
                   'LOS CONTEOS EN TABLA SON DIFERENTES'
                || V_C_SQL_DELETE2
                || '='
                || V_C_SQL_DELETE
                || ' NO SE PUEDE REALIZAR EL BORRADO',
                SQLCODE,
                SQLERRM);
        
        END IF;
        COMMIT;
        PA_EXECUTION := V_EXECUTION;
        PA_PROCESS := V_PROCESS;
        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
            'DBA_DMS.PCK_DELETE_DATA.SP_DELETE_DATA',
               'ÉXITO EN EL PROCESO DE BORRADO: '
            || PA_TABLE_NAME
            || ', SCRIPT DE BORRADO: '
            || PA_SQL_DELETE,
            SQLCODE,
            SQLERRM);
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            PA_EXECUTION := V_EXECUTION;
            PA_PROCESS := V_PROCESS;
            ROLLBACK;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA.SP_DELETE_DATA',
                   'TABLA: '
                || PA_TABLE_NAME
                || ', SCRIPT DE BORRADO: '
                || PA_SQL_DELETE
                || ', EJECUCIÓN: '
                || PA_EXECUTION
                || ', PROCESO: '
                || PA_PROCESS,
                SQLCODE,
                SQLERRM);
        WHEN OTHERS
        THEN
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA.SP_DELETE_DATA',
                   'TABLA: '
                || PA_TABLE_NAME
                || ', SCRIPT DE BORRADO: '
                || PA_SQL_DELETE
                || ', EJECUCIÓN: '
                || PA_EXECUTION
                || ', PROCESO: '
                || PA_PROCESS,
                SQLCODE,
                SQLERRM);
            PA_EXECUTION := V_EXECUTION;
            PA_PROCESS := V_PROCESS;
            ROLLBACK;
    END SP_DELETE_DATA;

    -----------------------------------*****************************************************-------------------------------------

    PROCEDURE SP_INDEX_TABLE (PA_REBUILDINGINDEX_ID   IN     NUMBER, ----ID  DE RECONSTRUCCIÓN DE ÍNDICES
                              PA_DELETE_DATA_ID       IN     NUMBER,     ---ID
                              PA_ITERATION_ID         IN     NUMBER, ----ITERACION
                              PA_TABLE_NAME           IN     VARCHAR2, ------NOMBRE DE LA TABLA
                              PA_CONSTRAINT_NAME      IN     VARCHAR2, ---NOMBRE DEL ÍNDICE
                              PA_EXECUTION               OUT NUMBER, --  1 - TODO OK, 0 - ALGO SALÍO MAL
                              PA_PROCESS                 OUT VARCHAR2 -- IMPRIME LOG
                                                                     )
    AS
        V_REBUILDINGINDEX_ID   CONSTANT NUMBER (20) := PA_REBUILDINGINDEX_ID; ----ID  DE RECONSTRUCCIÓN DE ÍNDICES
        V_DELETE_DATA_ID       CONSTANT NUMBER (8) := PA_DELETE_DATA_ID; ---ID
        V_ITERATION            CONSTANT NUMBER (10) := PA_ITERATION_ID; ----ITERACION
        V_INDEX                CONSTANT VARCHAR2 (150) := PA_CONSTRAINT_NAME; ---NOMBRE DEL ÍNDICE
        V_TABLE_NAME                    VARCHAR2 (80) := PA_TABLE_NAME; ------NOMBRE DE LA TABLA
        V_EXECUTION                     NUMBER (1) := 0;   --- PROCESO APAGADO
        V_PROCESS                       VARCHAR2 (500)
                                            := 'NO SE INICIO EL PROCESO';
        V_ALTER_INDEX                   VARCHAR (2500);
        V_C_INDEX                       NUMBER (3) := 0;
    BEGIN
        V_ALTER_INDEX := 'ALTER INDEX ' || V_INDEX || ' REBUILD';



        EXECUTE IMMEDIATE V_ALTER_INDEX;                 -- RECONSTRUYE ÍNDÍCE

        UPDATE DBA_DMS.DEP_REBUILDING_INDEX
           SET STATUS = 'R',
               REBUILDING_DATE =
                   CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City'
         WHERE REBUILDINGINDEX_ID = V_REBUILDINGINDEX_ID; --- ACTUALIZA ESTATUS

        COMMIT;
        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
            'DBA_DMS.PCK_DELETE_DATA.SP_INDEX_TABLE',
               'SE RECONSTRUYÓ EL ÍNDICE '
            || V_INDEX
            || ' DE LA TABLA: '
            || V_TABLE_NAME
            || ',REBUILDINGINDEX_ID: '
            || V_REBUILDINGINDEX_ID,
            SQLCODE,
            SQLERRM);

        SELECT COUNT (*)
          INTO V_C_INDEX
          FROM DBA_DMS.DEP_REBUILDING_INDEX
         WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
               AND ITERATION_ID = V_ITERATION
               AND STATUS = 'N';

        IF V_C_INDEX = 0
        THEN
            ---ACTUALIZA EN LOG DE DELETE EXITOSO
            UPDATE DBA_DMS.DEP_DELETING_LOG
               SET SUCCESSFUL_REINDEXATION =
                       CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City',
                   END_PROCESS = 10
             WHERE     DELETE_DATA_ID = V_DELETE_DATA_ID
                   AND ITERATION_ID = V_ITERATION;

            COMMIT;
        END IF;

        V_EXECUTION := 1;
        V_PROCESS :=
               'SE RECONSTRUYÓ EL ÍNDICE '
            || V_INDEX
            || ' DE LA TABLA: '
            || PA_TABLE_NAME
            || ',REBUILDINGINDEX_ID: '
            || V_REBUILDINGINDEX_ID;

        PA_EXECUTION := V_EXECUTION;
        PA_PROCESS := V_PROCESS;
        DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
            'DBA_DMS.PCK_DELETE_DATA.SP_INDEX_TABLE',
               'SE RECONSTRUYÓ EL ÍNDICE '
            || V_INDEX
            || ' DE LA TABLA: '
            || PA_TABLE_NAME
            || ',REBUILDINGINDEX_ID: '
            || V_REBUILDINGINDEX_ID,
            SQLCODE,
            SQLERRM);
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            PA_EXECUTION := V_EXECUTION;
            PA_PROCESS := V_PROCESS;
            ROLLBACK;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA.SP_INDEX_TABLE',
                   'TABLA: '
                || PA_TABLE_NAME
                || ', EJECUCIÓN: '
                || PA_EXECUTION
                || ', PROCESO: '
                || PA_PROCESS,
                SQLCODE,
                SQLERRM);
        WHEN OTHERS
        THEN
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_DELETE_DATA.SP_INDEX_TABLE',
                   'TABLA: '
                || PA_TABLE_NAME
                || ', EJECUCIÓN: '
                || PA_EXECUTION
                || ', PROCESO: '
                || PA_PROCESS,
                SQLCODE,
                SQLERRM);
            PA_EXECUTION := V_EXECUTION;
            PA_PROCESS := V_PROCESS;
            ROLLBACK;
    END SP_INDEX_TABLE;
END PCK_DELETE_DATA;
/

