create PACKAGE BODY         PCK_COUNT_COD_PRINTS
AS
    PROCEDURE SP_COD_PRINT (
        P_ZONE            IN     NUMBER,
        P_FULL_CAMPAIGN   IN     NUMBER,
        P_COD_TYPE_P      IN     VARCHAR2,                       ----N ó P ó C
        P_COD_TYPE_A      IN     VARCHAR2,                        ----P ó NULL
        P_CURSOR             OUT DBA_DMS.PCK_COUNT_COD_PRINTS.CURSOR_TP,
        P_ERROR_FLAG         OUT VARCHAR2,            --- S = error, N = éxito
        P_ERROR_CODE         OUT VARCHAR2,                      --- Código SQL
        P_ERROR_MESSAGE      OUT VARCHAR2               --- mensaje de salida)
                                         )
    AS
        V_ERROR_FLAG   VARCHAR2 (1) := 'S';
    BEGIN
        IF     P_ZONE IS NOT NULL
           AND P_FULL_CAMPAIGN IS NOT NULL
           AND P_COD_TYPE_P IS NOT NULL
        THEN
            OPEN P_CURSOR FOR
                SELECT ZONE, FULL_CAMPAIGN, COD_ID
                  FROM (  SELECT COD_ID,
                                 COUNT (DISTINCT (T.ORDER_ID)) SAME_ORDERS,
                                 ORDER_COUNT,
                                 SUM (NUM_PACKAGES)          SAME_BOXES,
                                 BOX_COUNT,
                                 SUM (NUM_UNITARIES)         SAME_UNITARIES,
                                 SUM (ITEMS_COUNT)           SAME_ITEMS,
                                 UNITARY_ITEM_COUNT,
                                 T.ZONE,
                                 T.FULL_CAMPAIGN
                            FROM (  SELECT PCK.ORDER_ID,
                                           CP.FULL_CAMPAIGN,
                                           ZONE,
                                           SUM (
                                               CASE
                                                   WHEN PCK.PACKAGE_TYPE <> 'H'
                                                   THEN
                                                       1
                                                   ELSE
                                                       0
                                               END)
                                               AS NUM_PACKAGES,
                                           SUM (
                                               CASE
                                                   WHEN PCK.PACKAGE_TYPE = 'H'
                                                   THEN
                                                       1
                                                   ELSE
                                                       0
                                               END)
                                               AS NUM_UNITARIES,
                                           ITEMS_COUNT
                                      FROM DBA_DMS.PACKAGES PCK
                                           INNER JOIN DBA_DMS.ORDERS O
                                               ON O.ORDER_ID = PCK.ORDER_ID
                                           INNER JOIN DBA_DMS.SCPI_ORDER_HEADERS SP
                                               ON SP.ORDER_ID = PCK.ORDER_ID
                                           LEFT JOIN
                                           (  SELECT COUNT (*) ITEMS_COUNT,
                                                     IT.ORDER_ID
                                                FROM DBA_DMS.ITEMS IT
                                            GROUP BY IT.ORDER_ID) I
                                               ON (I.ORDER_ID = O.ORDER_ID)
                                           INNER JOIN DBA_DMS.COD_PRINTS CP
                                               ON     CP.ZONE_ID = SP."ZONE"
                                                  AND CP.FULL_CAMPAIGN =
                                                      SP.FULL_CAMPAIGN
                                           INNER JOIN DBA_DMS.COD_PRINT_DETAILS CD
                                               ON     CD.COD_ID = CP.COD_ID
                                                  AND CD.ORDER_ID = O.ORDER_ID ---- VALIDA QUE LAS ORDENES ESTÉN EN COD_PRINT_DETAILS SON DE TIPO
                                           LEFT JOIN
                                           (SELECT PD.ORDER_ID
                                              FROM DBA_DMS.COD_PRINT_DETAILS PD
                                             WHERE PD.COD_TYPE = P_COD_TYPE_A)
                                           CPD
                                               ON CPD.ORDER_ID = O.ORDER_ID --- INCLUYE LAS ORDENES DE TIPO P = PRUEBA
                                     WHERE     CP.PRINTED_AT IS NULL
                                           AND CP.ORDER_COUNT IS NOT NULL
                                           AND CP.UNITARY_ITEM_COUNT IS NOT NULL
                                           AND CP.FULL_CAMPAIGN >= 202109
                                           AND CP.FULL_CAMPAIGN = P_FULL_CAMPAIGN
                                           AND CP.ZONE_ID = P_ZONE
                                           AND CD.COD_TYPE IN (P_COD_TYPE_P) ---RECIBE EL PARÁMETRO DE TIPOS DE COD N, C, P
                                  GROUP BY PCK.ORDER_ID,
                                           CP.FULL_CAMPAIGN,
                                           ZONE,
                                           ITEMS_COUNT) T
                                 INNER JOIN DBA_DMS.COD_PRINTS C
                                     ON     C.ZONE_ID = T."ZONE"
                                        AND C.FULL_CAMPAIGN = T.FULL_CAMPAIGN
                        GROUP BY T.ZONE,
                                 T.FULL_CAMPAIGN,
                                 ORDER_COUNT,
                                 BOX_COUNT,
                                 UNITARY_ITEM_COUNT,
                                 COD_ID)
                 WHERE     SAME_ORDERS = ORDER_COUNT
                       AND SAME_BOXES = BOX_COUNT
                       AND SAME_UNITARIES = UNITARY_ITEM_COUNT
                       AND SAME_ITEMS = UNITARY_ITEM_COUNT    --- VALIDA ITEMS
                       AND COD_ID IN
                               (SELECT COD_ID
                                  FROM DBA_DMS.COD_PRINT_DETAILS PD
                                 WHERE PD.COD_TYPE IN
                                           (P_COD_TYPE_A, P_COD_TYPE_P)) ---DISCRIMINA OTROS TIPOS
                                                                        ;

            V_ERROR_FLAG := 'N';
        ELSE
            P_ERROR_FLAG := V_ERROR_FLAG;
            P_ERROR_CODE := SQLCODE;
            P_ERROR_MESSAGE :=
                   'DATO DE ENTRADA NULL ZONE:'
                || P_ZONE
                || ',FULL CAMPAIGN:'
                || P_FULL_CAMPAIGN
                || 'COD TYPE PRINCIPAL:'
                || P_COD_TYPE_P
                || ',COD TYPE ALTERNATIVO:'
                || P_COD_TYPE_A
                || '. NO SE GENERÓ COD';
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            P_ERROR_FLAG := 'S';
            P_ERROR_CODE := SQLCODE;
            P_ERROR_MESSAGE :=
                CONCAT (CONCAT (SQLERRM, '  '),
                        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
            ROLLBACK;
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_COUNT_COD_PRINTS.SP_COD_PRINT',
                'NO HAY DATOS ',
                SQLCODE,
                SQLERRM);
        WHEN OTHERS
        THEN
            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_COUNT_COD_PRINTS.SP_COD_PRINT',
                   'NO SE GENERÓ COD ZONA: '
                || P_ZONE
                || ',FULL CAMPAIGN:'
                || P_FULL_CAMPAIGN
                || ',COD TYPE PRINCIPAL:'
                || P_COD_TYPE_P
                || ',COD TYPE ALTERNATIVO:'
                || P_COD_TYPE_A,
                SQLCODE,
                SQLERRM);
            P_ERROR_CODE := SQLCODE;
            P_ERROR_FLAG := 'S';
            P_ERROR_MESSAGE :=
                CONCAT (CONCAT (SQLERRM, '  '),
                        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
            ROLLBACK;
    END SP_COD_PRINT;
END PCK_COUNT_COD_PRINTS;
/

