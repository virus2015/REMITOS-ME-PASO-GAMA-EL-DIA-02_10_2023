create PACKAGE         PCK_WHITE_LIST AS
/******************************************************************************
   NAME:       PCK_WHITE_LIST
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        22/03/2022      reyesros       1. Created this package.
******************************************************************************/


  PROCEDURE SP_INS_WHITE_LIST  ( P_FULL_CAMPAIGN IN NUMBER, -- full campaign
                                 P_ZONE IN NUMBER, --- no enviar si lleva cuenta
                                 P_ACCOUNT IN NUMBER,--- no enviar si lleva zona
                                 P_LOADED_BY IN VARCHAR2,--- Z si en por ZONA, A = ACCOUNT
                                 P_UPDATED_BY    IN VARCHAR2,--- avonsa
                                 P_ERROR_FLAG         OUT VARCHAR2, --- S = CON ERROR N = SIN ERROR
                                 P_ERROR_CODE         OUT VARCHAR2,
                                 P_ERROR_MESSAGE      OUT VARCHAR2,
                                 P_COUNT              OUT NUMBER  ---- número de filas actualizadas
);

 PROCEDURE SP_SEND_WL_SIMPLI
 (
                                 P_CURSOR_WL             OUT SYS_REFCURSOR  ----CURSOR CON SELECT A WHITE_LIST
);
PROCEDURE SP_UPD_WHITE_LIST  (
                                     P_FULL_CAMPAIGN IN NUMBER,
                                     P_ACCOUNT       IN NUMBER,
                                     P_ERROR_FLAG         OUT VARCHAR2, --- S = CON ERROR N = SIN ERROR
                                     P_ERROR_CODE         OUT VARCHAR2,
                                     P_ERROR_MESSAGE      OUT VARCHAR2,
                                     P_COUNT              OUT NUMBER );
END PCK_WHITE_LIST;
/

