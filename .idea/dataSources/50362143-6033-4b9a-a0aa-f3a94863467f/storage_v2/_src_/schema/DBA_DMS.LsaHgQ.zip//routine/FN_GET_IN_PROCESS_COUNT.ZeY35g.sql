create Function FN_GET_IN_PROCESS_COUNT
   RETURN number
IS
   total_ordenes number;

BEGIN

    SELECT COUNT(*) INTO total_ordenes
    FROM orders WHERE -- IN_PROCESS='T' AND 
    CHANGE_FLAG='T';
    -- Importante preguntar si se incluye el campo FULL_CAMPAIGN

RETURN total_ordenes;
END;
/

