create PROCEDURE         SP_APPLY_ONLINE_PAYMENTS (
    P_ERROR_FLAG         OUT VARCHAR2,
    P_ERROR_CODE         OUT VARCHAR2,
    P_ERROR_MESSAGE      OUT VARCHAR2,
    PAYMENTS_PROCESSED   OUT NUMBER,
    AMOUNTS_PROCESSED    OUT NUMBER)
IS
    V_PAYMENTS_PROCESSED   NUMBER(8) := 0;
    V_AMOUNTS_PROCESSED    NUMBER (8) := 0;
    BEFORE_ROWS_AMOUNTS    NUMBER (19) := 0;
    AFTER_ROWS_AMOUNTS     NUMBER (19) := 0;
    V_ACCOUNT              NUMBER (8) := 0;
    V_CURRENT_AMOUNT_O     NUMBER (10, 2) := 0;
    V_PAYMENT_AMOUNT       NUMBER (10) := 0;
    V_CAMPAIGN_YEAR_P      NUMBER (6) := 0;
    V_CAMPAIGN             NUMBER (2) := 0;
    V_ID_ONLINE_PAYMENTS   NUMBER (38) := 0;
    V_CAMPAIGN_PAYED       NUMBER (6) := 0;
    V_COUNT_ORDER_A        NUMBER (6) := 0;
    V_TOTAL_PAYMENT        NUMBER (12) := 0;
    V_PREVIUS_CAMPAIGN     NUMBER (6) := 0;
    V_ORDER                NUMBER (19) := 0;
    V_FULLCAMPAIGN         NUMBER (6) := 0;

    --- OBTIENE TODOS LOS PAGOS DEL DÍA DEL HOY
    CURSOR CUR_PAYMENTS
    IS
          SELECT ID,
                 CAMPAIGN_YEAR,
                 CAMPAIGN,
                 ACCOUNT,
                 PAYMENT_AMOUNT
            FROM ONLINE_PAYMENTS P
           WHERE     P.BIDS_TRANSACT = '017'      --- QUE SEAN DE TIPO ON LINE
                 AND TRUNC (P.created_at) = TRUNC (SYSDATE) --- PAGOS SÓLO DEL DÍA DE HOY
                 AND P.updated_at IS NULL            --- NO SE HAYAN PROCESADO
        ORDER BY created_at, ID ASC; ---ORDENAR POR FECHA DE CREACIÓN Y PRIMERA ORDEN
BEGIN
    P_ERROR_FLAG := 'N';

    SELECT COUNT (*)
      INTO BEFORE_ROWS_AMOUNTS
      FROM ONLINE_PAYMENTS P
     WHERE     P.BIDS_TRANSACT = '017'            --- QUE SEAN DE TIPO ON LINE
           AND TRUNC (P.created_at) = TRUNC (SYSDATE)   --- PAGOS SÓLO DEL DÍA
           AND P.updated_at IS NULL                  --- NO SE HAYAN PROCESADO
                                   ;

    OPEN CUR_PAYMENTS;

    LOOP
        FETCH CUR_PAYMENTS
            INTO V_ID_ONLINE_PAYMENTS,
                 V_CAMPAIGN_YEAR_P,
                 V_CAMPAIGN,
                 V_ACCOUNT,
                 V_PAYMENT_AMOUNT;

        EXIT WHEN CUR_PAYMENTS%NOTFOUND;
        V_PAYMENTS_PROCESSED := V_PAYMENTS_PROCESSED + SQL%ROWCOUNT;

        --- VALIDA QUE EXISTAN ORDENES EN LA CAMPAÑA ACTUAL
        SELECT COUNT (H.ORDER_ID), MAX (FULL_CAMPAIGN)
          INTO V_COUNT_ORDER_A,      ---OBTIENE LA PRIMERA ORDER DE LA CAMPAÑA
                                V_FULLCAMPAIGN
           FROM SCPI_ORDER_HEADERS  H
         WHERE   TRUNC (H.ORDER_DATE) > TRUNC (SYSDATE) - 9 --- HASTA OCHO DÍAS ANTES
               AND TRUNC (H.ORDER_DATE) <= TRUNC (SYSDATE) - 1 ---O FECHA DE FACTURACIÓN DE AYER
               AND  H.ORDER_ID NOT IN (SELECT S.ORDER_ID FROM ORDERS_STATUSES S 
               WHERE S.STATUS  IN (6                   --Entregado en Reparto
                                     , 8                     -- Entrega en PUP
                                       , 10        ---Entregado en Ventanilla
                                            ) )          --- NO ESTAN ENTREGADOS
               AND H.ACCOUNT = V_ACCOUNT                 --- POR REPRESENTANTE
               
                                        ;

        ---- SI HAY ORDENES VALIDA LA CAMPAÑA ANTERIOR, SINO ACTUALIZA LOS PAGOS
        IF V_COUNT_ORDER_A > 0
        THEN          ---OBTIENE LA CAMPAÑA ANTERIOR EN BASE A LA ORDEN ACTUAL
            SELECT FN_PREVIOUS_CAMPAIGN (V_FULLCAMPAIGN, 1)
              INTO V_PREVIUS_CAMPAIGN
              FROM DUAL;                       --- OBTIENE LA CAMPAÑA ANTERIOR

            ---- VALIDA QUE EXISTAN ORDENES EN CAMPAÑA ANTERIOR
            V_CAMPAIGN_PAYED := V_CAMPAIGN_YEAR_P || LPAD(V_CAMPAIGN,2,0);

            IF V_PREVIUS_CAMPAIGN = V_CAMPAIGN_PAYED
            THEN --- ACTUALIZA SI ES LIQUIDACIÓN DE LA CAMPAÑA ACTUAL, SINO HAY NO DEBE ACTUALIZAR NADA
                SELECT MIN (H.ORDER_ID)
                  INTO V_ORDER       ---OBTIENE LA PRIMERA ORDER DE LA CAMPAÑA
                    FROM SCPI_ORDER_HEADERS  H
         WHERE   TRUNC (H.ORDER_DATE) > TRUNC (SYSDATE) - 9 --- HASTA OCHO DÍAS ANTES
               AND TRUNC (H.ORDER_DATE) <= TRUNC (SYSDATE) - 1 ---O FECHA DE FACTURACIÓN DE AYER
               AND  H.ORDER_ID NOT IN (SELECT S.ORDER_ID FROM ORDERS_STATUSES S 
               WHERE S.STATUS  IN (6                   --Entregado en Reparto
                                     , 8                     -- Entrega en PUP
                                       , 10        ---Entregado en Ventanilla
                                            ) ) 
                       AND H.ACCOUNT = V_ACCOUNT         --- POR REPRESENTANTE
                                                ;

                --- OBTIENE EL CURRENT AMOUNT PARA SETEARLO AL PREVIUS AMOUNT
                SELECT CURRENT_AMOUNT
                  INTO V_CURRENT_AMOUNT_O
                  FROM ORDERS
                 WHERE ORDER_ID = V_ORDER;

                --- PONE EN CERO LOS NEGATIVOS y LOS MENORES IGUALES A 10
                V_TOTAL_PAYMENT :=
                    TRUNC (V_CURRENT_AMOUNT_O, 0) - V_PAYMENT_AMOUNT;

                IF V_TOTAL_PAYMENT <= 10
                THEN
                    V_TOTAL_PAYMENT := 0;
                END IF;
                                        --ACTUALIZA LOS SALDOS DE LAS ORDENES
                UPDATE ORDERS
                   SET CURRENT_AMOUNT = V_TOTAL_PAYMENT,
                       PREVIOUS_AMOUNT = V_CURRENT_AMOUNT_O,
                       TRANSFER_FLAG =
                           DECODE (TRANSFER_FLAG,
                                   'B', 'B',                 ---SE FUE A BIDS,
                                   'R', 'R',                          ---RETURN
                                   'F', 'F',
                                   'E')                   --- QUE LO ACTUALICE
                                       ,
                       PAYMENTS_COUNT = PAYMENTS_COUNT + 1,
                       UPDATED_BY = 'ONLINE PAYMENTS',
                       UPDATED_AT =
                           CURRENT_TIMESTAMP
                               AT TIME ZONE 'America/Mexico_City'
                 WHERE     CURRENT_AMOUNT > 0     --- LA ORDEN ES MAYOR A CERO
                       AND ORDER_ID IN         --- APLICADO ATODAS LAS ÓRDENES
                               (SELECT DISTINCT (H.ORDER_ID) --- TODAS LAS ORDENES
                                    FROM SCPI_ORDER_HEADERS  H
         WHERE   TRUNC (H.ORDER_DATE) > TRUNC (SYSDATE) - 9 --- HASTA OCHO DÍAS ANTES
               AND TRUNC (H.ORDER_DATE) <= TRUNC (SYSDATE) - 1 ---O FECHA DE FACTURACIÓN DE AYER
               AND  H.ORDER_ID NOT IN (SELECT S.ORDER_ID FROM ORDERS_STATUSES S 
               WHERE S.STATUS  IN (6                   --Entregado en Reparto
                                     , 8                     -- Entrega en PUP
                                       , 10        ---Entregado en Ventanilla
                                            ) ) 
                                       AND H.ACCOUNT = V_ACCOUNT); --- POR REPRESENTANTE

                ---ACTUALIZA LOS PAGOS APLICADOS
                UPDATE ONLINE_PAYMENTS
                   SET APPLIED_ORDER_NUMBER = V_ORDER,     --- LA ULTIMA ORDEN
                       APPLIED_ORDER_QUANTITY = 1,
                       PROCESSED_AT =
                           CURRENT_TIMESTAMP
                               AT TIME ZONE 'America/Mexico_City',
                       UPDATED_AT =
                           CURRENT_TIMESTAMP
                               AT TIME ZONE 'America/Mexico_City'
                 WHERE                              --- VALIDAR REGISTRO ÚNICO
                           ACCOUNT = V_ACCOUNT
                       AND CAMPAIGN_YEAR = V_CAMPAIGN_YEAR_P
                       AND CAMPAIGN = V_CAMPAIGN
                       AND BIDS_TRANSACT = '017'  --- QUE SEAN DE TIPO ON LINE
                       AND TRUNC (created_at) = TRUNC (SYSDATE) --- RANGO DE FECHA
                       AND updated_at IS NULL        --- NO SE HAYAN PROCESADO
                       AND ID = V_ID_ONLINE_PAYMENTS                --- POR ID
                                                    ;
             V_AMOUNTS_PROCESSED := V_AMOUNTS_PROCESSED + 1;
                COMMIT;
            ELSE --- SOLO ACTUALIZA LOS PAGOS PROCESADOS QUE NO ENCONTRARON ORDENES
                UPDATE ONLINE_PAYMENTS
                   SET APPLIED_ORDER_QUANTITY = 0,
                       PROCESSED_AT =
                           CURRENT_TIMESTAMP
                               AT TIME ZONE 'America/Mexico_City',
                       UPDATED_AT =
                           CURRENT_TIMESTAMP
                               AT TIME ZONE 'America/Mexico_City'
                 WHERE                              --- VALIDAR REGISTRO ÚNICO
                           ACCOUNT = V_ACCOUNT
                       AND CAMPAIGN_YEAR = V_CAMPAIGN_YEAR_P
                       AND CAMPAIGN = V_CAMPAIGN
                       AND BIDS_TRANSACT = '017'  --- QUE SEAN DE TIPO ON LINE
                       AND TRUNC (created_at) = TRUNC (SYSDATE) --- RANGO POR FECHA DE HOY
                       AND updated_at IS NULL        --- NO SE HAYAN PROCESADO
                       AND ID = V_ID_ONLINE_PAYMENTS                --- POR ID
                                                    ;

                COMMIT;
          END IF;
        ELSE --- SOLO ACTUALIZA LOS PAGOS PROCESADOS QUE NO ENCONTRARON ORDENES
            UPDATE ONLINE_PAYMENTS
               SET APPLIED_ORDER_QUANTITY = 0,
                   PROCESSED_AT =
                       CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City',
                   UPDATED_AT =
                       CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City'
             WHERE                                  --- VALIDAR REGISTRO ÚNICO
                       ACCOUNT = V_ACCOUNT
                   AND CAMPAIGN_YEAR = V_CAMPAIGN_YEAR_P
                   AND CAMPAIGN = V_CAMPAIGN
                   AND BIDS_TRANSACT = '017'      --- QUE SEAN DE TIPO ON LINE
                   AND TRUNC (created_at) = TRUNC (SYSDATE) --- RANGO POR FECHA DE HOY
                   AND updated_at IS NULL            --- NO SE HAYAN PROCESADO
                   AND ID = V_ID_ONLINE_PAYMENTS                    --- POR ID
                                                ;

            COMMIT;
        END IF;
          
    END LOOP;



    CLOSE CUR_PAYMENTS;

    PAYMENTS_PROCESSED := V_PAYMENTS_PROCESSED;
    AMOUNTS_PROCESSED := V_AMOUNTS_PROCESSED;
EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
    WHEN OTHERS
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
END SP_APPLY_ONLINE_PAYMENTS;
/

