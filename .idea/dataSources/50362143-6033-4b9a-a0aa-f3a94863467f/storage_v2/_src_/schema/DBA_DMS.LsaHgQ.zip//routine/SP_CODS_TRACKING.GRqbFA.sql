create PROCEDURE         SP_CODS_TRACKING
AS
   v_print_Header   NUMBER;
   v_time_Dif       NUMBER;
   v_data_Found     NUMBER;

   CURSOR c_req_CPDs
   IS
      SELECT *
        FROM (  SELECT CD.COD_ID AS CODID,
                       CP.ZONE_ID AS ZONE,
                       CP.ORDER_COUNT AS ORDERCOUNT,
                       CD.COD_TYPE AS CODTYPE,
                       CP.FULL_CAMPAIGN FULLCAMPAIGN,
                       COUNT (*) AS ORDENES,
                       CP.Created_AT,
                       CP.PRINTED_AT,
                       CP.Unitary_Item_Count,
                       CP.BOX_COUNT                      -- <= Included by GCM
                  FROM COD_PRINT_DETAILS CD
                       INNER JOIN COD_PRINTS CP ON CP.COD_ID = CD.COD_ID
                 WHERE CP.PRINTED_AT IS NULL
              GROUP BY CD.COD_ID,
                       CP.ZONE_ID,
                       CP.ORDER_COUNT,
                       CD.COD_TYPE,
                       CP.FULL_CAMPAIGN,
                       CP.Created_AT,
                       CP.Printed_AT,
                       CP.Unitary_Item_Count,
                       CP.BOX_COUNT     
              ORDER BY CD.COD_ID)
       WHERE ORDERCOUNT = ORDENES AND TRUNC (CREATED_AT) = TRUNC (SYSDATE);

   CURSOR c_info_en_DMS (
      p_Full_Campaign    NUMBER,
      p_Zone             NUMBER,
      p_Cod_Type         VARCHAR)
   IS
      SELECT ZONE,
             FULLCAMPAIGN,
             COD_ID CODID,
             SAME_ORDERS,
             SAME_BOXES,
             SAME_UNITARIES
        FROM (  SELECT C.COD_ID,
                       COUNT (DISTINCT (T.ORDER_ID)) SAME_ORDERS,
                       ORDER_COUNT,
                       SUM (NUM_PACKAGES) SAME_BOXES,
                       BOX_COUNT,
                       SUM (NUM_UNITARIES) SAME_UNITARIES,
                       CASE
                          WHEN SUM (ITEMS_COUNT) IS NULL THEN 0
                          ELSE SUM (ITEMS_COUNT)
                       END
                          SAME_ITEMS,
                       UNITARY_ITEM_COUNT,
                       T.ZONE,
                       T.FULLCAMPAIGN
                  FROM (  SELECT CP.COD_ID,
                                 PCK.ORDER_ID,
                                 CP.FULL_CAMPAIGN FULLCAMPAIGN,
                                 ZONE,
                                 SUM (
                                    CASE
                                       WHEN PCK.PACKAGE_TYPE <> 'H' THEN 1
                                       ELSE 0
                                    END)
                                    AS NUM_PACKAGES,
                                 SUM (
                                    CASE
                                       WHEN PCK.PACKAGE_TYPE = 'H' THEN 1
                                       ELSE 0
                                    END)
                                    AS NUM_UNITARIES,
                                 ITEMS_COUNT
                            FROM PACKAGES PCK
                                 INNER JOIN ORDERS O ON O.ORDER_ID = PCK.ORDER_ID
                                 INNER JOIN SCPI_ORDER_HEADERS SP
                                    ON SP.ORDER_ID = PCK.ORDER_ID
                                 LEFT JOIN
                                 (  SELECT COUNT (*) ITEMS_COUNT, IT.ORDER_ID
                                      FROM ITEMS IT
                                  GROUP BY IT.ORDER_ID) I
                                    ON (I.ORDER_ID = O.ORDER_ID)
                                 INNER JOIN COD_PRINTS CP
                                    ON     CP.ZONE_ID = SP.ZONE
                                       AND CP.FULL_CAMPAIGN = SP.FULL_CAMPAIGN
                                 INNER JOIN COD_PRINT_DETAILS CD
                                    ON     CD.COD_ID = CP.COD_ID
                                       AND CD.ORDER_ID = O.ORDER_ID
                                 LEFT JOIN
                                 (SELECT PD.ORDER_ID
                                    FROM COD_PRINT_DETAILS PD
                                   WHERE PD.COD_TYPE =
                                            CASE
                                               WHEN p_Cod_Type = 'N' 
                                                                    THEN 'P'
                                               ELSE NULL
                                            END) CPD
                                    ON CPD.ORDER_ID = O.ORDER_ID
                           WHERE     CP.PRINTED_AT IS NULL
                                 AND CP.ORDER_COUNT IS NOT NULL
                                 AND CP.UNITARY_ITEM_COUNT IS NOT NULL
                                 AND CP.FULL_CAMPAIGN >= 202109
                                 AND CP.FULL_CAMPAIGN = p_Full_Campaign
                                 AND CP.ZONE_ID = p_Zone
                                 AND CD.COD_TYPE = p_Cod_Type
                        GROUP BY CP.COD_ID,
                                 PCK.ORDER_ID,
                                 CP.FULL_CAMPAIGN,
                                 ZONE,
                                 ITEMS_COUNT) T
                       INNER JOIN COD_PRINTS C
                          ON     C.ZONE_ID = T.ZONE
                             AND C.FULL_CAMPAIGN = T.FULLCAMPAIGN
                             AND C.COD_ID = T.COD_ID
              GROUP BY C.COD_ID,
                       T.ZONE,
                       T.FULLCAMPAIGN,
                       ORDER_COUNT,
                       BOX_COUNT,
                       UNITARY_ITEM_COUNT)
       WHERE     SAME_ORDERS = ORDER_COUNT
             AND SAME_BOXES = BOX_COUNT
             AND SAME_UNITARIES = UNITARY_ITEM_COUNT
             AND SAME_ITEMS = UNITARY_ITEM_COUNT
             AND COD_ID IN (SELECT COD_ID
                              FROM COD_PRINT_DETAILS PD
                             WHERE PD.COD_TYPE = p_Cod_Type);
BEGIN
   v_print_Header := 0;

   FOR l_CPDs IN c_req_CPDs
   LOOP
      SELECT   (  TO_NUMBER (TO_CHAR (SYSDATE - 1, 'HH24')) * 100
                + TO_NUMBER (TO_CHAR (SYSDATE - 1, 'MI')))
             - (  TO_NUMBER (TO_CHAR (l_CPDs.CREATED_AT, 'HH24')) * 100
                + TO_NUMBER (TO_CHAR (l_CPDs.CREATED_AT, 'MI')))
        INTO v_time_Dif
        FROM DUAL;

      --IF v_time_Dif >= 40 THEN  -- Para verificar SI ya pasaron MAS de 40 minutos de espera de Impresión COD
      --    IF v_time_Dif >= 10 THEN  -- Para verificar SI ya pasaron MAS de 10 minutos de espera de Impresión COD
      BEGIN
         v_data_Found := 0;

         IF v_print_Header = 0
         THEN
            --           DBMS_OUTPUT.PUT_LINE('                         LISTA DE CPDS EN TIEMPO CRITICO');
            --           DBMS_OUTPUT.PUT_LINE(' ');
            --           DBMS_OUTPUT.PUT_LINE('CODID       ZONE       ORDERCOUNT       CODTYPE       FULLCAMPAIGN       ORDENES       CREATED_AT       PRINT_STATUS       STATUS_DMS       BOX_COUNT       UNITARY_ITEM_COUNT');
            --           DBMS_OUTPUT.PUT_LINE('-------     ------     ------------     ---------     --------------     ---------     ------------     --------------     ------------     -----------     ------------------');
            DBMS_OUTPUT.PUT_LINE (
               '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">');
            DBMS_OUTPUT.PUT_LINE ('<html>');
            DBMS_OUTPUT.PUT_LINE (
               '<head><title>Impresion de COD''''s</title>');
            DBMS_OUTPUT.PUT_LINE ('</head>');
            DBMS_OUTPUT.PUT_LINE ('<style type="text/css">');
            DBMS_OUTPUT.PUT_LINE ('  table, th, td {');
            DBMS_OUTPUT.PUT_LINE ('    border: 1px solid black;');
            DBMS_OUTPUT.PUT_LINE ('    border-collapse: collapse;');
            DBMS_OUTPUT.PUT_LINE ('  }');
            DBMS_OUTPUT.PUT_LINE ('</style>');
            DBMS_OUTPUT.PUT_LINE ('<body>');
            DBMS_OUTPUT.PUT_LINE (
               '<table style="width: 100%" align="center">');
            DBMS_OUTPUT.PUT_LINE (' <tr>');
            DBMS_OUTPUT.PUT_LINE (
               '  <td colspan="11" align="center" bgcolor="#3b83bd"><font color="#FFFFFF"><strong>LISTA DE CODs EN ESPERA</strong></font></td>');
            DBMS_OUTPUT.PUT_LINE (' </tr>');
            DBMS_OUTPUT.PUT_LINE (' <tr bgcolor="##87CEEB">');
            DBMS_OUTPUT.PUT_LINE ('  <th>ZONA</th>');
			DBMS_OUTPUT.PUT_LINE ('  <th>FULLCAMPAIGN</th>');
            DBMS_OUTPUT.PUT_LINE ('  <th>TIPO_COD</th>');
            DBMS_OUTPUT.PUT_LINE ('  <th>FECHA_HR_PETICION_COD</th>');			
            DBMS_OUTPUT.PUT_LINE ('  <th>TIEMPO_ESPERA_COD</th>');
            DBMS_OUTPUT.PUT_LINE ('  <th>ORDENES_PRINT</th>');
            DBMS_OUTPUT.PUT_LINE ('  <th>CAJAS_PRINT</th>');
            DBMS_OUTPUT.PUT_LINE ('  <th>UNITARIOS_PRINT</th>');
            DBMS_OUTPUT.PUT_LINE ('  <th>ORDENES_DMS</th>');
            DBMS_OUTPUT.PUT_LINE ('  <th>CAJAS_DMS</th>');
            DBMS_OUTPUT.PUT_LINE ('  <th>UNITARIOS_DMS</th>');			
            DBMS_OUTPUT.PUT_LINE (' </tr>');
            v_print_Header := 1;
         END IF;

         FOR l_en_DMS
            IN c_info_en_DMS (l_CPDs.FULLCAMPAIGN,
                              l_CPDs.ZONE,
                              l_CPDs.CODTYPE)
         LOOP
            BEGIN
               v_data_Found := 1;
               DBMS_OUTPUT.PUT_LINE (' <tr>');
               DBMS_OUTPUT.PUT_LINE (
                     '  <td>'
                  || l_CPDs.ZONE
                  || '</td> <td>'
                  || l_CPDs.FULLCAMPAIGN
                  || '</td> <td>'
                  || l_CPDs.CODTYPE
                  || '</td> <td>'
                  || l_CPDs.CREATED_AT
                  || '</td> <td>'
                  || v_time_Dif
                  || '</td> <td>'
                  || l_CPDs.ORDENES
                  || '</td> <td>'
                  || l_CPDs.BOX_COUNT
                  || '</td> <td>'
                  || l_CPDs.UNITARY_ITEM_COUNT
                  || '</td> <td>'				  
                  || l_en_DMS.SAME_ORDERS
                  || '</td> <td>'
                  || l_en_DMS.SAME_BOXES
                  || '</td> <td>'
                  || l_en_DMS.SAME_UNITARIES				  
                  || '</td>');
               DBMS_OUTPUT.PUT_LINE (' </tr>');
            END;
         END LOOP;
      END;
   END LOOP;

   IF v_print_Header = 1
   THEN
      DBMS_OUTPUT.PUT_LINE ('</table>');
      DBMS_OUTPUT.PUT_LINE ('</body>');
      DBMS_OUTPUT.PUT_LINE ('</html>');
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (SQLERRM);
END SP_CODS_TRACKING;
/

