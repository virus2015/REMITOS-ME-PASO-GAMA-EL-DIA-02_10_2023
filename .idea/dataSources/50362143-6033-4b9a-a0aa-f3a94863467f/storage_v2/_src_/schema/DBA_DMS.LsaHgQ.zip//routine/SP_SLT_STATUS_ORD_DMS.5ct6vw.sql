create PROCEDURE SP_SLT_STATUS_ORD_DMS (
    ordersDMS OUT SYS_REFCURSOR
)
AS

    v_last_id_processed number := 0;
    v_count_registers number := 0;

BEGIN

    SELECT VALOR
      INTO v_count_registers  
      FROM CONFIG_ORDER_HEADER@SCPIP
     WHERE ID_CONFIG = 9;


    OPEN ordersDMS FOR


      select * from (     

     SELECT  soh.order_id ,soh.order_number,soh.account,soh.order_date,soh.full_campaign,soh.zone,
                        soh.acc_name,soh.telephone,soh.email,soh.address1,soh.address2, soh.address3, soh.state_name,
                        soh.zip, soh.number_boxes,soh.cod_amount,soh.ord_amount,soh.first_order,
                        o.current_amount,o.previous_amount,o.payment_value,o.bank_code,o.payment_date,
                        o.round_num, o.return_reason, o.notes, o.dlv_typ, o.delivery1st, o.return_val,
                        o.pick_up_point_id, o.blocked_status, o.updated_at, o.stolen,o.route,o.deliver_order,os.updated_at as status_updated_at,
                        os.status
                        
                      FROM SCPI_ORDER_HEADERS soh
                      INNER join orders o on o.order_id = soh.order_id
                      INNER join orders_statuses os on os.order_id = o.order_id
      WHERE o.transfer_flag = 'F' AND o.updated_at is not null and os.status <> 1  
      ORDER BY soh.ORDER_ID ASC
       )
        where rownum <= v_count_registers;



END SP_SLT_STATUS_ORD_DMS;
/

