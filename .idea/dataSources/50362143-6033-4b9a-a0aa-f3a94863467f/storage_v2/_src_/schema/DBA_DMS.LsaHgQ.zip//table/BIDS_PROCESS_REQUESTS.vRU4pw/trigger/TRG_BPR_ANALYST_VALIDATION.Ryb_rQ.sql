create trigger TRG_BPR_ANALYST_VALIDATION
    before insert
    on BIDS_PROCESS_REQUESTS
    for each row
    when (new.JOB_TYPE = 'PY' and new.TRANSACTION_ID is null)
BEGIN
  RAISE_APPLICATION_ERROR(20001, 'Can''t request payments process without transaction id');
END;
/

