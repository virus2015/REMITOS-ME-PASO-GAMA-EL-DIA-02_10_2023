create TYPE           "ORDER_UPD_BLOCKED_ROW"                                          AS OBJECT 
(
   P_ORDER_ID NUMBER,
   P_BLOCKED_STATUS NUMBER
 )
/

