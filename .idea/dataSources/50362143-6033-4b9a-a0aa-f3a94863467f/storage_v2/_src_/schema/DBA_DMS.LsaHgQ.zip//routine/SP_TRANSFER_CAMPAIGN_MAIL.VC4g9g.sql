create PROCEDURE sp_transfer_campaign_mail (
    campaignsDMS   OUT SYS_REFCURSOR)
AS
    p_campaign_year   NUMBER (4, 0);
    p_campaign        NUMBER (2, 0);
    p_start_date      VARCHAR2 (8);
    p_end_date        VARCHAR2 (8);
    p_change_flag     CHAR (1 BYTE);
    p_updated_at      VARCHAR2 (8);
    p_billing_date    VARCHAR2 (8);
    p_mail_id         CHAR (1);
    p_error_flag      VARCHAR2 (50);
    p_error_code      VARCHAR2 (50);
    p_error_message   VARCHAR2 (500);
BEGIN
    OPEN campaignsDMS FOR
          SELECT MAX (c.CAMPAIGN_YEAR)     AS CAMPAIGN_YEAR,
                 c.CAMPAIGN,
                 TO_CHAR(c.START_DATE ,'YY-MM-DD') AS START_DATE ,
                 TO_CHAR(c.END_DATE ,'YY-MM-DD') AS END_DATE ,
                 c.CHANGE_FLAG,
                 TO_CHAR(c.UPDATED_AT ,'YY-MM-DD') AS UPDATED_AT ,
                 TO_CHAR( m.BILLING_DATE ,'YY-MM-DD') AS  BILLING_DATE,
                 m.MAIL_ID
            INTO p_campaign_year,
                 p_campaign,
                 p_start_date,
                 p_end_date,
                 p_change_flag,
                 p_updated_at,
                 p_billing_date,
                 p_mail_id
            FROM CAMPAIGNS c
                 INNER JOIN MAILS m
                     ON     c.campaign = m.campaign
                        AND c.campaign_year = m.campaign_year
                        AND c.CHANGE_FLAG = 'T'
                        AND m.CHANGE_FLAG = 'T'
        --    WHERE c.CAMPAIGN_YEAR >= to_char(systimestamp,'YYYY')
        -- WHERE c.CAMPAIGN IN (5)
        GROUP BY c.CAMPAIGN,
                 c.START_DATE,
                 c.END_DATE,
                 c.CHANGE_FLAG,
                 c.UPDATED_AT,
                 m.BILLING_DATE,
                 m.MAIL_ID;
    /*
    -- se envia en un nuevo stored procedure
    p_change_flag := 'T';
        UPDATE CAMPAIGNS SET change_flag = p_change_flag WHERE campaign_year = p_campaign_year AND campaign = p_campaign AND p_change_flag = 'F';
        UPDATE MAILS SET change_flag = p_change_flag WHERE campaign_year = p_campaign_year AND campaign = p_campaign AND p_change_flag = 'F';
        COMMIT;
*/
EXCEPTION
    WHEN OTHERS
    THEN
        p_error_code := SQLCODE;
        p_error_message :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.format_error_backtrace ());
        p_error_flag := 'S';
END sp_transfer_campaign_mail;
/

