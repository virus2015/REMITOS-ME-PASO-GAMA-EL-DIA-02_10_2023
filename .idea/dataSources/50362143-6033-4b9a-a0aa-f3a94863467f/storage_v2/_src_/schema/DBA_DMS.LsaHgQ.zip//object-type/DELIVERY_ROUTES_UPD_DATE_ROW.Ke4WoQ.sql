create TYPE           "DELIVERY_ROUTES_UPD_DATE_ROW"                                          AS OBJECT
(
   FULL_CAMPAIGN NUMBER,
   ZONE_ID NUMBER,
   ROUTE NUMBER,
   DELIVERY_DATE DATE,
   TRANSFER_FLAG CHAR(1)
 );
/

