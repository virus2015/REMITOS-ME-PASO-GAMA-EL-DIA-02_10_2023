create FUNCTION         fn_get_current_campaign
        RETURN NUMBER
    AS
      result number(6);
    BEGIN
        select (CAMPAIGN_YEAR*100+CAMPAIGN) into result
        from CAMPAIGNS where current_timestamp between START_DATE and END_DATE and CAMPAIGN between 1 and 19;
      RETURN result;
    end;
/

