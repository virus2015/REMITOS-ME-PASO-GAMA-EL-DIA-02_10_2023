create PACKAGE         PCK_ONE_PAGE_REPRES AS
/******************************************************************************
   NAME:       PCK_ONE_PAGE_REPRES
   PURPOSE:    CONSULTA DATOS DE REPRESENTANTE PARA ONE PAGE
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        19/1272022      reyesros       1. Created this package.
******************************************************************************/

  PROCEDURE  SP_SEL_ONE_PAGE_REPRES                (P_ACCOUNT IN NUMBER, ---- OBLIGATORIO
                                                    P_CAMPAIGN IN VARCHAR2, ---- SI VA NULO, DEVUELVE LA ÚLTIMA CAMPAÑA DE FACTURACIÓN DE LA REPRESENTANTE
                                                    P_YEAR IN NUMBER, ---- EL AÑO DEBE IR UNLO SI LA CAMPAÑA VA NULA
                                                    P_ERROR_CODE         OUT VARCHAR2, --- Código SQL,
                                                    P_ERROR_MESSAGE      OUT VARCHAR2,
                                                    P_CURSOR  OUT SYS_REFCURSOR);



  FUNCTION FN_ESTATUS_ORDEN
                                        (P_ORDER_ID  NUMBER) RETURN VARCHAR2;




END PCK_ONE_PAGE_REPRES;
/

