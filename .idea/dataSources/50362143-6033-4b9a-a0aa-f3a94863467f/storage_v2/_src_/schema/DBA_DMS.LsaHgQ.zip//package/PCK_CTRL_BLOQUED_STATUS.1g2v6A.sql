create PACKAGE         PCK_CTRL_BLOQUED_STATUS AS
/******************************************************************************
   NAME:       PCK_CTRL_BLOQUED_STATUS
   PURPOSE:    Controla las actualizaciones del estatus de bloqueo en ordenes
               IMPORTANTE: Cuando se agregue un nuevo registro en la tabla de return_reasons, se debe agregar al procedimiento en el flujo correspondiente.

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        23/06/2021      reyesros       1. Created this package.
******************************************************************************/

  PROCEDURE SP_CTRL_BLOQUED_STATUS_0
                                        (P_BLOCKED_STATUS_0     OUT NUMBER,
                                         P_ERROR_FLAG         OUT VARCHAR2, --- S = error, N = éxito
                                         P_ERROR_CODE         OUT VARCHAR2, --- Código SQL
                                         P_ERROR_MESSAGE      OUT VARCHAR2);
   PROCEDURE SP_CTRL_BLOQUED_STATUS_INC
                                        (P_BLOCKED_STATUS_INC   OUT NUMBER,
                                         P_ERROR_FLAG         OUT VARCHAR2, --- S = error, N = éxito
                                         P_ERROR_CODE         OUT VARCHAR2, --- Código SQL
                                         P_ERROR_MESSAGE      OUT VARCHAR2);

END PCK_CTRL_BLOQUED_STATUS;
/

