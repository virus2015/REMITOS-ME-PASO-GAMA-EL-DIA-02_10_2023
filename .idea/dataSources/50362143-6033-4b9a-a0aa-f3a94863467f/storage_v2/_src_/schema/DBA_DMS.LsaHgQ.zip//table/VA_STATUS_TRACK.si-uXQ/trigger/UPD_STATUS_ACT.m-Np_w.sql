create trigger UPD_STATUS_ACT
    before insert
    on VA_STATUS_TRACK
    for each row
declare 

begin

    if :new.STATUS_MASTER_BOX = 6 then 
       update DBA_DMS.VA_STATUS_TRACK 
          set STATUS = 0
        where ID_FOLIO_MASTERBOX = :new.ID_FOLIO_MASTERBOX
        and STATUS_MASTER_BOX = 5;

    end if ;

end ;
/

