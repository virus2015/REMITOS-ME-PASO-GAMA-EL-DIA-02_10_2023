create PROCEDURE SP_UPD_SLT_ORD_DMS (
  P_ORDER_ID IN VARCHAR2)
  IS
  
  V_ORDER_ID NUMBER(19,0);
  
BEGIN
  
  if P_ORDER_ID is not null then
     if P_ORDER_ID = '' then
         V_ORDER_ID := null;
     else
         V_ORDER_ID := to_number(P_ORDER_ID);
     end if;
  else
    V_ORDER_ID := null;
  end if;
  
  if ( V_ORDER_ID is not null ) then
  
    update CONFIG_ORDER_HEADER@SCPIP 
    set VALOR = V_ORDER_ID
        where ID_CONFIG = 8;
        
        commit;
        
  end if;
  
  EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20001,
                            'HA OCURRIDO UN ERROR AL INTENTAR ACTUALIZAR  ' || V_ORDER_ID ||' - ' ||
                            SQLCODE || ' -ERROR- ' || SQLERRM);

  
  
END SP_UPD_SLT_ORD_DMS;
/

