create TYPE           "ORDER_UPD_BLOCKED_EXCELL_ROW"                                          AS OBJECT 
(
   P_ACCOUNT NUMBER,
   P_BLOCKED_STATUS NUMBER,
   P_CAMP_YEAR NUMBER,
   P_CAMPAIGN NUMBER
 )
/

