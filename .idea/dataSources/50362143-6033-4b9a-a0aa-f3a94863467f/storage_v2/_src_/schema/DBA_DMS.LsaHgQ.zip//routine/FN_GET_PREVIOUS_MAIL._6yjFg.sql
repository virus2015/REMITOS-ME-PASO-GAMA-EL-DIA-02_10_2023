create FUNCTION         FN_GET_PREVIOUS_MAIL (
    P_FULLCAMPAIGN          IN NUMBER,
    P_ZONE                     NUMBER,
    P_NUM_CAMPAIGN_BEFORE   IN NUMBER)
    RETURN VARCHAR2
AS

/******************************************************************************
   NAME:       FN_GET_PREVIOUS_MAIL
   PURPOSE:    Obtiene el plan mail de la campaña anterior en la tabla de zone_campaign

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        14/07/2021      reyesros       1. Created this function.
******************************************************************************/

    V_TEMPYEAR             NUMBER (4);
    V_TEMPCAMP             NUMBER (2);
    V_FULLCAMPAIGN         NUMBER (6) := P_FULLCAMPAIGN;
    V_MAX_CAMP             NUMBER (2);
    V_PREVIOUS_CAMPAIGN    NUMBER (6);
    V_PREVIOUS_PLAN_MAIL   VARCHAR2 (5);
    V_ZONE                 NUMBER (4) := P_ZONE;
BEGIN
    V_MAX_CAMP := 19;                             -- NUMERO DE CAMPAÑAS MAXIMO


    V_TEMPCAMP := MOD (V_FULLCAMPAIGN, 100);
    V_TEMPYEAR := (V_FULLCAMPAIGN - V_TEMPCAMP) / 100;


    IF (V_TEMPCAMP <= P_NUM_CAMPAIGN_BEFORE)
    THEN
        V_TEMPCAMP := V_MAX_CAMP + V_TEMPCAMP - P_NUM_CAMPAIGN_BEFORE;
        V_TEMPYEAR := V_TEMPYEAR - 1;
    ELSE
        V_TEMPCAMP := V_TEMPCAMP - P_NUM_CAMPAIGN_BEFORE;
    END IF;

    V_PREVIOUS_CAMPAIGN := V_TEMPCAMP;

    SELECT ZC.MAIL_PLAN
      INTO V_PREVIOUS_PLAN_MAIL
      FROM ZONE_CAMPAIGNS ZC
     WHERE     ZC.CAMPAIGN_YEAR = V_TEMPYEAR
           AND ZC.CAMPAIGN = V_TEMPCAMP
           AND ZC."ZONE" = V_ZONE;

    RETURN V_PREVIOUS_PLAN_MAIL;
        EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            V_PREVIOUS_PLAN_MAIL := NULL;
            RETURN V_PREVIOUS_PLAN_MAIL ;

           WHEN OTHERS
        THEN
            V_PREVIOUS_PLAN_MAIL := NULL;
            RETURN V_PREVIOUS_PLAN_MAIL ;

END;
/

