create FUNCTION FN_STRING_TYPE (P_DATES VARCHAR2)
  RETURN TABLE AS DBA_DMS.PKC_UPD_REPRES_DATA.CUR_TYPE;
  
CREATE OR REPLACE PACKAGE BODY DBA_DMS.PKC_UPD_REPRES_DATA
AS
    PROCEDURE SP_UPD_REPRES_DATA (P_DATE            IN     VARCHAR2, --- fechas, sepadas por comas DD/MM/YYYY
                                  P_ERROR_FLAG         OUT VARCHAR2, ---N sin error, S error
                                  P_ERROR_CODE         OUT VARCHAR2, --- SQLCODE
                                  P_ERROR_MESSAGE      OUT VARCHAR2, --- mensaje del error Oracle
                                  P_TOTAL_UPDATE       OUT NUMBER, --- total de datos a procesar
                                  P_REAL_UPDATE        OUT NUMBER) --- total de datos procesados
    AS
        V_DATE            VARCHAR2 (40) := P_DATE;
        V_ERROR_FLAG      VARCHAR2 (2600) := 'S';
        V_ERROR_CODE      VARCHAR2 (150) := ' ';                    --- SQLCODE
        V_ERROR_MESSAGE   VARCHAR2 (1500) := ' ';  --- mensaje del error Oracle
        V_TOTAL_UPDATE    NUMBER (6) := 0;       --- total de datos a procesar
        V_REAL_UPDATE     NUMBER (6) := 0;       --- total de datos procesados
    BEGIN
        NULL;
        EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
    WHEN OTHERS
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
    END SP_UPD_REPRES_DATA;
END
/

