create trigger TRG_MANAGER_ID_SEQ
    before insert
    on MANAGER_ACCESS
    for each row
BEGIN
  SELECT MANAGER_ID_SEQ.NEXTVAL
  INTO   :new.MANAGER_ID
  FROM   DUAL;
END TRG_MANAGER_ID_SEQ;
/

