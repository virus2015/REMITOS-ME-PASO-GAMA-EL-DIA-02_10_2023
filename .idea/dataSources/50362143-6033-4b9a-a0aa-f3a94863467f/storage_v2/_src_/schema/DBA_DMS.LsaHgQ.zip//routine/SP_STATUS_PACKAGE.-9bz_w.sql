create PROCEDURE SP_STATUS_PACKAGE 
(
  P_ORDER_ID IN VARCHAR2,
  P_PACKAGE_ID IN VARCHAR,
  P_UPDATED_AT IN VARCHAR,
  P_STATUS IN VARCHAR,
  p_error_flag out varchar2,
  p_error_code out varchar2,
  p_error_message out varchar2
) IS 
  V_ORDER_ID NUMBER(19,0);
  V_PACKAGE_ID NUMBER(19,0);
  V_UPDATED_AT TIMESTAMP(6);
  V_STATUS NUMBER(4,0);
BEGIN
  V_ORDER_ID := to_number(P_ORDER_ID);
  V_PACKAGE_ID := to_number(P_PACKAGE_ID);
  V_UPDATED_AT := TO_TIMESTAMP(P_UPDATED_AT,'DD-MM-YYYY HH24:MI:SS');
  V_STATUS := to_number(P_STATUS);
  
  insert into package_statuses ( order_id, package_id, updated_at, status )
  values
  ( V_ORDER_ID, V_PACKAGE_ID, V_UPDATED_AT, V_STATUS);
  
  commit;
  
  EXCEPTION
			  WHEN OTHERS THEN
				 p_error_code := SQLCODE;
				 p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() );
				 p_error_flag := 'S';
END SP_STATUS_PACKAGE;
/

