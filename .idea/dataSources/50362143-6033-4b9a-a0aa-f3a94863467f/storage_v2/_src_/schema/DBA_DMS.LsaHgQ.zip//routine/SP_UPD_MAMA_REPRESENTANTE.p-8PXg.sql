create PROCEDURE SP_UPD_MAMA_REPRESENTANTE 
(
  P_ACCOUNT IN VARCHAR2 
, P_MAMA_ACCOUNT IN VARCHAR2

) AS

     V_ACCOUNT NUMBER(8,0);
     V_MAMA_ACCOUNT NUMBER(8,0);
     
BEGIN

     if P_ACCOUNT is not null then
          if P_ACCOUNT = '' then
              V_ACCOUNT := null;
          else
              V_ACCOUNT := to_number(P_ACCOUNT);
          end if;
     else
          V_ACCOUNT := null;
     end if;
     
     if P_MAMA_ACCOUNT is not null then
          if P_MAMA_ACCOUNT = '' then
              V_MAMA_ACCOUNT := null;
          else
              V_MAMA_ACCOUNT := to_number(P_MAMA_ACCOUNT);
          end if;
     else
          V_MAMA_ACCOUNT := null;
     end if;
     
     if ( V_ACCOUNT is not null and V_MAMA_ACCOUNT is not null ) then
          
          UPDATE representatives SET PARENT_ACCOUNT = V_MAMA_ACCOUNT
          WHERE ACCOUNT = V_ACCOUNT;
          
          COMMIT;
          
     end if;
     
     EXCEPTION
          WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20001,
                            'HA OCURRIDO UN ERROR AL INTENTAR ACTUALIZAR LA MAMA REPRESENTANTE  ' || V_MAMA_ACCOUNT || ' DE LA REPRESENTANTE ' || V_ACCOUNT || ' - ' ||
                            SQLCODE || ' -ERROR- ' || SQLERRM);
                            
END SP_UPD_MAMA_REPRESENTANTE;
/

