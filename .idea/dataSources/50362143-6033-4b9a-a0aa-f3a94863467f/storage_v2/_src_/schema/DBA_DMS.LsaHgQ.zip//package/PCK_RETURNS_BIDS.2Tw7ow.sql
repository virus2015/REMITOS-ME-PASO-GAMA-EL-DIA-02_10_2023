create PACKAGE PCK_RETURNS_BIDS AS 

/******************************************************************************
   NAME:       PCK_RETURNS_BIDS
   PURPOSE:     DEVUELVE LOS DATOS DE LAS DEVOLUCIONES PARA TRANSMITTRLOS A SIMPLI

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        02/10/2022      reyesros       1. Created this package.
******************************************************************************/

  PROCEDURE SP_BIDS_RETURN_HEADER
                                        (
                                         P_ERROR_CODE         OUT VARCHAR2, --- Código SQL,
                                         P_ERROR_MESSAGE      OUT VARCHAR2,
                                         P_CUR_OUT            OUT SYS_REFCURSOR);
   PROCEDURE SP_BIDS_RETURN_DETAIL
                                        (P_PROCESS_ID         IN NUMBER,
                                         P_ERROR_CODE         OUT VARCHAR2, --- Código SQL
                                         P_ERROR_MESSAGE      OUT VARCHAR2,
                                         P_CUR_OUT            OUT SYS_REFCURSOR);
END PCK_RETURNS_BIDS;
/

