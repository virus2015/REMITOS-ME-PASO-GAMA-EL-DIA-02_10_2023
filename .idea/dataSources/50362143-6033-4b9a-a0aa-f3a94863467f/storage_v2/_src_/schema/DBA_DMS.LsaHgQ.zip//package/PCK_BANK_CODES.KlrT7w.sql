create PACKAGE PCK_BANK_CODES IS

 TYPE bank_codes IS RECORD(
    BANK_CODE CHAR(3 BYTE));

  TYPE bank_codes_row IS RECORD(
    BANK_CODE CHAR(3 BYTE), 
	BANK_NAME VARCHAR2(50 BYTE), 
	CASH_FLAG CHAR(1 BYTE), 
	CHANGE_FLAG CHAR(1 BYTE), 
	DELETE_FLAG CHAR(1 BYTE), 
	UPDATED_AT TIMESTAMP (6), 
	TRANSFER_FLAG CHAR(1 BYTE));

  TYPE bank_codes_tbl IS TABLE OF PCK_BANK_CODES.bank_codes_row;

  TYPE bank_codes_array IS TABLE OF PCK_BANK_CODES.bank_codes;

  FUNCTION fn_insert_bank_codes(p_bank_codes_tbl PCK_BANK_CODES.bank_codes_tbl
       )
        RETURN NUMBER;

  FUNCTION fn_merge_bank_codes(p_bank_codes_tbl PCK_BANK_CODES.bank_codes_tbl
       )
        RETURN NUMBER;

  FUNCTION fn_update_bank_codes(p_bank_codes_tbl PCK_BANK_CODES.bank_codes_tbl
       )
        RETURN NUMBER;

  FUNCTION fn_update_bank_codes_array(p_bank_codes_array PCK_BANK_CODES.bank_codes_array
       )
        RETURN NUMBER;

    procedure sp_transfer_bank_codes_dms
    (	p_bank_code in char,
        p_bank_name   out varchar2, 
        p_cash_flag   out char, 
        p_change_flag out char, 
        p_delete_flag out char, 
        p_updated_at  out timestamp,
        p_transfer_flag  out char,
        p_error_flag out varchar2,
        p_error_code out varchar2,
        p_error_message out varchar2
    );


    FUNCTION fn_transfer_pending_codes_dms
    (	p_bank_codes_tbl out PCK_BANK_CODES.bank_codes_tbl,
        p_error_flag out varchar2,
        p_error_code out varchar2,
        p_error_message out varchar2
    )
    RETURN PCK_BANK_CODES.bank_codes_tbl;

END PCK_BANK_CODES;
/

