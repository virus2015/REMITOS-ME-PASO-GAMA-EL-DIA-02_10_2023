create PACKAGE BODY PCK_COD_MESSAGES AS

/******************************************************************************
   NAME:       SP_SELECT_MESSAGES
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        23/02/2022   reyesros       1. Created this procedure.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     SP_SELECT_MESSAGES
      Sysdate:         23/02/2022
      Date and Time:   23/02/2022, 03:31:44 p. m., and 23/02/2022 03:31:44 p. m.
      Username:        reyesros 
      Table Name:      DBA_DMS.COD_MESSAGES 

******************************************************************************/
  PROCEDURE SP_SELECT_MESSAGES
                                (P_SEND_TO IN VARCHAR2, ---C campaña, Z campaña y zona, A ACCONT
                                 P_FULL_CAMPAIGN IN NUMBER,
                                 P_ZONE IN NUMBER,
                                 P_ACCOUNT IN NUMBER,
                                 P_MAIL IN VARCHAR2,
                                 P_LDC  IN VARCHAR2,
                                 P_REGION IN NUMBER,
                                 P_DIVISION IN NUMBER,
                                 P_ERROR_FLAG         OUT VARCHAR2, --- S = CON ERROR N = SIN ERROR
                                 P_ERROR_CODE         OUT VARCHAR2,
                                 P_ERROR_MESSAGE      OUT VARCHAR2,
                                 P_CURSOR_MESS OUT SYS_REFCURSOR)
  AS

 V_FULL_CAMPAIGN NUMBER (6) := P_FULL_CAMPAIGN;
 V_ZONE NUMBER (4) := P_ZONE;
 V_ACCOUNT NUMBER (12) := P_ACCOUNT;
 V_MAIL  VARCHAR2 (1) := P_MAIL;
 V_LDC   VARCHAR2 (3) := P_LDC;
 V_REGION  NUMBER (6) := P_REGION;
 V_DIVISION  NUMBER (3) := P_DIVISION;
BEGIN
P_ERROR_FLAG := 'N';
        CASE P_SEND_TO
        WHEN 'C' --- CONSULTA POR CAMPAÑA
        THEN
            IF V_FULL_CAMPAIGN IS NOT NULL THEN
              OPEN P_CURSOR_MESS FOR
              SELECT  UPDATED_BY AS USUARIO,
            CREATED_AT AS FECHA_CREACION,
            COD_MESSAGE AS MENSAJE,
            (SELECT END_DATE FROM  DBA_DMS.CAMPAIGNS C
            WHERE C.CAMPAIGN_YEAR = SUBSTR(FULL_CAMPAIGN, 0,4) and campaign = SUBSTR(FULL_CAMPAIGN, 5,2) )as VIGENCIA,
            FULL_CAMPAIGN,
            DECODE (SEND_TO, 'Z', 'ZONA', 'A', 'ACCOUNT', 'OTRO') AS RECEPTOR,
            DECODE (SEND_TO, 'Z', ZONE, 'A', ACCOUNT, 'OTRO') AS DESC_RECEPTOR
            FROM DBA_DMS.COD_MESSAGES M
            WHERE FULL_CAMPAIGN = V_FULL_CAMPAIGN
            ORDER BY CREATED_AT DESC;
            END IF;
            
            WHEN 'Z' --- CONSULTA POR ZONA
        THEN
            IF V_ZONE IS NOT NULL ---AND  V_FULL_CAMPAIGN IS NOT NULL
            THEN
                  OPEN P_CURSOR_MESS FOR
              SELECT  UPDATED_BY AS USUARIO,
            CREATED_AT AS FECHA_CREACION,
            COD_MESSAGE AS MENSAJE,
            (SELECT END_DATE FROM  DBA_DMS.CAMPAIGNS C
            WHERE C.CAMPAIGN_YEAR = SUBSTR(FULL_CAMPAIGN, 0,4) and campaign = SUBSTR(FULL_CAMPAIGN, 5,2) )as VIGENCIA,
            FULL_CAMPAIGN,
            DECODE (SEND_TO, 'Z', 'ZONA', 'A', 'ACCOUNT', 'OTRO') AS RECEPTOR,
            DECODE (SEND_TO, 'Z', ZONE, 'A', ACCOUNT, 'OTRO') AS DESC_RECEPTOR
            FROM DBA_DMS.COD_MESSAGES M
            WHERE ZONE = V_ZONE
            ORDER BY CREATED_AT DESC;
            END IF;
             WHEN 'A' --- CONSULTA POR ZONA
        THEN
            IF P_ACCOUNT IS NOT NULL ---AND  P_FULL_CAMPAIGN IS NOT NULL
            THEN
                            OPEN P_CURSOR_MESS FOR
              SELECT  UPDATED_BY AS USUARIO,
            CREATED_AT AS FECHA_CREACION,
            COD_MESSAGE AS MENSAJE,
            (SELECT END_DATE FROM  DBA_DMS.CAMPAIGNS C
            WHERE C.CAMPAIGN_YEAR = SUBSTR(FULL_CAMPAIGN, 0,4) and campaign = SUBSTR(FULL_CAMPAIGN, 5,2) )as VIGENCIA,
            FULL_CAMPAIGN,
            DECODE (SEND_TO, 'Z', 'ZONA', 'A', 'ACCOUNT', 'OTRO') AS RECEPTOR,
            DECODE (SEND_TO, 'Z', ZONE, 'A', ACCOUNT, 'OTRO') AS DESC_RECEPTOR
            FROM DBA_DMS.COD_MESSAGES M
            WHERE ACCOUNT = P_ACCOUNT
            ORDER BY CREATED_AT DESC;
            END IF;
            END CASE;

               EXCEPTION
             WHEN NO_DATA_FOUND THEN
               OPEN P_CURSOR_MESS FOR
              SELECT  '' USUARIO, '' FECHA_CREACION, '' MENSAJE, '' VIGENCIA, '' FULL_CAMPAIGN, '' RECEPTOR, '' DESC_RECEPTOR
              FROM DUAL;
             WHEN OTHERS THEN
               P_ERROR_CODE := SQLCODE;
                P_ERROR_MESSAGE :=
                    CONCAT (CONCAT (SQLERRM, '  '),
                            DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
                P_ERROR_FLAG := 'S';
END SP_SELECT_MESSAGES;

END PCK_COD_MESSAGES;
/

