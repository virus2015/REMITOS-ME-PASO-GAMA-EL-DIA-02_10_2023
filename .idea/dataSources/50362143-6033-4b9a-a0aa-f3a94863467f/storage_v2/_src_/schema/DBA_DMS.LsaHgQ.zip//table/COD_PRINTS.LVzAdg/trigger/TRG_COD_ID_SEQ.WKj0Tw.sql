create trigger TRG_COD_ID_SEQ
    before insert
    on COD_PRINTS
    for each row
BEGIN
  SELECT COD_ID_SEQ.NEXTVAL
  INTO   :new.COD_ID
  FROM   DUAL;
END TRG_COD_ID_SEQ;
/

