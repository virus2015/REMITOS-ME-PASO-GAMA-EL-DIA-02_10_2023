create PACKAGE BODY         PCK_REPRESENTATIVES
AS
-- Package body

 /**************************************************************************************************************************
   * Prepared statement to update the representatives
   **************************************************************************************************************************/
  updateRepQuery VARCHAR2(800):='UPDATE	REPRESENTATIVES SET '||
	'STATE_CODE=:STATE_CODE, REP_STATUS=:REP_STATUS, '||
	'CHANGE_FLAG=:CHANGE_FLAG,DELETE_FLAG=:DELETE_FLAG,LAST_BILLED_AT=:LAST_BILLED_AT,LAST_BILL_YEAR=:LAST_BILL_YEAR, '||
	'LAST_BILL_CAMPAIGN=:LAST_BILL_CAMPAIGN,TELEPHONE=:TELEPHONE,ZIP=:ZIP,REZONE_FLAG=:REZONE_FLAG, '||
	'PARENT_ACCOUNT=:PARENT_ACCOUNT,UPDATED_AT=:UPDATED_AT,LOS=:LOS,LOA=:LOA,"SECTION"=:SECTION, '||
	'STATE_NAME=:STATE_NAME,DEFAULT_ZONE=:DEFAULT_ZONE,  SALES_LEVEL=:SALES_LEVEL WHERE ACCOUNT=:ACCOUNT';



/***************************************************************************************************************************
   * This cursor retrieves the ZONES data from ORDER_HEADER_OCP table that meet with the status.                                
   *
   * PARAMS:
   *
   *    -   orderStatus: Id of status group.
   *    - processStatus: Status order.   
   *
   **************************************************************************************************************************/
CURSOR zonesCursor(orderStatus NUMBER,processStatus NUMBER) IS SELECT
	DISTINCT("ZONE") AS "ZONE"
FROM
	ORDER_HEADER@SCPIP
WHERE
	ORDER_DATE >= TRUNC( SYSDATE - 1, 'DD' )
	AND ORDER_STATUS = orderStatus
	AND PROCESS_STATUS = processStatus;

  /***************************************************************************************************************************
   * This cursor retrieves the representatives data from ORDER_HEADER_OCP table that meet with the status.                                
   *
   * PARAMS:
   *
   *    -   orderStatus: Id of status group.
   *    - processStatus: Status order.   
   *    -      zoneNumb: Zone number for process.
   **************************************************************************************************************************/
 CURSOR representativesCursor(
	orderStatus NUMBER,
	processStatus NUMBER,
	zoneNumb NUMBER
) IS SELECT
	O.ACCOUNT,	O.STATE_NAME,	O.STATE_CODE,	ZIP,
	O.TELEPHONE,	O.CLUB_TYPE,	O.LENGTH_ASSOC,	O.LENGTH_SERVICE,	O.TOTAL_CUST,	O.BORDER_FLAG,
	O.ZONE, O.NOVA_STATUS,	O.CARRIER_CODE,	O.ROUTE_CODE,O.ORDER_DATE, O.BILL_DATE, O.CAMPAIGN, O.REP_TYPE 
FROM
	ORDER_HEADER@SCPIP O
WHERE
	O.ORDER_STATUS = orderStatus 
	AND O.PROCESS_STATUS = processStatus 
	AND O.ORDER_DATE >= TRUNC( SYSDATE - 1, 'DD' ) 
	AND O.ZONE = zoneNumb;

/************************************************************************************************************************
   * With this function it is formatted the order data from the SCPI database to save them in the CATS database.
   **************************************************************************************************************************/
   FUNCTION toDMSrep(repSCPI REPRESENTANTE) RETURN REPRESENTATIVE 
   IS
      resultVal REPRESENTATIVE;
   BEGIN

	resultVal.ACCOUNT:=repSCPI.ACCOUNT;
-- 	resultVal.ADDRESS1:=repSCPI.ADDRESS1;
-- 	resultVal.ADDRESS2:=repSCPI.ADDRESS2;
-- 	resultVal.ADDRESS3:=repSCPI.ADDRESS3;
 	resultVal.STATE_CODE:=repSCPI.STATE_CODE;
 	resultVal.REP_STATUS:='A';
 	resultVal.CHANGE_FLAG:='F';
 	resultVal.DELETE_FLAG:='F';
 	resultVal.LAST_BILLED_AT:=repSCPI.ORDER_DATE;
 	resultVal.LAST_BILL_YEAR:=SUBSTR(repSCPI.BILL_DATE, 1, 4) ;
	resultVal.LAST_BILL_CAMPAIGN:=SUBSTR(repSCPI.CAMPAIGN, 5);
 	resultVal.TELEPHONE:=repSCPI.TELEPHONE;
 	resultVal.ZIP:=repSCPI.ZIP;
 	resultVal.REZONE_FLAG:='F';
 	resultVal.PARENT_ACCOUNT:=0;
 	resultVal.UPDATED_AT:=SYSDATE;
 	resultVal.LOS:=repSCPI.LENGTH_SERVICE;
 	resultVal.LOA:=repSCPI.LENGTH_ASSOC;
 	resultVal."SECTION":=LPAD(SUBSTR(repSCPI.ROUTE_CODE, 1, 3), 3, '0');
-- 	resultVal.ROUTE:=repSCPI.ROUTE_CODE;
 	resultVal.STATE_NAME:=SUBSTR(repSCPI.STATE_NAME, 5);
 	resultVal.DEFAULT_ZONE:=repSCPI."ZONE";
-- 	resultVal.ACCOUNT_NAME:=repSCPI.ACC_NAME;
 	resultVal.SALES_LEVEL:=TRIM(repSCPI.REP_TYPE);
 	
      RETURN resultVal;
      
  EXCEPTION 
    WHEN OTHERS 
    THEN
    DBMS_OUTPUT.PUT_LINE('Couldnt format the SCPI rep'|| repSCPI.ACCOUNT ||' error ' || SQLCODE);
      
   END toDMSrep;


/**************************************************************************************************************************
   * Import orders from SCPI to CATS database.
   **************************************************************************************************************************/ 
  PROCEDURE updateRepresentativesInfo
  AS
    zonen NUMBER(4):=0;
	repSCPI REPRESENTANTE;
	repDMS REPRESENTATIVE;

  BEGIN
	  
  IF zonesCursor % ISOPEN THEN CLOSE zonesCursor;END IF;
IF representativesCursor % ISOPEN THEN CLOSE representativesCursor;END IF;

    DBMS_OUTPUT.PUT_LINE('inicia el store');
	DBMS_OUTPUT.PUT_LINE('procesos'|| orderStatus|| processStatus);
    OPEN zonesCursor(orderStatus, processStatus);
    DBMS_OUTPUT.PUT_LINE('abrio el cursor seguuuun');
    
    LOOP
    
      FETCH zonesCursor INTO zonen;
      EXIT WHEN zonesCursor%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE('ZONA'||zonen);
IF zonen IS NOT NULL THEN 
      OPEN representativesCursor(orderStatus, processStatus,zonen);
		
 		LOOP
 		FETCH representativesCursor INTO repSCPI;
		
EXIT WHEN representativesCursor%NOTFOUND;
repDMS:=toDMSrep(repSCPI);
 		BEGIN
 		EXECUTE IMMEDIATE updateRepQuery 
 		USING  repDMS.STATE_CODE, repDMS.REP_STATUS, repDMS.CHANGE_FLAG, 
		repDMS.DELETE_FLAG, repDMS.LAST_BILLED_AT, repDMS.LAST_BILL_YEAR, repDMS.LAST_BILL_CAMPAIGN, repDMS.TELEPHONE, repDMS.ZIP, 
		repDMS.REZONE_FLAG, repDMS.PARENT_ACCOUNT, repDMS.UPDATED_AT, repDMS.LOS, repDMS.LOA , repDMS."SECTION",  
		repDMS.STATE_NAME, repDMS.DEFAULT_ZONE, repDMS.SALES_LEVEL,repDMS.ACCOUNT;
		EXCEPTION
				WHEN OTHERS THEN
      			 DBMS_OUTPUT.PUT_LINE('SALIO MAL EL INSERT A dms' || SQLCODE || ' - ' || SQLERRM );
				 END;
		
 		END LOOP;
 		CLOSE representativesCursor;
END IF;
    END LOOP;
                                      
    CLOSE zonesCursor;                                  
   
    IF zonesCursor%ISOPEN
    THEN
      CLOSE zonesCursor;
    END IF;

  END updateRepresentativesInfo;

  


END PCK_REPRESENTATIVES;
/

