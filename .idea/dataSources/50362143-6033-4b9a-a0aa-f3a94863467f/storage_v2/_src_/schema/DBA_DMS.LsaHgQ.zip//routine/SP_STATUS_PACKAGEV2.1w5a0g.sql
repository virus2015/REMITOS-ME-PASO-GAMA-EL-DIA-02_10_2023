create PROCEDURE SP_STATUS_PACKAGEV2 
(
  P_STATUS_PACKAGE_TBL STATUS_PACKAGE_TBL 
) AS 
BEGIN
  FORALL I IN P_STATUS_PACKAGE_TBL.FIRST .. P_STATUS_PACKAGE_TBL.LAST SAVE EXCEPTIONS
  
      insert into package_statuses ( order_id, package_id, updated_at, status )
         values
     ( P_STATUS_PACKAGE_TBL(I).order_id, P_STATUS_PACKAGE_TBL(I).package_id, P_STATUS_PACKAGE_TBL(I).updated_at, P_STATUS_PACKAGE_TBL(I).status );
  
  commit;
  
   EXCEPTION
   WHEN OTHERS
   THEN
      IF SQLCODE = -24381
      THEN
         FOR indx IN 1 .. SQL%BULK_EXCEPTIONS.COUNT
         LOOP
            DBMS_OUTPUT.put_line (
                  SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX
               || ': '
               || SQL%BULK_EXCEPTIONS (indx).ERROR_CODE);
         END LOOP;
      ELSE
         RAISE;
      END IF;
END SP_STATUS_PACKAGEV2;
/

