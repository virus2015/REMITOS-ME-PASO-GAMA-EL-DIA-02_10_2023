create procedure SP_LOAD_PAY_BY_ACC_IN_PROC
(	p_account           in number, 
    p_campaign_year     out number, 
    p_campaign          out number, 
    p_payment_value     out number, 
    p_zone              out number, 
    p_error_flag        out varchar2,
    p_error_code        out varchar2,
    p_error_message     out varchar2
)
is
begin

        SELECT SUBSTR(ORS.FULL_CAMPAIGN,1,4) as campaign_year, SUBSTR(ORS.FULL_CAMPAIGN,5,6) as campaign,
         O.PAYMENT_VALUE AS TRAN_VALUE, ORS.ZONE 
         INTO p_campaign_year, p_campaign, p_payment_value, p_zone 
         FROM scpi_order_headers ORS
         JOIN orders O ON ORS.order_id = O.order_id  
         WHERE O.CHANGE_FLAG='T'
         AND ORS.ACCOUNT = p_account; --AND T.IN_PROCESS='T'

    EXCEPTION
        WHEN OTHERS THEN
         p_error_code := SQLCODE;
         p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
         p_error_flag := 'S';


 end  SP_LOAD_PAY_BY_ACC_IN_PROC;
/

