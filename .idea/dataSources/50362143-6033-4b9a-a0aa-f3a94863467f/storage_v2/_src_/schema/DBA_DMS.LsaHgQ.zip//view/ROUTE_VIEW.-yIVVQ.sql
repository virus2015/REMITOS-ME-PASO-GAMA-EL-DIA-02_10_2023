create view ROUTE_VIEW as
SELECT DISTINCT( SUBSTR(TO_CHAR(re.route, 'FM0000'), 0, 2)) route  FROM representatives  re
             inner join zone_campaigns zc 
             on zc.zone = re.default_zone 
              where  zc.full_campaign = fn_get_current_campaign
                 and zc.division = 1
                 and re.route IS NOT NULL
/

