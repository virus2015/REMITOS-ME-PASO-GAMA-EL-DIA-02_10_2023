create PROCEDURE         SP_SLT_ORD_STAT (
   ordersDMS   OUT SYS_REFCURSOR)
AS
   v_count_registers   NUMBER := 0;
BEGIN
   SELECT LONG_VALUE
     INTO v_count_registers
     FROM PARAMETERS
    WHERE ID = 32;


   OPEN ordersDMS FOR
WITH CA
     AS (SELECT soh.order_id,
                soh.order_number,
                soh.account,
                soh.order_date,
                soh.full_campaign,
                soh.zone,
                soh.acc_name,
                soh.telephone,
                soh.email,
                soh.address1,
                soh.address2,
                soh.address3,
                soh.state_name,
                soh.zip,
                soh.number_boxes,
                soh.cod_amount,
                soh.ord_amount,
                soh.first_order,
                soh.certified_quality,
                soh.credit_check,
                o.processed_at,
                o.process_comment,
                o.approved,
                o.change_flag,
                o.current_amount,
                o.previous_amount,
                o.payment_value,
                o.bank_code,
                o.payment_date,
                o.round_num,
                o.return_reason,
                o.notes,
                o.dlv_typ,
                o.delivery1st,
                o.return_val,
                o.pick_up_point_id,
                o.blocked_status,
                o.updated_at,
                o.stolen,
                r.route,
                r.last_deliver_order AS deliver_order,
                r.section,
                os.updated_at AS status_updated_at,
                os.status,
                r.loa,
                r.cellphone,
                r.parent_account,
                r.SEGMENTATION,
                r.SALES_LEVEL,
                soh.cod
           FROM SCPI_ORDER_HEADERS soh
                INNER JOIN ORDERS o ON o.order_id = soh.order_id
                INNER JOIN ORDERS_STATUSES os ON os.order_id = o.order_id 
                INNER JOIN REPRESENTATIVES r ON r.account = soh.account
          WHERE o.TRANSFER_FLAG = 'D'),
     FEC_MAX
     AS (  SELECT MAX (OS.UPDATED_AT) AS FECHA_MAX, OS.ORDER_ID
             FROM ORDERS_STATUSES OS
                  INNER JOIN CA O ON OS.ORDER_ID = O.ORDER_ID  AND OS.STATUS <> 1
         GROUP BY OS.ORDER_ID),
     PRE_FC
     AS (  SELECT CASE
                     WHEN MAX (O.FULL_CAMPAIGN) IS NULL THEN 0
                     ELSE MAX (O.FULL_CAMPAIGN)
                  END
                     PREVIOUSFULLCAMPAIGN,
                  O.ACCOUNT
             FROM SCPI_ORDER_HEADERS O INNER JOIN CA P ON P.ACCOUNT = O.ACCOUNT
            WHERE O.FULL_CAMPAIGN < (SELECT fn_get_current_campaign FROM DUAL)
         GROUP BY O.ACCOUNT)
  SELECT O.ORDER_ID,
         O.ORDER_NUMBER,
         O.ACCOUNT,
         O.ORDER_DATE,
         O.FULL_CAMPAIGN,
         O.ZONE,
         O.ACC_NAME,
         O.TELEPHONE,
         O.EMAIL,
         O.ADDRESS1,
         O.ADDRESS2,
         O.ADDRESS3,
         O.STATE_NAME,
         O.ZIP,
         O.NUMBER_BOXES,
         O.COD_AMOUNT,
         O.ORD_AMOUNT,
         O.FIRST_ORDER,
         O.CERTIFIED_QUALITY,
         O.CREDIT_CHECK,
         O.PROCESSED_AT,
         O.PROCESS_COMMENT,
         O.APPROVED,
         O.CHANGE_FLAG,
         O.CURRENT_AMOUNT,
         O.PREVIOUS_AMOUNT,
         O.PAYMENT_VALUE,
         O.BANK_CODE,
         O.PAYMENT_DATE,
         O.ROUND_NUM,
         O.RETURN_REASON,
         O.NOTES,
         O.DLV_TYP,
         O.DELIVERY1ST,
         O.RETURN_VAL,
         --- O.PICK_UP_POINT_ID,
         DECODE (NR,1,null,O.PICK_UP_POINT_ID) PICK_UP_POINT_ID, --SE QUITA PUP PARA MARCA NR POR CAMBIO DE DIRECCÓN DE LA REPRE
         DECODE (NR,1, -99,0, O.BLOCKED_STATUS, NULL,  O.BLOCKED_STATUS ) AS BLOCKED_STATUS, --SE AGREGA MARCA NR POR CAMBIO DE DIRECCÓN DE LA REPRE
         --O.BLOCKED_STATUS,
         O.UPDATED_AT,
         O.UPDATED_AT,
         O.STOLEN,
         O.ROUTE,
         O.DELIVER_ORDER,
         O.SECTION,
         O.STATUS_UPDATED_AT,
         O.STATUS,
         o.cellphone,
         P.ACCOUNT AS PARENT_ACCOUNT,
         P.DEFAULT_ZONE AS PARENT_ZONE,
         P.ACCOUNT_NAME AS PARENT_ACC_NAME,
         P.CELLPHONE AS PARENT_CELLPHONE,
         FN_GET_PREMIOS_NAR_SCPI (O.ORDER_NUMBER, O.FULL_CAMPAIGN) PRIZES,
         O.SEGMENTATION,
         O.SALES_LEVEL,
         O.COD,
         NVL (J.PREVIOUSFULLCAMPAIGN, 0) AS PREVIOUSFULLCAMPAIGN
    FROM CA O
         LEFT JOIN REPRESENTATIVES P ON O.PARENT_ACCOUNT = P.ACCOUNT
         LEFT JOIN (select * from DBA_DMS.repres_address where nr = 1 )D ON ( O.ACCOUNT = D.ACCOUNT AND  O.FULL_CAMPAIGN = D.NR_CAMPAIGN)--- SE  AGREGA VALIDACIÓN DE MARCA NR POR CAMBIO DE REPRESENTANTE
         LEFT JOIN PRE_FC J ON O.ACCOUNT = J.ACCOUNT
         INNER JOIN FEC_MAX F ON O.ORDER_ID = F.ORDER_ID
   WHERE O.status_updated_at = F.FECHA_MAX AND ROWNUM <= v_count_registers
ORDER BY o.ORDER_ID ASC, o.status ASC;


EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
         'DBA_DMS.SP_SLT_ORD_STAT',
            'NO SE ENCUENTRA NINGUN REGISTRO',
         SQLCODE,
         SQLERRM);
   WHEN OTHERS
   THEN
      DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
         'DBA_DMS.SP_SLT_ORD_STAT',
            'ERROR EN LA CONSULTA TRANSFER_FLAG = D',
         SQLCODE,
         SQLERRM);

END SP_SLT_ORD_STAT;
/

