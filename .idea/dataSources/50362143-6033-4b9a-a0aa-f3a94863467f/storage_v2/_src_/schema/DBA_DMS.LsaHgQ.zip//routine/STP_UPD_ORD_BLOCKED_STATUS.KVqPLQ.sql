create PROCEDURE STP_UPD_ORD_BLOCKED_STATUS
(
  P_ORDER_UPD_BLOCKED_TBL ORDER_UPD_BLOCKED_TBL, 
  P_ERROR_FLAG OUT VARCHAR2,
  P_ERROR_MESSAGE OUT VARCHAR2
  --P_ERROR_MESSAGE OUT orders_id_array
) AS
BEGIN

  P_ERROR_FLAG := 'N';

  FORALL I IN P_ORDER_UPD_BLOCKED_TBL.FIRST .. P_ORDER_UPD_BLOCKED_TBL.LAST SAVE EXCEPTIONS

      update orders set
                  blocked_status = P_ORDER_UPD_BLOCKED_TBL(I).P_BLOCKED_STATUS,
                  Transfer_Flag = 'E',
                  UPDATED_AT = CURRENT_TIMESTAMP
        where order_id = P_ORDER_UPD_BLOCKED_TBL(I).P_ORDER_ID;

   commit;

   EXCEPTION  
   WHEN std_errs.failure_in_forall  
   THEN  

   P_ERROR_FLAG := 'S';

      DBMS_OUTPUT.put_line (SQLERRM);  
      DBMS_OUTPUT.put_line (  
         'Updated ' || SQL%ROWCOUNT || ' rows.');  

      FOR indx IN 1 .. SQL%BULK_EXCEPTIONS.COUNT  
      LOOP  
         --DBMS_OUTPUT.put_line (
         P_ERROR_MESSAGE := P_ORDER_UPD_BLOCKED_TBL( SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX).P_ORDER_ID
            || SQLERRM ( -1 * SQL%BULK_EXCEPTIONS (indx).ERROR_CODE);

      END LOOP;
      ROLLBACK;
END STP_UPD_ORD_BLOCKED_STATUS;
/

