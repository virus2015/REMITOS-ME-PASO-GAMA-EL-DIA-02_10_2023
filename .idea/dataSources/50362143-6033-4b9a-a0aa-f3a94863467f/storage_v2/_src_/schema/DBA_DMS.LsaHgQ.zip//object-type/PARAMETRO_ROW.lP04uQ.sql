create TYPE           "PARAMETRO_ROW"                                          AS OBJECT 
(
    KEY VARCHAR2(100),
    STRING_VALUE VARCHAR2(4000)
)
/

