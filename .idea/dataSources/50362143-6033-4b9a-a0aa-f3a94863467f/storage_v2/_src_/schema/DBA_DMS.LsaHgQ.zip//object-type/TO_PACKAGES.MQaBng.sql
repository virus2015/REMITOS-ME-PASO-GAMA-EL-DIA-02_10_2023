create type         to_packages as object
(
ID_PACKAGES number(38)
)
/

