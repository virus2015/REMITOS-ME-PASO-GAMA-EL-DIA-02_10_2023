create PROCEDURE         SP_INS_REJECT_ORDER_SIMPLI 
(
  P_ID_ORDER_ERROR IN VARCHAR2,
  P_MENSAJE_ERROR IN VARCHAR2,
  P_ERROR_FLAG OUT VARCHAR2,
  P_ERROR_CODE OUT VARCHAR2,
  P_ERROR_MESSAGE OUT VARCHAR2
) IS
  --V_ID NUMBER(38,0);
BEGIN

  p_error_flag := 'N';
  
  if P_ID_ORDER_ERROR is not null then
     if P_ID_ORDER_ERROR = '' then
         P_ERROR_FLAG := 'S';
         P_ERROR_CODE := '1';
         P_ERROR_MESSAGE := 'ID.ORDEN VACIO';
     end if;
  else
    P_ERROR_FLAG := 'S';
    P_ERROR_CODE := '1';
    P_ERROR_MESSAGE := 'ID.ORDEN NULO';
  end if;
  /*
  select max(id) into V_ID from error_log;
  
  if V_ID is null then
     V_ID := 1;
  else
     V_ID := V_ID + 1;
  end if;
  */
  insert into error_log( id,rejected_id,rejection_type,message ) values ( ERROR_LOG_SEQ.NEXTVAL, P_ID_ORDER_ERROR, 'ORDER', P_MENSAJE_ERROR);
  
  commit;
  
  EXCEPTION
      WHEN OTHERS THEN
         p_error_code := SQLCODE;
         p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
         p_error_flag := 'S';
         
END SP_INS_REJECT_ORDER_SIMPLI;
/

