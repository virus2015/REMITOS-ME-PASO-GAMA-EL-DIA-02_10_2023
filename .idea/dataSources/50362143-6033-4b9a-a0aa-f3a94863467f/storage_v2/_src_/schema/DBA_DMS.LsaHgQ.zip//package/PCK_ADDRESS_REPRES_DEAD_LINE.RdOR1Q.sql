create PACKAGE         PCK_ADDRESS_REPRES_DEAD_LINE AS
/******************************************************************************
   NAME:       PCK_ADDRESS_REPRES_DEAD_LINE
   PURPOSE:    CÁLCULA LA FECHA LÍMITE DE INICIO Y FIN PARA EL ENVÍO DE DIRECCIÓNES A BIDS
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        19/1272022      reyesros       1. Created this package.
******************************************************************************/

  FUNCTION FN_ADDRESS_REPRES_DEAD_LINE
                                        (P_ZONE   NUMBER) RETURN SYS_REFCURSOR;



  FUNCTION FN_NR_ADDRESS_REPRES
                                        (P_ACCOUNT  NUMBER, P_FULLCAMPAIGN   NUMBER) RETURN NUMBER;




END PCK_ADDRESS_REPRES_DEAD_LINE;
/

