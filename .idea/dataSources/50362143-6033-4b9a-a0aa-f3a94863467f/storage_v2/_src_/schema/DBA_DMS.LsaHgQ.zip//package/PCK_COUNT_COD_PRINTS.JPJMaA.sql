create PACKAGE         PCK_COUNT_COD_PRINTS
AS
    /******************************************************************************
       NAME:       PCK_COUNT_COD_PRINTS
       PURPOSE:    Cuenta paquetes por zona y full campaign

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        06/08/2021      reyesros       1. Created this package.
    ******************************************************************************/
    TYPE CURSOR_TP IS REF CURSOR;

    PROCEDURE SP_COD_PRINT (
        P_ZONE            IN     NUMBER,
        P_FULL_CAMPAIGN   IN     NUMBER,
        P_COD_TYPE_P      IN     VARCHAR2,                       ----N ó P ó C
        P_COD_TYPE_A      IN     VARCHAR2,                        ----P ó NULL
        P_CURSOR             OUT DBA_DMS.PCK_COUNT_COD_PRINTS.CURSOR_TP,
        P_ERROR_FLAG         OUT VARCHAR2,            --- S = error, N = éxito
        P_ERROR_CODE         OUT VARCHAR2,                      --- Código SQL
        P_ERROR_MESSAGE      OUT VARCHAR2               --- mensaje de salida)
                                         );
END PCK_COUNT_COD_PRINTS;
/

