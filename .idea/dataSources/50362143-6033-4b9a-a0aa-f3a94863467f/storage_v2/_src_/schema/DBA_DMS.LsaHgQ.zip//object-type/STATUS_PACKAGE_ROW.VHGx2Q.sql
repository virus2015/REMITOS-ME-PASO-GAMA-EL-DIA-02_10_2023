create TYPE           "STATUS_PACKAGE_ROW"                                          AS OBJECT 
(
    ORDER_ID NUMBER(19,0),
    PACKAGE_ID NUMBER(19,0),
    UPDATED_AT TIMESTAMP(6),
    STATUS NUMBER(4,0)
)
/

