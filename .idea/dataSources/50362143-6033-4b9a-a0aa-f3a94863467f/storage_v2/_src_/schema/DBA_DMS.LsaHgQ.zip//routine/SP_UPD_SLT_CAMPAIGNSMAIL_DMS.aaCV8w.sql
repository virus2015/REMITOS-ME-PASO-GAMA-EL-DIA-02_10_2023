create PROCEDURE         SP_UPD_SLT_CAMPAIGNSMAIL_DMS (
  p_campaign_year IN VARCHAR2,
  p_campaign IN VARCHAR2)
  IS
  
  v_campaign_year number(4,0) ; 
  v_campaign number(2,0) ; 
  	p_change_flag char(1 byte) ; 

BEGIN

  if p_campaign_year is not null then
     if p_campaign_year = '' then
         v_campaign_year := null;
     else
         v_campaign_year := to_number(p_campaign_year);
     end if;
  else
    v_campaign_year := null;
  end if;

  if p_campaign is not null then
     if p_campaign = '' then
         v_campaign := null;
     else
         v_campaign := to_number(p_campaign);
     end if;
  else
    v_campaign := null;
  end if;

  if ( v_campaign_year is not null and v_campaign is not null ) then



         p_change_flag := 'F';
        UPDATE CAMPAIGNS SET change_flag = p_change_flag WHERE campaign_year = v_campaign_year AND campaign = v_campaign AND change_flag = 'T';
        UPDATE MAILS SET change_flag = p_change_flag WHERE campaign_year = v_campaign_year AND campaign = v_campaign AND change_flag = 'T';
        COMMIT;



  end if;

  EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20001,
                            'HA OCURRIDO UN ERROR AL INTENTAR ACTUALIZAR  ' || v_campaign || '-'  || v_campaign_year ||' - ' ||
                            SQLCODE || ' -ERROR- ' || SQLERRM);



END SP_UPD_SLT_CAMPAIGNSMAIL_DMS;
/

