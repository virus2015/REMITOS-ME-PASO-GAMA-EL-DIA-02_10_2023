create PROCEDURE         SP_ORDERS_SCIMEI 
(
   PA_FULL_CAMPAIGN   IN NUMBER,
   PA_ID_ORDERS       IN DBA_DMS.TY_ORDERS, 
   PA_CODE           OUT INTEGER,
   PA_MESSAGE        OUT VARCHAR2
)
IS

VL_ERROR VARCHAR2 (300) := ' ';

CSL_ARROW_INDICATOR   CONSTANT VARCHAR2 (2) := '->';
CSL_MESSAGE           CONSTANT VARCHAR2 (15) :='Proceso Exitoso';
CSL_1000              CONSTANT SIMPLE_INTEGER := 1000;
CSL_100               CONSTANT SIMPLE_INTEGER := 100;
CSL_11                CONSTANT SIMPLE_INTEGER := 11;  
CSL_8                 CONSTANT SIMPLE_INTEGER := 8;
CSL_0                 CONSTANT SIMPLE_INTEGER := 0;
CSL_3                 CONSTANT SIMPLE_INTEGER := 3;
CSL_ONE               CONSTANT SIMPLE_INTEGER := 1;
CSL_ZERO              CONSTANT SIMPLE_INTEGER := 0;
CSL_SUCC              CONSTANT SIMPLE_INTEGER := 0;
CSL_300               CONSTANT SIMPLE_INTEGER := 300;

TYPE REC_ORDERS_SCIMEI IS RECORD
   (
    ID_ORDER        NUMBER(38),
    CAMPAIGN        NUMBER(6),
    ZONE            NUMBER(5),
    FSC             VARCHAR2(20),
    LINENUMBER      VARCHAR2(20),
    DESC1           VARCHAR2(300),
    DELIVEREDPIECES NUMBER(4),
    PRODUCTCATEGORY NUMBER(4),
    BARCODE         VARCHAR2(25),
    PRICE           NUMBER(12,2),
    ID_CARTON       VARCHAR2(25),
    FLYER_PRICE     NUMBER(12,2) 
   );

TYPE TAB_ORDERS_SCIMEI IS TABLE OF REC_ORDERS_SCIMEI;

VLTAB_ORD_SCIMEI  TAB_ORDERS_SCIMEI;
VL_IDX            NUMBER (38);

BEGIN

        SELECT OH.ID_ORDER AS ORDER_ID,
               OH.CAMPAIGN AS FULL_CAMPAIGN,
               OH.ZONE,
               CC.FSC,
               CC.LINENUMBER AS LINE_NUMBER,
               ID.DESC1 AS DESCRIPTION,
               CC.DELIVEREDPIECES AS QUANTITY,
               CC.PRODUCTCATEGORY,
               LPAD (TO_NUMBER (C.ORDERNUM) * CSL_1000 + TO_NUMBER (C.CARTON),CSL_11,'0')|| DBA_DMS.FN_DIGITO_VERIFICADOR (CONCAT (LPAD (TO_CHAR (C.ORDERNUM), CSL_8, TO_CHAR (CSL_0)),LPAD (TO_CHAR (C.CARTON), CSL_3, TO_CHAR (CSL_0))))AS BARCODE,
               P_SCPI.PRICE,
               C_SCPI.ID_CARTON,
               P_SCPI.FLYER_PRICE
          BULK COLLECT INTO VLTAB_ORD_SCIMEI  
          FROM CTS.ORDERS@CATS O
    INNER JOIN CTS.CARTON@CATS C  ON O.ORDERNUM = C.ORDERNUM
                                 AND O.CAMPYEAR = C.CAMPYEAR
                                 AND O.CAMPAIGN = C.CAMPAIGN
    INNER JOIN DBA_SCPI.CARTON C_SCPI ON LPAD (TO_NUMBER (C.ORDERNUM) * CSL_1000 + TO_NUMBER (C.CARTON), CSL_11,'0') = C_SCPI.CARTON_CODE
     LEFT JOIN CTS.CARTONCONTENT@CATS CC ON CC.ORDERNUM = C.ORDERNUM
                                        AND CC.CAMPYEAR = C.CAMPYEAR
                                        AND CC.CAMPAIGN = C.CAMPAIGN
                                        AND CC.CARTON = C.CARTON
          JOIN DBA_SCPI.PRODUCT P_SCPI  ON P_SCPI.ID_CARTON = C_SCPI.ID_CARTON
                                       AND P_SCPI.FSC = CC.FSC
                                       AND P_SCPI.LINE_NUMBER = CC.LINENUMBER
                                       AND MOD (P_SCPI.CAMPAIGN, CSL_100) = TO_NUMBER (CC.CAMPAIGN)
                                       AND TRUNC (P_SCPI.CAMPAIGN / CSL_100) = TO_NUMBER (CC.CAMPYEAR)
          JOIN DBA_SCPI.ITEM_DATA   ID  ON ID.CAMPAIGN = C.CAMPAIGN
                                       AND ID.YEAR = C.CAMPYEAR
                                       AND ID.FSC = CC.FSC
                                       AND ID.LINNO = CC.LINENUMBER
          JOIN DBA_SCPI.ORDER_HEADER OH ON OH.ORDER_NUMBER = O.ORDERNUM
          JOIN TABLE(PA_ID_ORDERS) TY_ORD_ID ON  OH.ID_ORDER = TY_ORD_ID.ID_ORDER
         WHERE CC.DELIVEREDPIECES > CSL_ZERO
            AND OH.CAMPAIGN = PA_FULL_CAMPAIGN
      ORDER BY C_SCPI.ID_ORDER;
      
      
      EXECUTE IMMEDIATE ('TRUNCATE TABLE DBA_DMS.ORDERS_CATS_SCIMEI_WRK');
      
       VL_IDX := VLTAB_ORD_SCIMEI.FIRST;
       
     WHILE (VL_IDX IS NOT NULL)
          LOOP
          
                INSERT INTO DBA_DMS.ORDERS_CATS_SCIMEI_WRK (ID_ORDER,
                                                         CAMPAIGN,
                                                         ZONE,
                                                         FSC,
                                                         LINENUMBER,
                                                         DESC1,
                                                         DELIVEREDPIECES,
                                                         PRODUCTCATEGORY,
                                                         BARCODE,
                                                         PRICE,
                                                         ID_CARTON,
                                                         FLYER_PRICE)
                     VALUES (VLTAB_ORD_SCIMEI (VL_IDX).ID_ORDER,
                             VLTAB_ORD_SCIMEI (VL_IDX).CAMPAIGN,
                             VLTAB_ORD_SCIMEI (VL_IDX).ZONE,
                             VLTAB_ORD_SCIMEI (VL_IDX).FSC,
                             VLTAB_ORD_SCIMEI (VL_IDX).LINENUMBER,
                             VLTAB_ORD_SCIMEI (VL_IDX).DESC1,
                             VLTAB_ORD_SCIMEI (VL_IDX).DELIVEREDPIECES,
                             VLTAB_ORD_SCIMEI (VL_IDX).PRODUCTCATEGORY,
                             VLTAB_ORD_SCIMEI (VL_IDX).BARCODE,
                             VLTAB_ORD_SCIMEI (VL_IDX).PRICE,
                             VLTAB_ORD_SCIMEI (VL_IDX).ID_CARTON,
                             VLTAB_ORD_SCIMEI (VL_IDX).FLYER_PRICE);
                         

                          VL_IDX := VLTAB_ORD_SCIMEI.NEXT (VL_IDX);
          
          END LOOP;
          
COMMIT;

      PA_CODE := CSL_SUCC;
      PA_MESSAGE := CSL_MESSAGE;

EXCEPTION

WHEN OTHERS
   THEN
      ROLLBACK;
      VL_ERROR := SUBSTR (
               DBMS_UTILITY.FORMAT_ERROR_STACK
            || CSL_ARROW_INDICATOR
            || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
            CSL_ONE,
            CSL_300);

      PA_CODE := SQLCODE;
      PA_MESSAGE := VL_ERROR;

END SP_ORDERS_SCIMEI;
/

