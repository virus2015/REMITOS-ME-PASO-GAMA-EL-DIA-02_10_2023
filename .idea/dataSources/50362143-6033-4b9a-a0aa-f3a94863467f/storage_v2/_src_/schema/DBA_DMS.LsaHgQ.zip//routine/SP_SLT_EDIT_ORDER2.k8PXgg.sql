create PROCEDURE SP_SLT_EDIT_ORDER2 
(
  ordersDMS OUT SYS_REFCURSOR 
) AS 

    v_count_registers number := 0;

BEGIN

    SELECT LONG_VALUE
      INTO v_count_registers  
      FROM PARAMETERS
     WHERE ID = 22;


    OPEN ordersDMS FOR

    select * from (
     select order_id ,order_number,account,order_date,full_campaign,zone,
        acc_name,telephone,email,address1,address2,address3,state_name,
        zip, number_boxes,cod_amount,ord_amount,first_order,
        current_amount,previous_amount,payment_value,bank_code,payment_date,
        round_num, return_reason, notes, dlv_typ, delivery1st, return_val,
        pick_up_point_id, blocked_status, updated_at, stolen, route, deliver_order, section,
        max(status_updated_at) as status_updated_at, max(status) as status from (
     
     SELECT  soh.order_id ,soh.order_number,soh.account,soh.order_date,soh.full_campaign,soh.zone,
        soh.acc_name,soh.telephone,soh.email,soh.address1,soh.address2, soh.address3, soh.state_name,
        soh.zip, soh.number_boxes,soh.cod_amount,soh.ord_amount,soh.first_order,
        o.current_amount,o.previous_amount,o.payment_value,o.bank_code,o.payment_date,
        o.round_num, o.return_reason, o.notes, o.dlv_typ, o.delivery1st, o.return_val,
        o.pick_up_point_id, o.blocked_status, o.updated_at, o.stolen, o.route, o.deliver_order, r.section, os.updated_at as status_updated_at,
        os.status

      FROM SCPI_ORDER_HEADERS soh
      INNER JOIN ORDERS o on o.order_id = soh.order_id
      INNER JOIN ORDERS_STATUSES os on os.order_id = o.order_id
      INNER JOIN representatives r on r.account = soh.account and r.default_zone = soh.zone
      WHERE o.transfer_flag = 'E'  
      ORDER BY ORDER_ID ASC, os.status ASC
    )
    GROUP BY order_id ,order_number,account,order_date,full_campaign,zone,
        acc_name,telephone,email,address1,address2,address3,state_name,
        zip, number_boxes,cod_amount,ord_amount,first_order,
        current_amount,previous_amount,payment_value,bank_code,payment_date,
        round_num, return_reason, notes, dlv_typ, delivery1st, return_val,
        pick_up_point_id, blocked_status, updated_at, stolen, route, deliver_order, section
    ORDER BY ORDER_ID ASC
    )
    where ROWNUM <= v_count_registers;
END SP_SLT_EDIT_ORDER2;
/

