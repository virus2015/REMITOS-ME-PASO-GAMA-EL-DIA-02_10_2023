create trigger TRG_ORD_STATUSES_OURS
    before insert or update
    on ORDERS_STATUSES
    for each row
    when (new.status in (2, 3, 13))
BEGIN
    update ORDERS set TRANSFER_FLAG = 'D',
                      updated_at = current_timestamp
    where ORDER_ID = :new.ORDER_ID;
END;
/

