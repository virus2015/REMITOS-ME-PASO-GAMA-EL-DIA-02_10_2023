create FUNCTION         FN_PREVIOUS_CAMPAIGN(P_FULL_CAMPAIGN IN NUMBER,--- campaña base
		P_NUM_CAMP_BEFORE IN NUMBER)--- número de campañas que se desea restar
	RETURN NUMBER
/******************************************************************************
NAME:       DBA_DMS.FN_PREVIOUS_CAMPAIGN
PURPOSE:   Obtener la campaña anterior en base al numero de campaña que se desea retroceder y la campaña recibida
REVISIONS:
 Ver        Date        Author           Description
---------  ----------  ---------------  ------------------------------------
1.0        05/11/2021   ROSSANA REYES  1. Created this procedure.

Object Name:     FN_PREVIOUS_CAMPAIGN
Sysdate:         09/11/2021
Date and Time:   09/11/2021, 10:03:05 a. m.
Username:        ROSSANA REYES
Table Name:      N/A

******************************************************************************/

IS 
	V_YEAR NUMBER (4);
	V_CAMPAIGN NUMBER (2);
	V_FULLCAMPAGIN NUMBER (6) := P_FULL_CAMPAIGN;
    V_NUM_CAMP_BEFORE NUMBER (4) := P_NUM_CAMP_BEFORE;
	V_MAX_CAMP NUMBER;
BEGIN
	V_MAX_CAMP := 19; -- NUMERO DE CAMPAÑAS MAXIMO

	V_CAMPAIGN := MOD(V_FULLCAMPAGIN,100) ;
	V_YEAR := (V_FULLCAMPAGIN - V_CAMPAIGN) / 100;

	IF(V_CAMPAIGN <= V_NUM_CAMP_BEFORE) THEN
		V_CAMPAIGN := V_MAX_CAMP + V_CAMPAIGN - V_NUM_CAMP_BEFORE;
		V_YEAR := V_YEAR - 1;
	ELSE
		V_CAMPAIGN := V_CAMPAIGN - V_NUM_CAMP_BEFORE;
	END IF;

	RETURN (V_YEAR * 100) + V_CAMPAIGN;
END;
/

