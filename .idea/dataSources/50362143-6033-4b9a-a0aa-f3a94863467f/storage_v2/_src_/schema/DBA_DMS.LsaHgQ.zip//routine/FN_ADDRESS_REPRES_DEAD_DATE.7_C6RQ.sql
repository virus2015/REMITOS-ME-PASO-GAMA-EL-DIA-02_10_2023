create FUNCTION         FN_ADDRESS_REPRES_DEAD_DATE(P_ZONE NUMBER,P_ZONE_DESTINO NUMBER)
        RETURN SYS_REFCURSOR
    AS
        V_ZONE                              NUMBER (4) := P_ZONE;
        V_ZONE_DESTINO                     NUMBER (4) := P_ZONE_DESTINO;

        TYPE TYP_REF_CUR IS REF CURSOR;

        V_REF_CUR                        TYP_REF_CUR;
        V_FULL_CAMPAIGN                  NUMBER (8);
        V_FULL_CAMPAIGN_DESTINO          NUMBER (8);
        V_COUNT_CAMPAIGN                 NUMBER (2);
        V_COUNT_ZONE_CAMPAIGN            NUMBER (2);
        V_COUNT_ZONE_CAMPAIGN_DESTINO    NUMBER (2);
        V_COUNT_ZONE_ON_DEADLINE         NUMBER (2);
        V_COUNT_ZONE_ON_DEADLINE_DEST    NUMBER (2);
        V_TOTAL_DAYS_INI                 NUMBER (2) := 2;
        V_TOTAL_DAYS_END                 NUMBER (2) := 0;
        V_TOTAL_DAYS_INI_DEST            NUMBER (2) := 2;
        V_TOTAL_DAYS_END_DEST            NUMBER (2) := 0;
    BEGIN
        --- VALIDA QUE EXISTAN DATOS EN CAMPAIGN
        SELECT COUNT (*)
          INTO V_COUNT_CAMPAIGN
          FROM CAMPAIGNS
         WHERE     CURRENT_TIMESTAMP BETWEEN START_DATE AND END_DATE
               AND CAMPAIGN BETWEEN 1 AND 20;

        ---- SETEA CAMPAÑA CURRENT
        SELECT (CAMPAIGN_YEAR * 100 + CAMPAIGN)
          INTO V_FULL_CAMPAIGN
          FROM CAMPAIGNS
         WHERE     CURRENT_TIMESTAMP BETWEEN START_DATE AND END_DATE
               AND CAMPAIGN BETWEEN 1 AND 20;

        ---- VALIDA  QUE EXISTAN DATOS EN ZONE_CAMPAIGN
        SELECT COUNT (*)
          INTO V_COUNT_ZONE_CAMPAIGN
          FROM DBA_DMS.zone_campaigns
         WHERE zone = V_ZONE AND FULL_CAMPAIGN = V_FULL_CAMPAIGN;


         ---- VALIDA  QUE EXISTAN DATOS EN ZONE_CAMPAIGN---DESTINO
        SELECT COUNT (*)
          INTO V_COUNT_ZONE_CAMPAIGN_DESTINO
          FROM DBA_DMS.zone_campaigns
         WHERE zone = V_ZONE_DESTINO AND FULL_CAMPAIGN = V_FULL_CAMPAIGN;

        IF V_COUNT_ZONE_CAMPAIGN > 0 AND V_COUNT_CAMPAIGN > 0 and V_COUNT_ZONE_CAMPAIGN_DESTINO >0
        THEN                                          --- ESTA EN SU DEAD LINE
            SELECT COUNT (*)
              INTO V_COUNT_ZONE_ON_DEADLINE
              FROM DBA_DMS.zone_campaigns
             WHERE     zone = V_ZONE
                      AND  full_campaign = (select (CAMPAIGN_YEAR*100+CAMPAIGN) 
        from CAMPAIGNS where current_timestamp between START_DATE and END_DATE and CAMPAIGN between 1 and 20)
         AND  TRUNC (billed_at+V_TOTAL_DAYS_END) >= TRUNC (SYSDATE); --- YA FACTURÓ

          SELECT COUNT (*)
              INTO V_COUNT_ZONE_ON_DEADLINE_DEST
              FROM DBA_DMS.zone_campaigns
             WHERE     zone = V_ZONE
                      AND  full_campaign = (select (CAMPAIGN_YEAR*100+CAMPAIGN) 
        from CAMPAIGNS where current_timestamp between START_DATE and END_DATE and CAMPAIGN between 1 and 20)
         AND  TRUNC (billed_at+V_TOTAL_DAYS_END) >= TRUNC (SYSDATE); --- YA FACTURÓ


            IF V_COUNT_ZONE_ON_DEADLINE > 0 and V_COUNT_ZONE_ON_DEADLINE_DEST >0
            THEN                                 --- PONLE LA CAMPAÑA ANTERIOR
                SELECT FULL_CAMPAIGN
                  INTO V_FULL_CAMPAIGN
                  FROM DBA_DMS.zone_campaigns
                 WHERE     zone = V_ZONE
                     AND  full_campaign = (select (CAMPAIGN_YEAR*100+CAMPAIGN) 
        from CAMPAIGNS where current_timestamp between START_DATE and END_DATE and CAMPAIGN between 1 and 20)
         AND  TRUNC (billed_at+V_TOTAL_DAYS_END) >= TRUNC (SYSDATE); --- YA FACTURÓ
         ---DESTINO
          SELECT FULL_CAMPAIGN
                  INTO V_FULL_CAMPAIGN_DESTINO
                  FROM DBA_DMS.zone_campaigns
                 WHERE     zone = V_ZONE_DESTINO
                     AND  full_campaign = (select (CAMPAIGN_YEAR*100+CAMPAIGN) 
        from CAMPAIGNS where current_timestamp between START_DATE and END_DATE and CAMPAIGN between 1 and 20)
         AND  TRUNC (billed_at+V_TOTAL_DAYS_END) >= TRUNC (SYSDATE); --- YA FACTURÓ


                OPEN V_REF_CUR FOR
               with V_REF_CUR_01 as(
SELECT  TO_CHAR (billed_at - V_TOTAL_DAYS_INI,
                                    'DD/MM/YYYY')    AS START_DEADLINE_ACTUAL, --- 1 DÍA ANTES DE LA FACTURA
                          -- TO_CHAR (FIRST_ATTEMPT_AT + V_TOTAL_DAYS_END,  'DD/MM/YYYY')    AS END_DEADLINE_ACTUAL, --- DOS DÍAS DESÚES DEL PRIMER REPARTO SE CAMBIA POR SOLICITUD DE NEGOCIO
                          TO_CHAR (billed_at + 0,  'DD/MM/YYYY')    AS END_DEADLINE_ACTUAL, --- CUATRO DÍAS DESPUÉS DE LA FACTURA
                           FULL_CAMPAIGN AS FULL_CAMPAIGN_ACTUAL,zone as ZONA_ACTUAL
                      FROM DBA_DMS.zone_campaigns
                     WHERE zone = V_ZONE AND FULL_CAMPAIGN  = V_FULL_CAMPAIGN
                     ), V_REF_CUR_02 as(
                     SELECT  TO_CHAR (billed_at - V_TOTAL_DAYS_INI_DEST,
                                    'DD/MM/YYYY')    AS START_DEADLINE_DESTINO, --- 1 DÍA ANTES DE LA FACTURA
                          -- TO_CHAR (FIRST_ATTEMPT_AT + V_TOTAL_DAYS_END,  'DD/MM/YYYY')    AS END_DEADLINE_ACTUAL, --- DOS DÍAS DESÚES DEL PRIMER REPARTO SE CAMBIA POR SOLICITUD DE NEGOCIO
                          TO_CHAR (billed_at + V_TOTAL_DAYS_END_DEST,  'DD/MM/YYYY')    AS END_DEADLINE_DESTINO, --- CUATRO DÍAS DESPUÉS DE LA FACTURA
                           FULL_CAMPAIGN,zone as ZONA
                      FROM DBA_DMS.zone_campaigns
                     WHERE zone = V_ZONE_DESTINO AND FULL_CAMPAIGN = V_FULL_CAMPAIGN
                     )                     
                      select  V1.*,V2.START_DEADLINE_DESTINO,V2.END_DEADLINE_DESTINO,V2.FULL_CAMPAIGN AS FULL_CAMPAIGN_DESTINO,
                     V2.ZONA AS ZONA_DESTINO
                     from V_REF_CUR_01 v1
                     left join V_REF_CUR_02 v2                     
                     on v1.FULL_CAMPAIGN_ACTUAL = v2.FULL_CAMPAIGN;    



                RETURN V_REF_CUR;



            ELSE ---- SI YA PASÓ SU DEAD LINE, BUSCA LOS DATOS CON LA SIGUIENTE CAMPAÑA LA SIGUIENTE CAMPAÑA
                OPEN V_REF_CUR FOR
                              with    V_REF_CUR_03 as(      
      SELECT 1 as id_zone,TO_CHAR (MIN(billed_at) - V_TOTAL_DAYS_INI,
                                    'DD/MM/YYYY')    AS START_DEADLINE_ACTUAL, --- 1 DÍA ANTES DE LA FACTURA
                             -- TO_CHAR (FIRST_ATTEMPT_AT + V_TOTAL_DAYS_END,  'DD/MM/YYYY')    AS END_DEADLINE_ACTUAL, --- DOS DÍAS DESÚES DEL PRIMER REPARTO SE CAMBIA POR SOLICITUD DE NEGOCIO
                          TO_CHAR (billed_at + V_TOTAL_DAYS_END,  'DD/MM/YYYY')    AS END_DEADLINE_ACTUAL, --- CUATRO DÍAS DESPUÉS DE LA FACTURA
                           FULL_CAMPAIGN AS FULL_CAMPAIGN_ACTUAL,zone as ZONA_ACTUAL 
                      FROM DBA_DMS.zone_campaigns
                     WHERE zone = V_ZONE --AND FULL_CAMPAIGN = V_FULL_CAMPAIGN
                     AND TRUNC (billed_at) >= TRUNC (SYSDATE)
                     AND ROWNUM = 1
                     GROUP BY billed_at, --FIRST_ATTEMPT_AT,
                     FULL_CAMPAIGN, ZONE
                     ) ,V_REF_CUR_04 as(
                       SELECT 1 as id_zone, TO_CHAR (MIN(billed_at) - V_TOTAL_DAYS_INI_DEST,
                                    'DD/MM/YYYY')    AS START_DEADLINE_DESTINO, --- 1 DÍA ANTES DE LA FACTURA
                             -- TO_CHAR (FIRST_ATTEMPT_AT + V_TOTAL_DAYS_END,  'DD/MM/YYYY')    AS END_DEADLINE_ACTUAL, --- DOS DÍAS DESÚES DEL PRIMER REPARTO SE CAMBIA POR SOLICITUD DE NEGOCIO
                          TO_CHAR (billed_at + V_TOTAL_DAYS_END_DEST,  'DD/MM/YYYY')    AS END_DEADLINE_DESTINO, --- CUATRO DÍAS DESPUÉS DE LA FACTURA
                           FULL_CAMPAIGN,zone as ZONA 
                      FROM DBA_DMS.zone_campaigns
                     WHERE zone = V_ZONE_DESTINO -- AND FULL_CAMPAIGN = V_FULL_CAMPAIGN_DESTINO
                     AND TRUNC (billed_at) >= TRUNC (SYSDATE)
                     AND ROWNUM = 1
                     GROUP BY billed_at, --FIRST_ATTEMPT_AT,
                     FULL_CAMPAIGN, ZONE
                     )                   
                      select  v1.START_DEADLINE_ACTUAL,v1.END_DEADLINE_ACTUAL,v1.FULL_CAMPAIGN_ACTUAL,v1.ZONA_ACTUAL,V2.START_DEADLINE_DESTINO,V2.END_DEADLINE_DESTINO,V2.FULL_CAMPAIGN AS FULL_CAMPAIGN_DESTINO,
                     V2.ZONA AS ZONA_DESTINO from V_REF_CUR_03 v1
                     left join V_REF_CUR_04 v2
                      on  v1.id_zone = v2.id_zone;  

                RETURN V_REF_CUR;
            END IF;
        ELSE
            OPEN V_REF_CUR FOR
                SELECT '00/00/0000'     AS START_DEADLINE_ACTUAL,
                       '00/00/0000'     AS END_DEADLINE_ACTUAL,
                       0                AS FULL_CAMPAIGN_ACTUAL,
                       0                AS ZONA_ACTUAL,
                       '00/00/0000'     AS START_DEADLINE_DESTINO,
                       '00/00/0000'     AS END_DEADLINE_DESTINO,
                       0                AS FULL_CAMPAIGN_DESTINO,
                       0                AS ZONA_DESTINO
                       
                  FROM DUAL;

            RETURN V_REF_CUR;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            OPEN V_REF_CUR FOR
                SELECT '00/00/0000'     AS START_DEADLINE_ACTUAL,
                       '00/00/0000'     AS END_DEADLINE_ACTUAL,
                       0                AS FULL_CAMPAIGN_ACTUAL,
                       0                AS ZONA_ACTUAL,
                       '00/00/0000'     AS START_DEADLINE_DESTINO,
                       '00/00/0000'     AS END_DEADLINE_DESTINO,
                       0                AS FULL_CAMPAIGN_DESTINO,
                       0                AS ZONA_DESTINO
                  FROM DUAL;


            RETURN V_REF_CUR;
    END FN_ADDRESS_REPRES_DEAD_DATE;
/

