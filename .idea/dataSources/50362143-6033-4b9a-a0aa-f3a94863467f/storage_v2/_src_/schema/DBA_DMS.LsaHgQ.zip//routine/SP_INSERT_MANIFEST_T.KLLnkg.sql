create PROCEDURE         SP_INSERT_MANIFEST_T (
    P_FULL_CAMPAIGN           VARCHAR2,                                   ---S
    P_SHIPPED_AT              VARCHAR2,                                    --S
    P_EXPECT_ARRIVAL_AT       VARCHAR2,                                    --S
    P_TRUCK_DRIVER            VARCHAR2,                                    --S
    P_TRUCK_NUMBER_CBOOTS      VARCHAR2,	
    P_NOTES                   VARCHAR2,                                    --S
    P_ORDER_COUNT             VARCHAR2,                                    --S
    P_DOCUMENT_COUNT          VARCHAR2,                                    --N
    P_GATE_ID_1               VARCHAR2,                                    --S
    P_GATE_ID_2               VARCHAR2,                                    --S
    P_ZONE                    VARCHAR2,                                    --S
    INSERTED_ROW          OUT VARCHAR2,         ---- NÚMERO DE LÍNEAS INSERTADAS
    P_TRUCK_NUMBER        OUT VARCHAR2,                                    ---
    P_ERROR_FLAG          OUT VARCHAR2, --- S = SI HUBO ERROR, N = NO HUBO ERROR
    P_ERROR_CODE          OUT VARCHAR2, --- SI S ENTONES NÚMERO DE ERROR ORA, SI  N ENTONCES NULL
    P_ERROR_MESSAGE       OUT VARCHAR2) --- SI S MENSAJE DE ERROR ORA, SI  N ENTONCES NULL
IS
    V_FULL_CAMPAIGN            NUMBER (6, 0);
    V_SHIPPED_AT               TIMESTAMP (6);
    V_EXPECT_ARRIVAL_AT        TIMESTAMP (6);
    V_TRUCK_DRIVER             VARCHAR2 (150 BYTE);
    V_NOTES                    VARCHAR2 (4000 BYTE);
    V_ORDER_COUNT              NUMBER (10, 0);
    V_OTHER_COUNT              NUMBER (10, 0) := 0;
    V_DOCUMENT_COUNT           NUMBER (10, 0);
    V_ZONE                     NUMBER (4, 0);
    V_GATE_ID_1                VARCHAR2 (10 BYTE);
    V_GATE_ID_2                VARCHAR2 (10 BYTE);
    V_TRANSFER_FLAG            CHAR (1 BYTE);
    NEW_ZONE                   NUMBER (4, 0);
    LOADING_GATES              NUMBER (4, 0);
    NEW_GATES                  NUMBER (4, 0);
    V_TRUCK_NUMBER_CATS        VARCHAR2 (10 BYTE);
    V_CAMPAIGN                 NUMBER (4);
    V_CAMPYEAR                 NUMBER (4);
    V_TRUCKNUMBER_ZON          NUMBER (10);
    VL_TOTAL_BOXES             NUMBER (10);
    VL_COUNT_ZONE              NUMBER (5);
    VL_INS_ROW                 VARCHAR2 (1500) := '-';
    VL_EXIST_MANIFEST          NUMBER (3);
    V_TRUCK_NUMBER_CBOOTS      VARCHAR2 (10 BYTE)  := P_TRUCK_NUMBER_CBOOTS;
     V_TRUCK_NUMBER_CBOOTS_C   NUMBER (3);
     V_TRUCK_NUMBER           VARCHAR2 (10 BYTE);

BEGIN
    P_ERROR_FLAG := 'N';

    ---- SEPARAR CAMPAÑA Y AÑO
    SELECT TRUNC (P_FULL_CAMPAIGN / 100) INTO V_CAMPYEAR FROM DUAL; --- EXTRAE AÑO

    SELECT MOD (P_FULL_CAMPAIGN, 100) INTO V_CAMPAIGN FROM DUAL; ---- EXTRAE CAMPAÑA
    ----- BUSCAR PLACA DE CBOOTS EN CATS
    SELECT  COUNT (DISTINCT(trucknumber))  into V_TRUCK_NUMBER_CBOOTS_C  --- BUSCA EL CAMION EN CATS
        FROM MANIFEST@CATS
        WHERE ZONE = P_ZONE
        AND CAMPAIGN = V_CAMPAIGN
        AND CAMPYEAR = V_CAMPYEAR
        AND TRUCKNUMBER = V_TRUCK_NUMBER_CBOOTS;

    ----EXTRAE TRUCK NUMBER DE CATS
    SELECT DBA_DMS.PK_FIND_TRUCKNUM.FN_FIND_TRUCK (P_ZONE,            --- ZONA
                                                   V_CAMPAIGN,     --- CAMPAÑA
                                                   V_CAMPYEAR)         --- AÑO
      INTO V_TRUCK_NUMBER_CATS
      FROM DUAL;

      IF V_TRUCK_NUMBER_CBOOTS_C = 1
      THEN V_TRUCK_NUMBER := V_TRUCK_NUMBER_CBOOTS;
      ELSE V_TRUCK_NUMBER :=V_TRUCK_NUMBER_CATS;
      END IF;


    SELECT DBA_DMS.PK_FIND_TRUCKNUM.FN_TOTAL_BOXES (V_TRUCK_NUMBER, --- ZONA
                                                    V_CAMPAIGN,    --- CAMPAÑA
                                                    V_CAMPYEAR)        --- AÑO
      INTO VL_TOTAL_BOXES
      FROM DUAL;


    SELECT DBA_DMS.PK_FIND_TRUCKNUM.FN_TOTAL_BOXES (V_TRUCK_NUMBER, --- ZONA
                                                    V_CAMPAIGN,    --- CAMPAÑA
                                                    V_CAMPYEAR)        --- AÑO
      INTO VL_TOTAL_BOXES
      FROM DUAL;

    SELECT COUNT (*)
      INTO VL_EXIST_MANIFEST --- VALIDA SI EXISTE REGISTRO EN TRUCKNUMBER CON ESA CAMPAÑA
      FROM MANIFEST
     WHERE     FULL_CAMPAIGN = P_FULL_CAMPAIGN
           AND TRUCK_NUMBER = V_TRUCK_NUMBER;

    V_TRUCK_DRIVER := P_TRUCK_DRIVER;
    V_NOTES := P_NOTES;

    V_GATE_ID_1 := P_GATE_ID_1;
    V_GATE_ID_2 := P_GATE_ID_2;

    V_TRANSFER_FLAG := 'F';

    SELECT NVL (TO_NUMBER (P_FULL_CAMPAIGN), NULL),
           NVL (TO_TIMESTAMP (P_SHIPPED_AT, 'YYYY-MM-DD HH24:MI:SS.FF'),
                NULL),
           NVL (
               TO_TIMESTAMP (P_EXPECT_ARRIVAL_AT, 'YYYY-MM-DD HH24:MI:SS.FF'),
               NULL),
           NVL (V_TRUCK_NUMBER, NULL),
           NVL (P_TRUCK_DRIVER, NULL),
           NVL (P_NOTES, NULL),
           NVL (TO_NUMBER (P_ORDER_COUNT), NULL),
           NVL (TO_NUMBER (V_OTHER_COUNT), 0),
           NVL (TO_NUMBER (P_DOCUMENT_COUNT), NULL),
           NVL (TO_NUMBER (P_ZONE), NULL)
      INTO V_FULL_CAMPAIGN,
           V_SHIPPED_AT,
           V_EXPECT_ARRIVAL_AT,
           V_TRUCK_NUMBER, --- SE SUSTITUYE POR EL DE CATS V_TRUCK_NUMBER,
           V_TRUCK_DRIVER,
           V_NOTES,
           V_ORDER_COUNT,
           V_OTHER_COUNT,
           V_DOCUMENT_COUNT,
           V_ZONE
      FROM DUAL;


    IF (VL_EXIST_MANIFEST = 0) --- NO EXISTE EN MANIFEST, INSERTA SÓLO EL DE MAYOR VOLUMEN
    THEN
        INSERT INTO MANIFEST (FULL_CAMPAIGN,
                              SHIPPED_AT,
                              EXPECT_ARRIVAL_AT,
                              TRUCK_NUMBER,
                              TRUCK_DRIVER,
                              NOTES,
                              TOTAL_BOX_SUM,
                              TRANSFER_FLAG)
             VALUES (V_FULL_CAMPAIGN,
                     V_SHIPPED_AT,
                     V_EXPECT_ARRIVAL_AT,
                     V_TRUCK_NUMBER, --- SE SUSTITUYE POR EL DE CATS V_TRUCK_NUMBER,
                     V_TRUCK_DRIVER,
                     V_NOTES,
                     VL_TOTAL_BOXES,
                     V_TRANSFER_FLAG);

    END IF;

    SELECT DBA_DMS.PK_FIND_TRUCKNUM.FN_TRUCK_ZONES (V_TRUCK_NUMBER, --- ZONA
                                                    V_CAMPAIGN,    --- CAMPAÑA
                                                    V_CAMPYEAR)        --- AÑO
      INTO V_TRUCKNUMBER_ZON --- VALIDA SI HAY EL MISMO NÚMERO DE ZONAS QUE LAS INSERTADAS
      FROM DUAL;

    SELECT COUNT (*)
      INTO NEW_ZONE
      FROM MANIFEST_ZONE
     WHERE     FULL_CAMPAIGN = P_FULL_CAMPAIGN
           AND TRUCK_NUMBER = V_TRUCK_NUMBER;

    IF (NEW_ZONE != V_TRUCKNUMBER_ZON) --- VALIDA SI HAY EL MISMO NÚMERO DE ZONAS QUE LAS INSERTADAS
    THEN
    SELECT  COUNT( DISTINCT (MC.ZONE)) INTO VL_COUNT_ZONE
                 FROM MANIFEST@CATS MC
                WHERE     MC.CAMPAIGN = V_CAMPAIGN
                      AND MC.CAMPYEAR = V_CAMPYEAR
                      AND MC.TRUCKNUMBER = V_TRUCK_NUMBER
                      AND TO_NUMBER (ZONE) IN ---INSERTA SÓLO LAS ZONAS QUE EXISTEN EN ZONE_CAMPAING
                              (SELECT DISTINCT ZC.ZONE
                                 FROM DBA_DMS.ZONE_CAMPAIGNS ZC
                                WHERE     MC.CAMPYEAR = ZC.CAMPAIGN_YEAR
                                      AND MC.CAMPAIGN = ZC.CAMPAIGN)
                      AND TO_NUMBER (ZONE)NOT  IN  ----QUE  EXISTEN EN MANIFEST ZONE
                              (SELECT  MF.ZONE
                                 FROM MANIFEST_ZONE MF
                                WHERE   MF.FULL_CAMPAIGN = V_FULL_CAMPAIGN
                                  AND MF.TRUCK_NUMBER = V_TRUCK_NUMBER)
                                      ;

     IF VL_COUNT_ZONE > 0 THEN
     SELECT DBA_DMS.FN_STRING_CONCAT(ZONE) INTO VL_INS_ROW
     FROM(
     SELECT DISTINCT ( MC.ZONE)
                 FROM MANIFEST@CATS MC
                WHERE     MC.CAMPAIGN = V_CAMPAIGN
                      AND MC.CAMPYEAR = V_CAMPYEAR
                      AND MC.TRUCKNUMBER = V_TRUCK_NUMBER
                      AND TO_NUMBER (ZONE) IN ---INSERTA SÓLO LAS ZONAS QUE EXISTEN EN ZONE_CAMPAING
                              (SELECT DISTINCT ZC.ZONE
                                 FROM DBA_DMS.ZONE_CAMPAIGNS ZC
                                WHERE     MC.CAMPYEAR = ZC.CAMPAIGN_YEAR
                                      AND MC.CAMPAIGN = ZC.CAMPAIGN)
                      AND TO_NUMBER (ZONE) NOT IN  ----QUE NO EXISTEN EN MANIFEST ZONE
                              (SELECT  MF.ZONE
                                 FROM MANIFEST_ZONE MF
                                WHERE   MF.FULL_CAMPAIGN = V_FULL_CAMPAIGN
                                  AND MF.TRUCK_NUMBER = V_TRUCK_NUMBER))
                                  ;

                                      ELSE VL_INS_ROW := '-';
                                      END IF;
        INSERT INTO MANIFEST_ZONE (ZONE,
                                   FULL_CAMPAIGN,
                                   TRUCK_NUMBER,
                                   TOTAL_BOXES,
                                   ORDER_COUNT,
                                   BOX_COUNT,
                                   SHIPPED_ORDER_COUNT,
                                   BILLED_ORDER_COUNT,
                                   COD_COUNT,
                                   OTHER_COUNT,
                                   DOCUMENT_COUNT,
                                   TOTAL_BOX_COUNT)
            (  SELECT MC.ZONE,
                      V_FULL_CAMPAIGN,
                      V_TRUCK_NUMBER, --- SE SUSTITUYE POR EL DE CATS V_TRUCK_NUMBER
                      COUNT (*)                 total_boxes,
                      COUNT (DISTINCT (ordernum)) ORDERS,
                      COUNT (*)                 total_boxes_,
                      COUNT (DISTINCT (ordernum)) ORDERS_,
                      COUNT (DISTINCT (ordernum)) ORDERS_1,
                      COUNT (DISTINCT (ordernum)) ORDERS,
                      V_OTHER_COUNT,
                      V_DOCUMENT_COUNT,
                      COUNT (*)                 total_boxes_1
                 FROM MANIFEST@CATS MC
                WHERE     MC.CAMPAIGN = V_CAMPAIGN
                      AND MC.CAMPYEAR = V_CAMPYEAR
                      AND MC.TRUCKNUMBER = V_TRUCK_NUMBER
                      AND TO_NUMBER (ZONE) IN ---INSERTA SÓLO LAS ZONAS QUE EXISTEN EN ZONE_CAMPAING
                              (SELECT DISTINCT ZC.ZONE
                                 FROM DBA_DMS.ZONE_CAMPAIGNS ZC
                                WHERE     MC.CAMPYEAR = ZC.CAMPAIGN_YEAR
                                      AND MC.CAMPAIGN = ZC.CAMPAIGN)
                      AND TO_NUMBER (ZONE) NOT IN  ----QUE NO EXISTEN EN MANIFEST ZONE
                              (SELECT  MF.ZONE
                                 FROM MANIFEST_ZONE MF
                                WHERE   MF.FULL_CAMPAIGN = V_FULL_CAMPAIGN
                                  AND MF.TRUCK_NUMBER = V_TRUCK_NUMBER)
             GROUP BY trucknumber, MC.ZONE);
----- REGRESA LA BANDERA DE TRANSFERENCIA A SIMPLI
        UPDATE MANIFEST SET TRANSFER_FLAG = 'F' WHERE TRUCK_NUMBER = V_TRUCK_NUMBER AND FULL_CAMPAIGN = V_FULL_CAMPAIGN;
    END IF;

    SELECT COUNT (*)
      INTO LOADING_GATES
      FROM LOADING_GATES
     WHERE (GATE_ID = P_GATE_ID_1);

    IF (V_GATE_ID_1 IS NOT NULL AND LOADING_GATES = 0)
    THEN
        INSERT INTO LOADING_GATES (GATE_ID,
                                   DROP_CODE,
                                   CREATED_AT,
                                   GATE_STATUS)
            SELECT V_GATE_ID_1 AS GATE_ID,
                   'N/A'       AS DROP_CODE,
                   SYSDATE     AS CREATED_AT,
                   '1'         AS GATE_STATUS
              FROM DUAL;

    END IF;

    SELECT COUNT (*)
      INTO LOADING_GATES
      FROM LOADING_GATES
     WHERE (GATE_ID = P_GATE_ID_2);

    IF (V_GATE_ID_2 IS NOT NULL AND LOADING_GATES = 0)
    THEN
        INSERT INTO LOADING_GATES (GATE_ID,
                                   DROP_CODE,
                                   CREATED_AT,
                                   GATE_STATUS)
            SELECT V_GATE_ID_2 AS GATE_ID,
                   'N/A'       AS DROP_CODE,
                   SYSDATE     AS CREATED_AT,
                   '1'         AS GATE_STATUS
              FROM DUAL;

    END IF;

    SELECT COUNT (*)
      INTO NEW_GATES
      FROM MANIFEST_GATES
     WHERE     FULL_CAMPAIGN = P_FULL_CAMPAIGN
           AND TRUCK_NUMBER = V_TRUCK_NUMBER
           AND (GATE_ID = P_GATE_ID_1 OR GATE_ID = P_GATE_ID_2);


    IF (V_GATE_ID_1 IS NOT NULL  AND NEW_GATES = 0)
    THEN
        INSERT INTO MANIFEST_GATES (FULL_CAMPAIGN,
                                    GATE_ID,
                                    TRUCK_CREATED_AT,
                                    TRUCK_NUMBER)
             VALUES (V_FULL_CAMPAIGN,
                     V_GATE_ID_1,
                     SYSDATE,
                     V_TRUCK_NUMBER --- SE SUSTITUYE POR EL DE CATS V_TRUCK_NUMBER
                                        );
                                        END IF;
  IF  (V_GATE_ID_2 IS NOT NULL  AND NEW_GATES = 0)
  THEN
        INSERT INTO MANIFEST_GATES (FULL_CAMPAIGN,
                                    GATE_ID,
                                    TRUCK_CREATED_AT,
                                    TRUCK_NUMBER)
             VALUES (V_FULL_CAMPAIGN,
                     V_GATE_ID_2,
                     SYSDATE,
                     V_TRUCK_NUMBER --- SE SUSTITUYE POR EL DE CATS V_TRUCK_NUMBER
                                        );

    END IF;

    COMMIT;                                   -- SE CONFIRMA TODA LA OPERACIÓN

    UPDATE MANIFEST
       SET TOTAL_BOX_SUM = VL_TOTAL_BOXES
     WHERE     FULL_CAMPAIGN = P_FULL_CAMPAIGN
           AND TRUCK_NUMBER = V_TRUCK_NUMBER;
    P_TRUCK_NUMBER := 'TRUCK NUMBER:'|| V_TRUCK_NUMBER;
    INSERTED_ROW :=   VL_INS_ROW   ;

    COMMIT;                                   -- SE CONFIRMA TODA LA OPERACIÓN
EXCEPTION
    WHEN NO_DATA_FOUND 
    THEN ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
    WHEN OTHERS
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
END SP_INSERT_MANIFEST_T;
/

