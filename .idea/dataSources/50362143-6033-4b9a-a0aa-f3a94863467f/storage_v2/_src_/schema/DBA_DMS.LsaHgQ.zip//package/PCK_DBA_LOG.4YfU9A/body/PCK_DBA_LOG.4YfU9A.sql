create PACKAGE BODY PCK_DBA_LOG IS
  /******************************************************************************
   NAME:       INS_DBA_LOG
   PURPOSE:    INSERTS ORACLE ERRORS AND COMMITS

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        25/03/2021  ROSSANA REYES     1. Created this Store Procedure.
   1.1        15/04/2021  JUAN C LOZANO     2. Updated comments.

******************************************************************************/
  PROCEDURE INS_DBA_LOG
    (
     PA_OBJECT     IN VARCHAR2,
     PA_PARAMETERS IN VARCHAR2,
     PA_SQLCODE    IN VARCHAR2,
     PA_SQLERRM    IN VARCHAR2
    ) IS
    VL_SEQ        NUMBER (10);
    VL_SYS_CONTEXT   VARCHAR2(500);
 BEGIN
   SELECT DBA_DMS.DBA_LOG_SEQ.NEXTVAL INTO VL_SEQ FROM DUAL;
   SELECT 'SID:'||
      SYS_CONTEXT('USERENV', 'SID') ||',USERID:'||
      SYS_CONTEXT('USERENV', 'SESSION_USERID') ||',SESSIONID:'||
      SYS_CONTEXT('USERENV', 'SESSIONID') ||',HOST:'||
      SYS_CONTEXT('USERENV', 'SERVER_HOST')||',IP_ADDRESS:'||
      SYS_CONTEXT('USERENV', 'IP_ADDRESS')||',CURRENT_SQL:'||
      SYS_CONTEXT('USERENV', 'CURRENT_SQL')
    INTO VL_SYS_CONTEXT
    FROM
    dual;
    INSERT INTO DBA_DMS.DBA_LOG
      (
       ID_LOG
      ,OBJECT_
      ,PARAMETERS_
      ,SQLCODE_
      ,SQLERRM_
      ,APPLICATION_
      )
    VALUES
      (
       VL_SEQ
      ,SUBSTR (NVL(PA_OBJECT, '-'), 0,80)
      ,SUBSTR (NVL(PA_PARAMETERS,'-'), 0,500)
      ,SUBSTR (NVL(PA_SQLCODE, '-'), 0,120)
      ,SUBSTR (NVL(PA_SQLERRM, '-'), 0,120)
      ,SUBSTR (NVL( VL_SYS_CONTEXT, '-'), 0,500)
      );
      COMMIT;
  END INS_DBA_LOG;
  /******************************************************************************
   NAME:       INSERT_DBA_LOG
   PURPOSE:    INSERTS ORACLE ERRORS AND DOES NOT COMMIT

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        15/04/2021  JUAN C LOZANO     1. Created this Store Procedure.

******************************************************************************/

  PROCEDURE INSERT_DBA_LOG
    (
     PA_OBJECT      IN VARCHAR2,
     PA_PARAMETERS IN VARCHAR2,
     PA_SQLCODE     IN VARCHAR2,
     PA_SQLERRM     IN VARCHAR2
    ) IS
    VL_SEQ        NUMBER (10);
    VL_SYS_CONTEXT   VARCHAR2(500);
  BEGIN
    SELECT DBA_DMS.DBA_LOG_SEQ.NEXTVAL INTO VL_SEQ FROM DUAL;
    SELECT 'SID:'||
      SYS_CONTEXT('USERENV', 'SID') ||',USERID:'||
      SYS_CONTEXT('USERENV', 'SESSION_USERID') ||',SESSIONID:'||
      SYS_CONTEXT('USERENV', 'SESSIONID') || ',MODULE:'||
      SYS_CONTEXT('USERENV','MODULE') || ',OS_USER:' ||
      SYS_CONTEXT('USERENV','OS_USER') || ',' ||',HOST:'||
      SYS_CONTEXT('USERENV', 'SERVER_HOST')||',IP_ADDRESS:'||
      SYS_CONTEXT('USERENV', 'IP_ADDRESS')||',CURRENT_SQL:'||
      SYS_CONTEXT('USERENV', 'CURRENT_SQL')
    INTO VL_SYS_CONTEXT
    FROM
    dual;
    INSERT INTO DBA_DMS.DBA_LOG
      (
       ID_LOG
      ,OBJECT_
      ,PARAMETERS_
      ,SQLCODE_
      ,SQLERRM_
      ,APPLICATION_
      )
    VALUES
      (
       VL_SEQ
      ,SUBSTR (NVL(PA_OBJECT, '-'), 0,80)
      ,SUBSTR (NVL(PA_PARAMETERS,'-'), 0,500)
      ,SUBSTR (NVL(PA_SQLCODE, '-'), 0,120)
      ,SUBSTR (NVL(PA_SQLERRM, '-'), 0,120)
      ,SUBSTR (NVL( VL_SYS_CONTEXT, '-'), 0,500)
      );
  END INSERT_DBA_LOG;
    /******************************************************************************
   NAME:       DEL_DBA_LOG
   PURPOSE:    BORRA ERRORES ORACLE

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        25/03/2021  ROSSANA REYES     1. Created this Store Procedure.
******************************************************************************/

  PROCEDURE DEL_DBA_LOG
    (PA_FECHA IN VARCHAR2,
	 PA_ROWNUM IN NUMBER ) IS
     VL_FECHA  DATE ;
  BEGIN
    VL_FECHA  := TO_DATE(PA_FECHA,'DD/MM/YYYY');
    DELETE FROM DBA_DMS.DBA_LOG WHERE pa_fecha >= VL_FECHA
    ;
    COMMIT;
  END DEL_DBA_LOG;
END PCK_DBA_LOG;
/

