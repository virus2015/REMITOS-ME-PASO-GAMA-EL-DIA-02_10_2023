create PACKAGE BODY         PKG_REPORTES_CP
/* ***************************************************************************** */
/* ** Nombre    : DMS_DBA.PKG_REPORTES_CP                                     ** */
/* ** Para Cía  : AVON                                                        ** */
/* ** Proyecto  : CARTA PORTE                                                 ** */
/* **                                                                         ** */
/* ** Descripción : Generación de reportes para Carta Porte, por normativa    ** */
/* **               del SAT                                                   ** */
/* **                                 .                                       ** */
/* **                                                                         ** */
/* ** Etapas :     * Reporte de Remitos con Miscelaneos GZ                    ** */
/* **              * Reporte LineHaul vs Miscelaneos sin agrupar              ** */
/* **              * Reporte LineHaul vs Miscelaneos LH,                      ** */
/* **                agrupado por Codigo Padre SAT                            ** */
/* **                                                                         ** */
/* **  Objetos que componen PKG:                SP_REMITOGZ_PORTE             ** */
/* **                                           SP_LH_SIN_GROUP_MISCELANEOS   ** */
/* **                                           SP_LH_AGRUPADO_MISCELANEOS    ** */
/* **                                                                         ** */
/* ** Elaborado por:  Ana Gabriela Olvera G.                                  ** */
/* ** Fecha        :  24/02/2022                                              ** */
/* ***************************************************************************** */
AS
   PROCEDURE SP_REMITOGZ_PORTE (pi_campaign   IN     NUMBER,
                                pi_Ruta       IN     NUMBER,
                                pi_Account    IN     NUMBER,
                                pi_Zona       IN     NUMBER,
                                pi_ldc        IN     VARCHAR2,
                                po_cod           OUT VARCHAR2,
                                po_msg           OUT VARCHAR2,
                                RemitoGZ_CP      OUT SYS_REFCURSOR)
   /* *************************************************************** */
   /* ** Nombre  :  SP_REMITOGZ_PORTE                              ** */
   /* ** Función :  Mostrar todos los Remitos Facturados y         ** */
   /* **            Miscelaneos GZ      .                          ** */
   /* *************************************************************** */
   AS
      cSqlRemito     VARCHAR2 (4000);
      cSqlGroup      VARCHAR2 (4000);
      cSqlMisGz      VARCHAR2 (4000);
      vSql           VARCHAR2 (4000);
      vCondicion     VARCHAR2 (2000);
      vCondicionGZ   VARCHAR2 (2000);
      vCondicionRH   VARCHAR2 (2000);
   BEGIN
      cSqlRemito :=
            ' SELECT RH.CAMPAIGN CAMPAIGN,' 
         || ' X.LDC_ID LDC, '
         || 'UPPER (X.LOCATION_NAME) POBLACION_LDC, '
         || 'RP.DEFAULT_ZONE AS ZONA, '
         || 'NVL (RP.ROUTE, 0) RUTA, '
         || 'RP.RFC, '
         || 'RP.ACCOUNT, '
         || 'RP.ACCOUNT_NAME NOMBRE, '
         || 'NVL (RP.ADDRESS1, ''-'') || '' '' || NVL (RP.ADDRESS2, ''-'') DOMICILIO, '
         || 'RP.ZIP CP, '
         || 'NVL (RP.MUNICIPALITY, ''-'') MUNICIPIO, '
         || 'RP.STATE_NAME ESTADO, '
         || '''MÉXICO'' PAIS, '
         || 'RE.TAX_CATEGORY AS CODIGO_SAT, '
         || 'RE.FSC CODIGO_AVON, '
         || 'RE.LINE_NUMBER, '
         || 'RE.DESCRIPTION DESCRIPCION, '
         || 'NVL (RE.PRODUCTS_NUM, 1) CANTIDAD, '
         || '''H87'' CLAVE_UNIDAD_MEDIDA, '
         || '''PZA'' UNIDAD_MEDIDA, '
         || 'TO_NUMBER (SUBSTR (MAX (TI.WEIGHT) / 1000, 1, 8)) PESO_UNITARIO, '
         || 'TO_NUMBER (SUBSTR ( (MAX (TI.WEIGHT) / 1000) * RE.PRODUCTS_NUM, 1, 8)) PESO_TOTAL, '
         || '''MX'' MONEDA, '
         || '(RE.PRICE * RE.PRODUCTS_NUM) PRECIO_TOTAL, '
         || '''FACTURADOS'' TIPO_DE_ARTICULO '
         || ' FROM DBA_SCPI.REMITO_HEADER RH, '
         || ' DBA_SCPI.REMITO RE, '
         || ' REPRESENTATIVES RP, '
         || ' DBA_SCPI.ITEM_DATA TI, '
         || ' DBA_DMS.LDC X, '
         || ' DBA_DMS.ZONE_CAMPAIGNS Z '
         || ' WHERE     RH.ID_REMITO_HEADER = RE.ID_REMITO_HEADER '
         || '  AND RH.ACCOUNT = RP.ACCOUNT '
         || '  AND RE.FSC = TI.FSC '
         || '  AND RE.LINE_NUMBER = TI.LINNO '
         || '  AND X.LDC_ID = Z.LDW_CODE '
         || '  AND RH.ZONE = Z.ZONE '
         || '  AND RH.CAMPAIGN = TO_CHAR (Z.CAMPAIGN_YEAR || LPAD (Z.CAMPAIGN, 2, 0)) '
         || '  AND RH.CAMPAIGN = '
         || pi_campaign;
      cSqlGroup :=
            '  GROUP BY RH.CAMPAIGN, '
         || 'X.LDC_ID, '
         || 'X.LOCATION_NAME, '
         || 'RP.DEFAULT_ZONE, '
         || 'RP.ROUTE, '
         || 'RP.RFC, '
         || 'RP.ACCOUNT, '
         || 'RP.ACCOUNT_NAME, '
         || 'RP.ADDRESS1, '
         || 'RP.ADDRESS2, '
         || 'RP.ZIP, '
         || 'RP.MUNICIPALITY, '
         || 'RP.STATE_NAME, '
         || 'RE.TAX_CATEGORY, '
         || 'RE.FSC, '
         || 'RE.LINE_NUMBER, '
         || 'RE.DESCRIPTION, '
         || 'RE.PRODUCTS_NUM, '
         || 'RE.PRICE ';
      cSqlMisGz :=
            '  UNION ALL '
         || ' SELECT  GZ.FULL_CAMPAIGN CAMPAIGN,'
         || ' X.LDC_ID AS LDC, '
         || ' UPPER (X.LOCATION_NAME) POBLACION_LDC, '
         || ' GZ.ZONE AS ZONA, '
         || ' NVL (RP.ROUTE, 0) RUTA, '
         || ' RP.RFC, '
         || ' GZ.ACCOUNT, '
         || ' RP.ACCOUNT_NAME NOMBRE, '
         || ' NVL (RP.ADDRESS1, ''-'') || '' '' || NVL (RP.ADDRESS2, ''-'') DOMICILIO, '
         || ' RP.ZIP CP, '
         || ' NVL (RP.MUNICIPALITY, ''-'') MUNICIPIO, '
         || ' RP.STATE_NAME ESTADO, '
         || '''MÉXICO'' PAIS, '
         || ' GZ.TAX_CATEGORY AS CODIGO_SAT, '
         || ' GZ.FSC AS CODIGO_AVON, '
         || ''' '' LINE_NUMBER, '
         || 'GZ.PRODUCT_DESC AS DESCRIPCION, '
         || 'GZ.PIECES AS CANTIDAD, '
         || '''H87'' AS CLAVE_UNIDAD_MEDIDA, '
         || '''PZA'' AS UNIDAD_MEDIDA, '
         || '0 AS PESO_UNITARIO, '
         || '0 AS PESO_TOTAL, '
         || '''MX'' AS MONEDA, '
         || '0 AS TOTAL, '
         || '''MISCELANEOS'' AS TIPO_ARTICULO '
         || ' FROM MISCELLANEOUS_GZ GZ, '
         || ' DBA_DMS.LDC X, '
         || ' DBA_DMS.ZONE_CAMPAIGNS Z, '
         || ' REPRESENTATIVES RP '
         || ' WHERE     GZ.FULL_CAMPAIGN = Z.FULL_CAMPAIGN '
         || ' AND GZ.ACCOUNT = RP.ACCOUNT '
         || ' AND GZ.ZONE = Z.ZONE '
         || ' AND X.LDC_ID = Z.LDW_CODE '
         || ' AND GZ.shipping_type = 2 '
         || ' AND GZ.FULL_CAMPAIGN = '
         || pi_campaign;

      BEGIN
         vCondicion := NULL;


         vSql := cSqlRemito || cSqlGroup || cSqlMisGz;

         IF pi_Ruta IS NOT NULL
         THEN
            vCondicion := ' AND RP.ROUTE = ' || pi_Ruta;
            vSql :=
                  cSqlRemito
               || vCondicion
               || cSqlGroup
               || cSqlMisGz
               || vCondicion;
         END IF;

         IF pi_Account IS NOT NULL
         THEN
            vCondicion := vCondicion || ' AND RP.ACCOUNT = ' || pi_Account;
            vSql :=
                  cSqlRemito
               || vCondicion
               || cSqlGroup
               || cSqlMisGz
               || vCondicion;
         END IF;

         IF pi_ldc IS NOT NULL
         THEN
            vCondicion :=
               vCondicion || ' AND X.LDC_ID = ''' || pi_ldc || ''' ';
            vSql :=
                  cSqlRemito
               || vCondicion
               || cSqlGroup
               || cSqlMisGz
               || vCondicion;
         END IF;

         IF pi_Zona IS NOT NULL
         THEN
            vCondicionRH := vCondicion || ' AND RH.ZONE = ' || pi_Zona;
            vCondicionGZ := vCondicion || ' AND GZ.ZONE = ' || pi_Zona;
            vSql :=
                  cSqlRemito
               || vCondicionRH
               || cSqlGroup
               || cSqlMisGz
               || vCondicionGZ;
         END IF;
      END;

      OPEN RemitoGZ_CP FOR vSql;
      DBMS_OUTPUT.put_line ('sqlRemito' || '-' || vSql);

   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         NULL;
      WHEN OTHERS
      THEN
         po_cod := SQLCODE;
         po_msg :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
   END SP_REMITOGZ_PORTE;

   PROCEDURE SP_LH_SIN_GROUP_MISCELANEOS (pi_campaign   IN     NUMBER,
                                          pi_ldc        IN     VARCHAR2,
                                          pi_zona       IN     NUMBER,
                                          pi_placa      IN     VARCHAR2,
                                          po_cod           OUT VARCHAR2,
                                          po_msg           OUT VARCHAR2,
                                          lhAgrupado       OUT SYS_REFCURSOR)
   AS
      cSqlLHSGr   VARCHAR2 (4000);
      vSql        VARCHAR2 (5000);
      vCondLh     VARCHAR2 (1000);

   BEGIN
      cSqlLHSGr :=
            'WITH SOH as ( '
         || 'SELECT ORDER_ID, ZONE, FULL_CAMPAIGN, ACCOUNT FROM SCPI_ORDER_HEADERS WHERE FULL_CAMPAIGN = '
         || pi_campaign
         || '), '
         || 'PKG as ( '
         || 'SELECT '
         || 'PACKAGE_ID, '
         || 'P.ORDER_ID, '
         || 'BARCODE, '
         || 'TRUCK_NUMBER, '
         || 'WEIGHT, '
         || 'PACKAGE_COST, '
         || 'PACKAGE_TYPE, '
         || 'ZONE, '
         || 'FULL_CAMPAIGN '
         || '  FROM PACKAGES P '
         || ' INNER JOIN SOH on SOH.ORDER_ID = P.ORDER_ID AND P.SHORTED IS NULL  '
         || '), '
         || ' PARSED_PACKAGES as ( '
         || ' SELECT '
         || 'PKG.PACKAGE_ID, '
         || 'TRUCK_NUMBER, '
         || 'ZONE, '
         || 'FULL_CAMPAIGN, '
         || 'PACKAGE_TYPE, '
         || '(DECODE (PACKAGE_TYPE,''H'', (WEIGHT / 1000000), '
         || '(CURRENT_WEIGHT + (SELECT TO_NUMBER (LONG_VALUE) FROM PARAMETERS  WHERE ID = 31))/ 1000)) AS PESO_UNIT, '
         || '1 QUANTITY, '
         || 'COSMETICS_PER_BOX COSMETICS_PER_BOX, '
         || 'PIECES_PER_BOX PIECES_PER_BOX, '
         || 'NVL(PACKAGE_COST,0) PACKAGE_COST, '
         || 'NVL (TAX_CATEGORY,(SELECT STRING_VALUE FROM PARAMETERS WHERE ID = 33 )) TAX_CATEGORY, '
         || 'CASE WHEN FSC IS NULL  '
         || 'THEN BARCODE ELSE  '
         || 'FSC END FSC, '
         || 'NVL(DESCRIPTION, ''CAJA DE COSMETICOS'') DESCRIPTION '
         || ' FROM PKG '
         || ' CROSS JOIN ( '
         || ' Select LONG_VALUE as BOX_WEIGHT from PARAMETERS where KEY = ''dms.cartaporte.pesoCaja'') PRM '
         || ' LEFT JOIN ITEMS I2 on PKG.PACKAGE_ID = I2.PACKAGE_ID and PKG.ORDER_ID = I2.ORDER_ID  AND I2.BIG_PRIZE IS NULL '
         || ' LEFT JOIN PACKAGE_TOTALS PT ON PKG.PACKAGE_ID = PT.PACKAGE_ID AND PKG.ORDER_ID = PT.ORDER_ID AND PT.ORDER_ID NOT IN (SELECT S.ORDER_ID '
         || '  FROM orders_statuses S '
         || ' WHERE S.STATUS = 15) '
         || '), '
         || 'PACKAGED_PACKAGES as ( '
         || ' SELECT '
         || 'case when TAX_CATEGORY = 0 then (SELECT to_number(STRING_VALUE) FROM PARAMETERS WHERE ID = 30 ) else TAX_CATEGORY END '
         || 'TAX_CATEGORY, '
         || 'FSC, '
         || 'DESCRIPTION, '
         || 'TRUCK_NUMBER, '
         || 'ZONE, '
         || 'FULL_CAMPAIGN, '
         || 'ROUND((PESO_UNIT),1) as PESO_UNIT, '
         || 'ROUND(AVG(PACKAGE_COST),2) UNIT_COST, '
         || 'sum(PACKAGE_COST) PACKAGE_COST, '
         || 'sum(QUANTITY) QUANTITY, '
         || 'nvl(to_char(sum(COSMETICS_PER_BOX)),''N/A'') COSMETICS_PER_BOX, '
         || 'nvl(to_char(sum(PIECES_PER_BOX)),''N/A'') PIECES_PER_BOX '
         || ' FROM PARSED_PACKAGES '
         || ' group by TAX_CATEGORY, FSC, DESCRIPTION, TRUCK_NUMBER, ZONE, FULL_CAMPAIGN,PESO_UNIT '
         || ') '
         || ' SELECT '
         || 'I.FULL_CAMPAIGN as "CAMPAIGN",'
         || 'ZC.LDW_CODE as "LDC", '
         || 'LDC.LOCATION_NAME as "POBLACION", '
         || 'I.ZONE as "ZONA", '
         || 'LDC.PROVIDER_ID as "NUM_PROVEEDOR", '
         || 'LDC.COMPANY_NAME as "RAZON_SOCIAL", '
         || 'LDC.ADDRESS, '
         || 'LDC.ZIP AS CP, '
         || 'ST.STATE_NAME as "ESTADO", '
         || 'ST.COUNTRY as "PAIS", '
         || 'RFC as "RFC", '
         || 'I.TRUCK_NUMBER as "NUM_PLACA", '
         || 'I.TAX_CATEGORY as "CODIGO_SAT", '
         || 'I.FSC as "FSC", '
         || 'I.DESCRIPTION as "DESCRIPCION", '
         || 'I.QUANTITY as "CANTIDAD", '
         || '''H87'' as "CLAVE_UNIDAD_MEDIDA", '
         || '''Pza'' as "UNIDAD_MEDIDA", '
         || 'PIECES_PER_BOX as "PIEZAS_CAJA", '
         || 'COSMETICS_PER_BOX as "PIEZAS_COSMETICOS", '
         || 'I.PESO_UNIT as "PESO_INDIVIDUAL", '
         || 'I.PESO_UNIT *I.QUANTITY as "PESO_TOTAL", '
         || 'I.UNIT_COST as "PRECIO_CATALOGO", '
         || '''MXN'' as "MONEDA", '
         || 'I.PACKAGE_COST as "PRECIO_TOTAL" '
         || ' from PACKAGED_PACKAGES I '
         || ' LEFT JOIN ZONE_CAMPAIGNS ZC on I.FULL_CAMPAIGN = ZC.FULL_CAMPAIGN '
         || ' AND I.ZONE = ZC.ZONE '
         || ' LEFT JOIN LDC ON ZC.LDW_CODE = LDC.LDC_ID '
         || ' LEFT JOIN TRANSPORTATION_PROVIDERS TP ON LDC.PROVIDER_ID = TP.PROVIDER_ID '
         || ' LEFT JOIN STATES ST ON LDC.STATE_CODE = ST.STATE_CODE ';




      BEGIN
         vCondLh := NULL;

         vSql := cSqlLHSGr ;

         IF pi_ldc IS NOT NULL
         THEN
            vCondLh := ' WHERE ZC.LDW_CODE = ''' || pi_ldc || ''' ';
            vSql := cSqlLHSGr || vCondLh ;
         END IF;  

  IF pi_zona IS NOT NULL 
         THEN
            IF pi_ldc IS NULL 
            THEN
               vCondLh := vCondLh || ' WHERE I.ZONE = ' || pi_zona;
            ELSE
               vCondLh := vCondLh || ' AND I.ZONE = ' || pi_zona;
            END IF;

            vSql := cSqlLHSGr || vCondLh ;
         END IF;

         IF pi_placa IS NOT NULL
         THEN
            IF pi_ldc IS NULL AND pi_zona IS NULL
            THEN
               vCondLh :=
                     vCondLh
                  || ' WHERE I.TRUCK_NUMBER = '''
                  || pi_placa
                  || ''' ';
            ELSE
               vCondLh :=
                  vCondLh || ' AND I.TRUCK_NUMBER = ''' || pi_placa || ''' ';
            END IF;

            vSql := cSqlLHSGr || vCondLh;         
   END IF;      
      END;

      DBMS_OUTPUT.put_line ('sql' || '-' || vSql);

      OPEN lhAgrupado FOR vSql;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         NULL;
      WHEN OTHERS
      THEN
         po_cod := SQLCODE;
         po_msg :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
   END SP_LH_SIN_GROUP_MISCELANEOS;


    PROCEDURE SP_LH_AGRUPADO_MISCELANEOS (
      pi_campaign     IN     NUMBER,
      pi_ldc          IN     VARCHAR2,
      pi_zona         IN     NUMBER,
      pi_placa        IN     VARCHAR2,
      po_cod             OUT VARCHAR2,
      po_msg             OUT VARCHAR2,
      lhAgrupadoMis      OUT SYS_REFCURSOR)
   AS
      cSqlLHSGr    VARCHAR2 (5000);
      cSqlGrpLh    VARCHAR2 (5000);
      vSql         VARCHAR2 (32767);
      vCondLh      VARCHAR2 (1000);
   BEGIN
      DBMS_OUTPUT.put_line ('entro aqui 1' || cSqlLHSGr);

      cSqlLHSGr :=
            'WITH SOH as ( '
         || 'SELECT ORDER_ID, ZONE, FULL_CAMPAIGN, ACCOUNT FROM SCPI_ORDER_HEADERS WHERE FULL_CAMPAIGN = '
         || pi_campaign
         || '), '
         || 'PKG as ( '
         || 'SELECT '
         || 'PACKAGE_ID, '
         || 'P.ORDER_ID, '
         || 'BARCODE, '
         || 'TRUCK_NUMBER, '
         || 'WEIGHT, '
         || 'PACKAGE_COST, '
         || 'PACKAGE_TYPE, '
         || 'ZONE, '
         || 'FULL_CAMPAIGN '
         || 'FROM PACKAGES P '
         || 'INNER JOIN SOH on SOH.ORDER_ID = P.ORDER_ID AND P.SHORTED IS NULL '
         || '), '
         || 'PARSED_PACKAGES as ( '
         || 'SELECT '
         || 'PKG.PACKAGE_ID, '
         || 'TRUCK_NUMBER, '
         || 'ZONE, '
         || 'FULL_CAMPAIGN, '
         || 'PACKAGE_TYPE, '
         || '(DECODE (PACKAGE_TYPE,''H'', (WEIGHT / 1000000), '
         || '(CURRENT_WEIGHT + (SELECT TO_NUMBER (LONG_VALUE) FROM PARAMETERS  WHERE ID = 31))/ 1000)) AS PESO_UNIT, '
         || '1 QUANTITY, '
         || 'COSMETICS_PER_BOX COSMETICS_PER_BOX, '
         || 'PIECES_PER_BOX PIECES_PER_BOX, '
         || 'NVL(PACKAGE_COST,0) PACKAGE_COST, '
         || 'NVL (TAX_CATEGORY,(SELECT STRING_VALUE FROM PARAMETERS WHERE ID = 33 )) TAX_CATEGORY, '
         || 'CASE WHEN FSC IS NULL '
         || 'THEN BARCODE ELSE '
         || 'FSC END FSC, '
         || 'NVL(DESCRIPTION, ''CAJA DE COSMETICOS'') DESCRIPTION '
         || ' FROM PKG '
         || ' CROSS JOIN ( '
         || ' Select LONG_VALUE as BOX_WEIGHT from PARAMETERS where KEY = ''dms.cartaporte.pesoCaja'') PRM '
         || ' LEFT JOIN ITEMS I2 on PKG.PACKAGE_ID = I2.PACKAGE_ID and PKG.ORDER_ID = I2.ORDER_ID  AND I2.BIG_PRIZE IS NULL  '
         || ' LEFT JOIN PACKAGE_TOTALS PT ON PKG.PACKAGE_ID = PT.PACKAGE_ID AND PKG.ORDER_ID = PT.ORDER_ID AND PT.ORDER_ID NOT IN (SELECT S.ORDER_ID '
         || ' FROM orders_statuses S '
         || ' WHERE S.STATUS = 15) '
         || '), '
         || 'PACKAGED_PACKAGES as ( '
         || 'SELECT '
         || 'case when TAX_CATEGORY = 0 then (SELECT to_number(STRING_VALUE) FROM PARAMETERS WHERE ID = 30 ) '
         || ' else TAX_CATEGORY END TAX_CATEGORY, '
         || 'FSC, '
         || 'DESCRIPTION, '
         || 'TRUCK_NUMBER, '
         || 'ZONE, '
         || 'FULL_CAMPAIGN, '
         || 'ROUND((PESO_UNIT),1) as PESO_UNIT, '
         || 'ROUND(AVG(PACKAGE_COST),2) UNIT_COST, '
         || 'PACKAGE_COST, '
         || 'sum(QUANTITY) QUANTITY, '
         || 'nvl(sum(COSMETICS_PER_BOX),0) COSMETICS_PER_BOX, '
         || 'nvl(sum(PIECES_PER_BOX),0) PIECES_PER_BOX '
         || ' FROM PARSED_PACKAGES '
         || 'group by TAX_CATEGORY, FSC, DESCRIPTION, TRUCK_NUMBER, ZONE, FULL_CAMPAIGN,PESO_UNIT, PACKAGE_COST '
         || ') '
         || 'SELECT  '
         || 'I.FULL_CAMPAIGN as "CAMPAIGN", '
         || 'ZC.LDW_CODE as "LDC", '
         || 'LDC.LOCATION_NAME as "POBLACION", '
         || 'I.ZONE as "ZONA", '
         || 'LDC.PROVIDER_ID as "NUM_PROVEEDOR", '
         || 'LDC.COMPANY_NAME as "RAZON_SOCIAL", '
         || 'LDC.ADDRESS, '
         || 'LDC.ZIP AS CP, '
         || 'ST.STATE_NAME as "ESTADO", '
         || 'ST.COUNTRY as "PAIS", '
         || 'RFC as "RFC", '
         || 'I.TRUCK_NUMBER as "NUM_PLACA", '
         || ' CASE WHEN SUBSTR(I.TAX_CATEGORY,1,6)||''00'' = ''10101000'' '
         || ' THEN ''1010101'' '
         || ' ELSE  '
         || 'SUBSTR(I.TAX_CATEGORY,1,6)||''00'' END '
         || ' AS "CODIGO_SAT", '
         || ' NULL AS  "FSC", '
         || 'TS.TAX_CATEGORY_DESC AS "DESCRIPCION", '
         || 'SUM(I.QUANTITY) as "CANTIDAD", '
         || '''H87'' as "CLAVE_UNIDAD_MEDIDA", '
         || '''Pza'' as "UNIDAD_MEDIDA", '
         || ' NULL as "PIEZAS_CAJA", '
         || ' NULL as "PIEZAS_COSMETICOS", '
         || ' NULL as "PESO_INDIVIDUAL", '
         || 'NVL(SUM(I.PESO_UNIT *I.QUANTITY),0) as "PESO_TOTAL", '
         || ' NULL   as "PRECIO_CATALOGO", '
         || '''MXN'' as "MONEDA", '
         || 'SUM(I.UNIT_COST *I.QUANTITY) as "PRECIO_TOTAL" '
         || ' from PACKAGED_PACKAGES I '
         || ' LEFT JOIN ZONE_CAMPAIGNS ZC on I.FULL_CAMPAIGN = ZC.FULL_CAMPAIGN '
         || ' AND I.ZONE = ZC.ZONE '
         || ' LEFT JOIN LDC ON ZC.LDW_CODE = LDC.LDC_ID '
         || ' LEFT JOIN TRANSPORTATION_PROVIDERS TP ON LDC.PROVIDER_ID = TP.PROVIDER_ID '
         || ' LEFT JOIN STATES ST ON LDC.STATE_CODE = ST.STATE_CODE '
         || ' LEFT JOIN  TAX_CATEGORY_SAT TS ON TS.TAX_CATEGORY = '
         || ' CASE WHEN SUBSTR (I.TAX_CATEGORY, 1, 6)  || ''00'' = ''10101000'' '
         || ' THEN ''1010101'' ELSE SUBSTR (I.TAX_CATEGORY, 1, 6) || ''00'' END ';


      cSqlGrpLh :=
            ' GROUP BY I.FULL_CAMPAIGN , '
         || 'ZC.LDW_CODE , '
         || 'LDC.LOCATION_NAME , '
         || 'I.ZONE , '
         || 'LDC.PROVIDER_ID , '
         || 'LDC.COMPANY_NAME , '
         || 'LDC.ADDRESS, '
         || 'LDC.ZIP , '
         || 'ST.STATE_NAME , '
         || 'ST.COUNTRY , '
         || 'RFC , '
         || 'I.TRUCK_NUMBER , '
         || ' CASE WHEN SUBSTR(I.TAX_CATEGORY,1,6)||''00'' = ''10101000'' '
         || ' THEN ''1010101'' '
         || ' ELSE  '
         || 'SUBSTR(I.TAX_CATEGORY,1,6)||''00'' END ,'
         || 'TS.TAX_CATEGORY_DESC ';

      BEGIN
         vCondLh := NULL;

         vSql := cSqlLHSGr || cSqlGrpLh;

         IF pi_ldc IS NOT NULL
         THEN
            vCondLh := ' WHERE ZC.LDW_CODE = ''' || pi_ldc || ''' ';
            vSql :=
                  cSqlLHSGr
               || vCondLh
               || cSqlGrpLh;
         END IF;

         IF pi_zona IS NOT NULL
         THEN
            IF pi_ldc IS NULL 
            THEN
               vCondLh := vCondLh || ' WHERE I.ZONE = ' || pi_zona;
            ELSE
               vCondLh := vCondLh || ' AND I.ZONE = ' || pi_zona;
            END IF;

            vSql :=
                  cSqlLHSGr
               || vCondLh
               || cSqlGrpLh;

         END IF;

         IF pi_placa IS NOT NULL
         THEN
            IF pi_zona IS NULL AND pi_ldc IS NULL
            THEN
               vCondLh :=
                     vCondLh
                  || ' WHERE I.TRUCK_NUMBER = '''
                  || pi_placa
                  || ''' ';
            ELSE
               vCondLh :=
                  vCondLh || ' AND I.TRUCK_NUMBER = ''' || pi_placa || ''' ';
            END IF;


            vSql :=
                  cSqlLHSGr
               || vCondLh
               || cSqlGrpLh;
         END IF;
      END;



      OPEN lhAgrupadoMis FOR vSql;
      DBMS_OUTPUT.put_line ('sqlagrup' || '-' || vSql);

   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         NULL;
      WHEN OTHERS
      THEN
         po_cod := SQLCODE;
         po_msg :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
   END SP_LH_AGRUPADO_MISCELANEOS;

   PROCEDURE SP_VEAS_ENTREGADOS (pi_campaign   IN     NUMBER,
                                pi_Zona       IN     NUMBER,
                                pi_ldc        IN     VARCHAR2,
                                po_cod           OUT VARCHAR2,
                                po_msg           OUT VARCHAR2,
                                Veas_Entregados      OUT SYS_REFCURSOR)
   /* *************************************************************** */
   /* ** Nombre  :  SP_VEAS_ENTREGADOS                              ** */
   /* ** Función :  Mostrar reporte carta porte de VEAS            ** */
   /* **            ENTREGADOS          .                          ** */
   /* *************************************************************** */
   AS
      cSqlVeas     VARCHAR2 (32000);
      vSql           VARCHAR2 (32000);
      vCondicion     VARCHAR2 (32000);
   BEGIN
      cSqlVeas :=
' SELECT LM.CURRENT_CAMPAIGN AS "CAMPAIGN", '
     || ' LM.ZONE AS "ZONA", '
     || ' LDC.LDC_ID AS "LDC", '
     || ' LDC.TAXPAYER_NUM "RFC_LDC", '
     || ' LDC.COMPANY_NAME AS "RAZON_SOCIAL_LDC", '
     || ' LDC.LOCATION_NAME AS "POBLACION_LDC", '
     || ' LDC.ADDRESS "ADDRESS_LDC", '
     || ' LDC.ZIP AS "CP_LDC", '
     || ' LM.RFC "RFC_GZ", '
     || ' LM.ZONE_MANAGER_ID "NUMERO_GZ", '
     || ' LM.MANAGER_NAME  "NOMBRE_GZ", '
     || ' LM.STREET "CALLE_GZ", '
     || ' LM.EXTERNAL_NUMBER "NUMERO_EXTERIOR_GZ", '
     || ' LM.INDOOR_INFORMATION "NUMERO_INTERIOR_GZ", '
     || ' LM.SUBURB "COLONIA_GZ", '
     || ' LM.ZIP "CP_GZ", '
     || ' LM.TOWNSHIP "MUNICIPIO_GZ", '
     || ' LM.STATE "ESTADO_GZ", '
     ||  '''MEXICO'' AS "PAIS", '
     ||  '''MEXICANA'' AS "NACIONALIDAD", '
     || ' LM.TAX_CATEGORY AS "CODIGO_SAT", '
     || ' LM.FSC AS "CODIGO_AVON", '
     || ' LM.PRODUCT_DESC AS "DESCRIPCION", '
     || ' LM.PIECES AS "PIEZAS", '
     || ' ''H87'' AS "CLAVE_UNIDAD_MEDIDA", '
     || ' ''Pza'' AS "UNIDAD_MEDIDA", '
--     || ' DI.WEIGHT/1000 AS "PESO_INDIVIDUAL", '
--     || ' (DI.WEIGHT/1000)*LM.PIECES AS "PESO_TOTAL", '
--     || ' DI.ITEM_PRICE AS "PRECIO_CATALOGO", '
--     || ' ''MXN'' AS "MONEDA", '
--     || ' DI.ITEM_PRICE*LM.PIECES AS "PRECIO_TOTAL" '
   || '       (SELECT UNIQUE A.WEIGHT / 1000 FROM ITEM_DATA A WHERE A.FSC = LM.FSC AND TO_CHAR (A.YEAR || LPAD (A.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN AND A.ITEM_PRICE = (
                     (SELECT MAX (B.ITEM_PRICE)
                 FROM ITEM_DATA B
                WHERE     B.FSC = LM.FSC
                      AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN))
                   AND A.LINNO =  ((SELECT MAX (B.LINNO)
                                    FROM ITEM_DATA B
                                   WHERE B.FSC = LM.FSC
                                     AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =LM.CURRENT_CAMPAIGN))) 
        AS "PESO_INDIVIDUAL",
       (SELECT UNIQUE (A.WEIGHT / 1000) * LM.PIECES  FROM ITEM_DATA A WHERE A.FSC = LM.FSC AND TO_CHAR (A.YEAR || LPAD (A.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN AND A.ITEM_PRICE = (
                     (SELECT MAX (B.ITEM_PRICE)
                 FROM ITEM_DATA B
                WHERE     B.FSC = LM.FSC
                      AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN))
                             AND A.LINNO =  ((SELECT MAX (B.LINNO)
                                    FROM ITEM_DATA B
                                   WHERE B.FSC = LM.FSC
                                     AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =LM.CURRENT_CAMPAIGN)))        
       AS "PESO_TOTAL",
       (SELECT UNIQUE A.ITEM_PRICE  FROM ITEM_DATA A WHERE A.FSC = LM.FSC AND TO_CHAR (A.YEAR || LPAD (A.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN AND A.ITEM_PRICE = (
                     (SELECT MAX (B.ITEM_PRICE)
                 FROM ITEM_DATA B
                WHERE     B.FSC = LM.FSC
                      AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN))
                             AND A.LINNO =  ((SELECT MAX (B.LINNO)
                                    FROM ITEM_DATA B
                                   WHERE B.FSC = LM.FSC
                                     AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =LM.CURRENT_CAMPAIGN)))   
             AS "PRECIO_CATALOGO",                                   
       ''MXN'' AS "MONEDA",
              (SELECT UNIQUE A.ITEM_PRICE * LM.PIECES   FROM ITEM_DATA A WHERE A.FSC = LM.FSC AND TO_CHAR (A.YEAR || LPAD (A.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN AND A.ITEM_PRICE = (
                     (SELECT MAX (B.ITEM_PRICE)
                 FROM ITEM_DATA B
                WHERE     B.FSC = LM.FSC
                      AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN))
                     AND A.LINNO =  ((SELECT MAX (B.LINNO)
                                    FROM ITEM_DATA B
                                   WHERE B.FSC = LM.FSC
                                     AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =LM.CURRENT_CAMPAIGN))        )   
                             AS "PRECIO_TOTAL" '
 || ' FROM MISCELLANEOUS_MANAGER LM '
 || '   LEFT JOIN LDC ON LM.LDC_ID = LDC.LDC_ID '
 --|| ' LEFT JOIN ITEM_DATA DI ON LM.FSC = DI.FSC '
-- || ' AND LM.CURRENT_CAMPAIGN = TO_CHAR (DI.YEAR || LPAD (DI.CAMPAIGN, 2, 0)) ' 
 || ' WHERE LM.CURRENT_CAMPAIGN = ' || pi_campaign 
 || ' AND LM.SHIPPING_TYPE = 1';
 --|| ' AND DI.ITEM_PRICE = (SELECT MAX(B.ITEM_PRICE) FROM ITEM_DATA B WHERE LM.FSC = B.FSC(+) AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) = LM.CURRENT_CAMPAIGN) ';

      BEGIN
         vCondicion := NULL;


         vSql := cSqlVeas ;

         IF pi_ldc IS NOT NULL
         THEN
            vCondicion :=
               vCondicion || ' AND LM.LDC_ID = ''' || pi_ldc || ''' ';
            vSql :=
                  cSqlVeas
               || vCondicion;
         END IF;

         IF pi_Zona IS NOT NULL
         THEN
            vCondicion := vCondicion || ' AND LM.ZONE = ' || pi_Zona;
            vSql :=
                  cSqlVeas
               || vCondicion;
         END IF;
      END;

      OPEN Veas_Entregados FOR vSql;
      DBMS_OUTPUT.put_line ('Veas_Entregados' || '-' || vSql);

   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         NULL;
      WHEN OTHERS
      THEN
         po_cod := SQLCODE;
         po_msg :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
   END SP_VEAS_ENTREGADOS;


      PROCEDURE SP_VEAS_DEVOLUCIONES (pi_campaign   IN     NUMBER,
                                pi_Zona       IN     NUMBER,
                                pi_ldc        IN     VARCHAR2,
                                po_cod           OUT VARCHAR2,
                                po_msg           OUT VARCHAR2,
                                Veas_Devoluciones      OUT SYS_REFCURSOR)
   /* *************************************************************** */
   /* ** Nombre  :  SP_VEAS_DEVOLUCIONES                              ** */
   /* ** Función :  Mostrar reporte carta porte de VEAS            ** */
   /* **            DEVOLUCIONES        .                          ** */
   /* *************************************************************** */
   AS
      cSqlVeas     VARCHAR2 (4000);
      vSql           VARCHAR2 (4000);
      vCondicion     VARCHAR2 (2000);
   BEGIN
      cSqlVeas :=
' SELECT LM.CURRENT_CAMPAIGN AS "CAMPAIGN", '
     || ' LM.PRODUCT_CAMPAING AS "PRODUCT_CAMPAING", '
     || ' LM.ZONE AS "ZONA", '
     || ' LM.RFC "RFC_GZ", '
     || ' LM.ZONE_MANAGER_ID "NUMERO_GZ", '
     || ' LM.MANAGER_NAME  "NOMBRE_GZ", '
     || ' LM.STREET "CALLE_GZ", '
     || ' LM.EXTERNAL_NUMBER "NUMERO_EXTERIOR_GZ", '
     || ' LM.INDOOR_INFORMATION "NUMERO_INTERIOR_GZ", '
     || ' LM.SUBURB "COLONIA_GZ", '
     || ' LM.ZIP "CP_GZ", '
     || ' LM.TOWNSHIP "MUNICIPIO_GZ", '
     || ' LM.STATE "ESTADO_GZ", '
     ||  '''MEXICO'' AS "PAIS", '
     ||  '''MEXICANA'' AS "NACIONALIDAD", '
     || ' LDC.LDC_ID AS "LDC", '
     || ' LDC.TAXPAYER_NUM "RFC_LDC", '
     || ' LDC.COMPANY_NAME AS "RAZON_SOCIAL_LDC", '
     || ' LDC.LOCATION_NAME AS "POBLACION_LDC", '
     || ' LDC.ADDRESS "ADDRESS_LDC", '
     || ' LDC.ZIP AS "CP_LDC", '
     || ' LM.TAX_CATEGORY AS "CODIGO_SAT", '
     || ' LM.FSC AS "CODIGO_AVON", '
     || ' LM.PRODUCT_DESC AS "DESCRIPCION", '
     || ' LM.PIECES AS "PIEZAS", '
     || ' ''H87'' AS "CLAVE_UNIDAD_MEDIDA", '
     || ' ''Pza'' AS "UNIDAD_MEDIDA", '
--     || ' DI.WEIGHT/1000 AS "PESO_INDIVIDUAL", '
--     || ' (DI.WEIGHT/1000)*LM.PIECES AS "PESO_TOTAL", '
--     || ' DI.ITEM_PRICE AS "PRECIO_CATALOGO", '
--     || ' ''MXN'' AS "MONEDA", '
--     || ' DI.ITEM_PRICE*LM.PIECES AS "PRECIO_TOTAL" '
   || '       (SELECT UNIQUE A.WEIGHT / 1000 FROM ITEM_DATA A WHERE A.FSC = LM.FSC AND TO_CHAR (A.YEAR || LPAD (A.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN AND A.ITEM_PRICE = (
                     (SELECT MAX (B.ITEM_PRICE)
                 FROM ITEM_DATA B
                WHERE     B.FSC = LM.FSC
                      AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN))) 
        AS "PESO_INDIVIDUAL",
       (SELECT UNIQUE (A.WEIGHT / 1000) * LM.PIECES  FROM ITEM_DATA A WHERE A.FSC = LM.FSC AND TO_CHAR (A.YEAR || LPAD (A.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN AND A.ITEM_PRICE = (
                     (SELECT MAX (B.ITEM_PRICE)
                 FROM ITEM_DATA B
                WHERE     B.FSC = LM.FSC
                      AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN)))        
       AS "PESO_TOTAL",
       (SELECT UNIQUE A.ITEM_PRICE  FROM ITEM_DATA A WHERE A.FSC = LM.FSC AND TO_CHAR (A.YEAR || LPAD (A.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN AND A.ITEM_PRICE = (
                     (SELECT MAX (B.ITEM_PRICE)
                 FROM ITEM_DATA B
                WHERE     B.FSC = LM.FSC
                      AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN)))   
             AS "PRECIO_CATALOGO",                                   
       ''MXN'' AS "MONEDA",
              (SELECT UNIQUE A.ITEM_PRICE * LM.PIECES   FROM ITEM_DATA A WHERE A.FSC = LM.FSC AND TO_CHAR (A.YEAR || LPAD (A.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN AND A.ITEM_PRICE = (
                     (SELECT MAX (B.ITEM_PRICE)
                 FROM ITEM_DATA B
                WHERE     B.FSC = LM.FSC
                      AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) =
                             LM.CURRENT_CAMPAIGN)))   
                             AS "PRECIO_TOTAL" '
 || ' FROM MISCELLANEOUS_MANAGER LM '
 || '   LEFT JOIN LDC ON LM.LDC_ID = LDC.LDC_ID '
 --|| ' LEFT JOIN ITEM_DATA DI ON LM.FSC = DI.FSC '
 --|| ' AND LM.CURRENT_CAMPAIGN = TO_CHAR (DI.YEAR || LPAD (DI.CAMPAIGN, 2, 0)) '
 || ' WHERE LM.CURRENT_CAMPAIGN = ' || pi_campaign 
 || ' AND LM.SHIPPING_TYPE = 2';
-- || ' AND DI.ITEM_PRICE = (SELECT MAX(B.ITEM_PRICE) FROM ITEM_DATA B WHERE LM.FSC = B.FSC(+) AND TO_CHAR (B.YEAR || LPAD (B.CAMPAIGN, 2, 0)) = LM.CURRENT_CAMPAIGN) ';


      BEGIN
         vCondicion := NULL;


         vSql := cSqlVeas ;

         IF pi_ldc IS NOT NULL
         THEN
            vCondicion :=
               vCondicion || ' AND LM.LDC_ID = ''' || pi_ldc || ''' ';
            vSql :=
                  cSqlVeas
               || vCondicion;
         END IF;

         IF pi_Zona IS NOT NULL
         THEN
            vCondicion := vCondicion || ' AND LM.ZONE = ' || pi_Zona;
            vSql :=
                  cSqlVeas
               || vCondicion;
         END IF;
      END;

      OPEN Veas_Devoluciones FOR vSql;
      DBMS_OUTPUT.put_line ('Veas_Devoluciones' || '-' || vSql);

   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         NULL;
      WHEN OTHERS
      THEN
         po_cod := SQLCODE;
         po_msg :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
   END SP_VEAS_DEVOLUCIONES;
END PKG_REPORTES_CP;
/

