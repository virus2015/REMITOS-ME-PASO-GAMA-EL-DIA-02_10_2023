create trigger TRG_ORDERS_MONITORING
    before insert or update
    on ORDERS
    for each row
    when (new.UPDATED_BY IS NULL and new.CURRENT_AMOUNT > 100000)
DECLARE MY_VAR VARCHAR2(500);
BEGIN
    insert into ORDERS_MONITORING (ID, LOG)
    select ORDER_MONITORING_SEQ.nextval,
           SYS_CONTEXT('USERENV','AUTHENTICATED_IDENTITY') || ',' ||
           SYS_CONTEXT('USERENV','CLIENT_IDENTIFIER') || ',' ||
           SYS_CONTEXT('USERENV','CURRENT_USER') || ',' ||
           SYS_CONTEXT('USERENV','HOST') || ',' ||
           SYS_CONTEXT('USERENV','IP_ADDRESS') || ',' ||
           SYS_CONTEXT('USERENV','MODULE') || ',' ||
           SYS_CONTEXT('USERENV','OS_USER') || ',' ||
           SYS_CONTEXT('USERENV','PROXY_USER') || ',' ||
           SYS_CONTEXT('USERENV','STATEMENTID') || ',' ||
           SYS_CONTEXT('USERENV','') || ','
    from dual;
    :NEW.UPDATED_BY := MY_VAR;
END;
/

