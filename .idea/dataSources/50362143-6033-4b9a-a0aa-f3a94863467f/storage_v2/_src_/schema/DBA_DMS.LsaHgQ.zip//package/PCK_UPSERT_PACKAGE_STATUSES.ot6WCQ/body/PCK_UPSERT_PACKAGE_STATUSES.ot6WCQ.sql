create PACKAGE BODY         PCK_UPSERT_PACKAGE_STATUSES AS 

	PROCEDURE SP_UPSERT_PACKAGE_STATUSES (
		p_package_statuses_tbl in PCK_UPSERT_PACKAGE_STATUSES.PACKAGE_STATUSES_TBL,
		p_error_flag out varchar2,
		p_error_code out varchar2,
		p_error_message out varchar2,
		statuses_changed out number
	)
	AS
	BEGIN
		p_error_flag := 'N';
		FORALL I IN p_package_statuses_tbl.FIRST .. p_package_statuses_tbl.LAST
			MERGE INTO PACKAGE_STATUSES PS
			USING
			   ( SELECT p_package_statuses_tbl(I).ORDER_ID,
			   p_package_statuses_tbl(I).STATUS,
			   p_package_statuses_tbl(I).PACKAGE_ID FROM DUAL ) P
			ON ( PS.ORDER_ID = p_package_statuses_tbl(I).ORDER_ID AND
			   PS.PACKAGE_ID = p_package_statuses_tbl(I).PACKAGE_ID )
			   WHEN MATCHED THEN
				  UPDATE SET
				   PS.ORDER_ID = p_package_statuses_tbl(I).ORDER_ID ,
				   PS.STATUS = p_package_statuses_tbl(I).STATUS ,
				   PS.PACKAGE_ID = p_package_statuses_tbl(I).PACKAGE_ID
			   WHEN NOT MATCHED THEN INSERT
					(ORDER_ID,
					STATUS,
					PACKAGE_ID)
					VALUES (p_package_statuses_tbl(I).ORDER_ID,
					p_package_statuses_tbl(I).STATUS,
					p_package_statuses_tbl(I).PACKAGE_ID);
					statuses_changed:=SQL%ROWCOUNT;

	EXCEPTION
			  WHEN OTHERS THEN
				 p_error_code := SQLCODE;
				 p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() );
				 p_error_flag := 'S';
	END;
END PCK_UPSERT_PACKAGE_STATUSES;
/

