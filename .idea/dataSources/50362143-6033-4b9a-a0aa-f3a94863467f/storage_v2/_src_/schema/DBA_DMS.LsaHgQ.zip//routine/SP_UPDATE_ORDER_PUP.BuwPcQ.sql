create PROCEDURE         SP_UPDATE_ORDER_PUP
AS
BEGIN
  MERGE INTO DBA_DMS.ORDERS dest
  USING ( SELECT *
            FROM DBA_SCPI.ORDER_HEADER
           WHERE BILL_DATE = TO_NUMBER(TO_CHAR(SYSDATE - 1,'yyyymmdd'))
             AND ORDER_PUP IS NOT NULL
          ORDER BY ZONE, ACCOUNT
        ) fte
  ON (dest.ORDER_ID = fte.ID_ORDER)
  WHEN MATCHED THEN
       UPDATE SET dest.PICK_UP_POINT_ID = trim(fte.ORDER_PUP),  -- varchar2(10) - varchar2(5)
                  dest.TRANSFER_FLAG = 'E',
                  dest.UPDATED_BY = 'PUP EN ORDEN',
                  dest.UPDATED_AT = sysdate;
--  WHEN NOT MATCHED THEN
--       INSERT (ORDER_ID, PICK_UP_POINT_ID, TRANSFER_FLAG) 
--       VALUES (ID_ORDER, ORDER_PUP, 'F');
EXCEPTION
  WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE(sqlerrm);
END SP_UPDATE_ORDER_PUP;
/

