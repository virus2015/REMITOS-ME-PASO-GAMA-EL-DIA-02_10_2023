create PROCEDURE         sp_upd_mtto_saldos_reprs (
    P_ERROR_FLAG      OUT VARCHAR2,
    P_ERROR_CODE      OUT VARCHAR2,
    P_ERROR_MESSAGE   OUT VARCHAR2,
    P_UPDATED_ROWS    OUT NUMBER)
AS
    v_valor_dias_atras        NUMBER := 16; -- NOTE: This value must be a POSITIVE one.
    v_valor_fecha_procesado   DATE := SYSDATE;
BEGIN
    P_ERROR_FLAG := 'N';

    /* -- */
    MERGE INTO ORDERS dest2
         USING (SELECT oh.ORDER_ID,
                       baff.DUE_BALANCE_AMOUNT,
                       baff.PAST_DUE_BALANCE_AMOUNT,
                       o.PREVIOUS_AMOUNT,
                       o.CURRENT_AMOUNT,
                       oh.ORD_AMOUNT
                  FROM ORDERS  o
                       INNER JOIN SCPI_ORDER_HEADERS oh
                           ON o.ORDER_ID = oh.ORDER_ID
                       INNER JOIN bids_amounts_from_file baff
                           ON (    baff.ACCOUNT = oh.ACCOUNT
                               AND baff.ZONE = oh.ZONE)
                 WHERE oh.ORDER_DATE BETWEEN (  v_valor_fecha_procesado
                                              - v_valor_dias_atras)
                                         AND v_valor_fecha_procesado AND o.CURRENT_AMOUNT > 0 --- VALIDA QUE NOSE HAGA UNA DOBLE APLICACIÓN DEL SALDO 
                                         ---- PARA LOS CASOS DE CAMBIO DE CAMPAÑA ENTRE LOS 16 DÍAS
                                         ) fte2
            ON (dest2.ORDER_ID = fte2.ORDER_ID)
    WHEN MATCHED
    THEN
        UPDATE SET
            dest2.PREVIOUS_AMOUNT =
                CASE
                    WHEN dest2.CURRENT_AMOUNT =
                         fte2.PAST_DUE_BALANCE_AMOUNT / 100
                    THEN
                        0
                    ELSE
                        fte2.CURRENT_AMOUNT
                END,
            ---- VALIDAR POR MONTOR MENOR A 10
            dest2.CURRENT_AMOUNT =      ---fte2.PAST_DUE_BALANCE_AMOUNT / 100,
                CASE WHEN PAST_DUE_BALANCE_AMOUNT / 100 <= 10 THEN 0 -- SI ES MENOR A 10 SE PONEN EN 0.
                      ELSE fte2.PAST_DUE_BALANCE_AMOUNT / 100 
                      END,
            dest2.TRANSFER_FLAG =
                CASE
                    WHEN dest2.CURRENT_AMOUNT =
                         fte2.PAST_DUE_BALANCE_AMOUNT / 100
                    --                                             THEN 'T'
                    THEN
                        dest2.TRANSFER_FLAG         -- Se deja el mismo valor.
                    ELSE
                        'E' -- No le puedes hacer cambios porque no se ha mandado a SIMPLI (i.e. se editó)
                END,
            dest2.UPDATED_BY = 'SALDOS BIDS',
            dest2.PAYMENTS_COUNT = NVL (dest2.PAYMENTS_COUNT, 0) + 1,
            dest2.UPDATED_AT = v_valor_fecha_procesado
                 WHERE     (fte2.PAST_DUE_BALANCE_AMOUNT / 100) > 0
                       AND dest2.RETURN_REASON IS NULL;

    --WHERE  dest2.CURRENT_AMOUNT > 1  and dest2.RETURN_REASON is null;


    /* -- */
    MERGE INTO ORDERS dest2
         USING (SELECT oh.ORDER_ID,
                       baff.DUE_BALANCE_AMOUNT,
                       baff.PAST_DUE_BALANCE_AMOUNT,
                       o.PREVIOUS_AMOUNT,
                       o.CURRENT_AMOUNT,
                       oh.ORD_AMOUNT
                  FROM ORDERS  o
                       INNER JOIN SCPI_ORDER_HEADERS oh
                           ON o.ORDER_ID = oh.ORDER_ID
                       INNER JOIN bids_amounts_from_file baff
                           ON (    baff.ACCOUNT = oh.ACCOUNT
                               AND baff.ZONE = oh.ZONE)
                 WHERE oh.ORDER_DATE BETWEEN (  v_valor_fecha_procesado
                                              - v_valor_dias_atras)
                                         AND v_valor_fecha_procesado AND o.CURRENT_AMOUNT > 0 --- VALIDA QUE NOSE HAGA UNA DOBLE APLICACIÓN DEL SALDO 
                                         ---- PARA LOS CASOS DE CAMBIO DE CAMPAÑA ENTRE LOS 16 DÍAS
                                        ) fte2
            ON (dest2.ORDER_ID = fte2.ORDER_ID)
    WHEN MATCHED
    THEN
        UPDATE SET
            dest2.PREVIOUS_AMOUNT =
                CASE
                    WHEN dest2.CURRENT_AMOUNT =
                         fte2.PAST_DUE_BALANCE_AMOUNT / 100
                    THEN
                        0
                    ELSE
                        fte2.CURRENT_AMOUNT
                END,
              ---- VALIDAR POR MONTOR MENOR A 10
            dest2.CURRENT_AMOUNT =      ---fte2.PAST_DUE_BALANCE_AMOUNT / 100,
                CASE WHEN PAST_DUE_BALANCE_AMOUNT / 100 <= 10 THEN 0 -- SI ES MENOR A 10 SE PONEN EN 0.
                ELSE fte2.PAST_DUE_BALANCE_AMOUNT / 100
                END,
            dest2.TRANSFER_FLAG =
                CASE
                    WHEN dest2.CURRENT_AMOUNT =
                         fte2.PAST_DUE_BALANCE_AMOUNT / 100
                    --                                             THEN 'T'
                    THEN
                        dest2.TRANSFER_FLAG         -- Se deja el mismo valor.
                    ELSE
                        'E' -- No le puedes hacer cambios porque no se ha mandado a SIMPLI (i.e. se editó)
                END,
            dest2.UPDATED_BY = 'SALDOS BIDS',
            dest2.PAYMENTS_COUNT = NVL (dest2.PAYMENTS_COUNT, 0) + 1,
            dest2.UPDATED_AT = v_valor_fecha_procesado
                 --  WHERE  (fte2.PAST_DUE_BALANCE_AMOUNT / 100) > 0  and dest2.RETURN_REASON is null;
                 WHERE     dest2.CURRENT_AMOUNT > 1
                       AND dest2.RETURN_REASON IS NULL;

    P_UPDATED_ROWS := SQL%ROWCOUNT;
    COMMIT;
EXCEPTION
    WHEN OTHERS
    THEN
        P_UPDATED_ROWS := SQL%ROWCOUNT;
        ROLLBACK;
        P_ERROR_FLAG := 'S';
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.format_error_backtrace ());
END sp_upd_mtto_saldos_reprs;
/

