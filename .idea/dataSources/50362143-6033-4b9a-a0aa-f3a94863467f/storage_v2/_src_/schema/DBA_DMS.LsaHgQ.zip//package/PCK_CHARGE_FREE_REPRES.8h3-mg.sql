create PACKAGE PCK_CHARGE_FREE_REPRES AS
/******************************************************************************
   NAME:       PCK_CHARGE_FREE_REPRES
   PURPOSE:    PONER SALDOS A CEROS PARA ENTREGA DE ESTAFETA WORK AROUND

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        20/06/2022      reyesros       1. Created this package.
******************************************************************************/



 PROCEDURE SP_UPD_CHARGE_FREE_REPRES (P_ROWS              OUT VARCHAR2,--- REGISTROS PROCESADOS
                                P_ERROR_FLAG         OUT VARCHAR2,
                                P_ERROR_CODE         OUT VARCHAR2,--- NUM DE ERROR
                                P_ERROR_MESSAGE      OUT VARCHAR2,
                                PAYMENTS_PROCESSED   OUT NUMBER,
                                AMOUNTS_PROCESSED    OUT NUMBER);--- ERROR ORACLE
                                
 PROCEDURE SP_UPD_CHARGE_FREE_REPRES_1 ( P_ROWS              OUT VARCHAR2,--- REGISTROS PROCESADOS
                                 P_ERROR_FLAG         OUT VARCHAR2,
                                P_ERROR_CODE         OUT VARCHAR2,--- NUM DE ERROR
                                P_ERROR_MESSAGE      OUT VARCHAR2);--- ERROR ORACLE                               


END PCK_CHARGE_FREE_REPRES;
/

