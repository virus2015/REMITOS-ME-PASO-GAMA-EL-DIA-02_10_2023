create PROCEDURE              SP_G13_ORDER_HEADER(   
                       PA_CODE            OUT INTEGER,
                       PA_MESSAGE         OUT VARCHAR2)
IS


type mi_table_g13 is table of SCPI_ORDER_HEADERS%ROWTYPE;

v_mi_tabla_g13   mi_table_g13;

 CSL_SUCC              CONSTANT SIMPLE_INTEGER := 0;
 CSL_MESSAGE           CONSTANT VARCHAR2 (15) := 'Proceso Exitoso';
 CSL_ONE               CONSTANT SIMPLE_INTEGER := 1;
 CSL_300               CONSTANT SIMPLE_INTEGER := 300;
 VL_ERROR                       VARCHAR2 (300) := ' ';
 CSL_ARROW_INDICATOR   CONSTANT VARCHAR2 (2) := '->';
 
 
               
 
 BEGIN
 
  select * bulk collect into v_mi_tabla_g13  from SCPI_ORDER_HEADERS hs
  where hs.account in ( select  acct_nr from GI3_ORDER_HEADER where ORDER_ID  is null)
  ;
  
    for mi_for in v_mi_tabla_g13.first()..v_mi_tabla_g13.last()
    
    loop
     update GI3_ORDER_HEADER g3 set                  g3.ORDER_ID         = v_mi_tabla_g13(mi_for).order_id,
                                                     g3.UPDATED_BY       = 'G13_USER',                                                    
                                                     g3.UPDATED_AT       =  CURRENT_TIMESTAMP

                    where g3.ORDER_ID                                                is null
                      and substr(g3.CMPGN_PERD_ID,0,4)||substr(g3.CMPGN_PERD_ID,7,8) = v_mi_tabla_g13(mi_for).full_campaign
                      and g3.acct_nr                                                 = v_mi_tabla_g13(mi_for).account;

    end loop;
 
 


 PA_CODE := CSL_SUCC;
 PA_MESSAGE := CSL_MESSAGE;
EXCEPTION
    WHEN OTHERS
    THEN
        ROLLBACK;
        VL_ERROR :=
            SUBSTR (
                   DBMS_UTILITY.FORMAT_ERROR_STACK
                || CSL_ARROW_INDICATOR
                || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                CSL_ONE,
                CSL_300);

        PA_CODE := SQLCODE;
        PA_MESSAGE := VL_ERROR;
        
        END SP_G13_ORDER_HEADER;
/

