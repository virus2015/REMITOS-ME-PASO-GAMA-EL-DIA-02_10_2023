create PACKAGE BODY         PKG_REPRES_ADRESS
/* ***************************************************************************** */
/* ** Nombre    : DMS_DBA.PKG_REPRES_ADRESS                                   ** */
/* ** Para Cía  : AVON                                                        ** */
/* ** Proyecto  : REPRES address                                              ** */
/* **                                                                         ** */
/* ** Descripción : Generación de reportes para Identificar Repres            ** */
/* **               NO PAGO, con Factura actual o no pero con adeudo          ** */
/* **                                 .                                       ** */
/* **                                                                         ** */
/* ** Etapas :     * Repres que solicitan cambios en direccion                ** */
/* **                                                                         ** */
/* **  Objetos que componen PKG:                SP_REPRES_REPORT_ADDRESS      ** */
/* **                                                                         ** */
/* ** Elaborado por:  Ana Gabriela Olvera G.                                  ** */
/* ** Fecha        :  28/12/2022                                              ** */
/* ***************************************************************************** */
AS
   PROCEDURE SP_REPRES_REPORT_ADDRESS (
      pi_campaign         IN  VARCHAR2,
      pi_account   IN NUMBER,
      pi_fec_ini IN DATE,
      pi_fec_fin  IN DATE,
      po_cod OUT VARCHAR2,
      repreAdrress OUT SYS_REFCURSOR)
   /* *************************************************************** */
   /* ** Nombre  :  SP_REPRES_REPORT_ADDRESS                       ** */
   /* ** Función :  Mostrar todas las Repres Facturados y          ** */
   /* **            con adeudo previo  .                           ** */
   /* *************************************************************** */
   AS
      cSqlRepres     VARCHAR2 (8000);
      cSql           VARCHAR2 (8000);
      vCondicion    VARCHAR2 (4000);
      vGroupBy      VARCHAR2  (4000);
            
   BEGIN
   
   
cSqlRepres := '  SELECT UNIQUE RA.ACCOUNT REGISTRO, '||
      ' RP.DEFAULT_ZONE ZONA, '||
      ' RP.SECTION RED, '||
      ' TO_CHAR (RA.CREATED_AT ,'||'''YYYY-MM-DD'''||')  FECHA_SOLICTUD, '||
      ' TO_CHAR (RA.CREATED_AT ,'||'''HH24:MI:SS'''||')  HORA_SOLICITUD, '||      
      ' RA.CREATED_BY USUARIO_SOLICITA, '||
      ' RL.PREVIOUS_ADDRESS1, '||
      ' RA.ADDRES1 NEW_ADDRESS1, '||
      ' RL.PREVIOUS_ADDRESS2, '||
      ' RA.ADDRES2 NEW_ADDRESS2, '||
      ' RL.PREVIOUS_ADDRESS3, '||
      ' RA.ADDRES3 NEW_ADDRESS3, '||
      ' RL.PREVIOUS_MUNICIPALITY, '||
      ' RA.MUNICIPALITY NEW_MUNICIPALITY, '||
      ' RL.PREVIOUS_STATE_CODE, '||
      ' RA.STATE_CODE NEW_STATE_CODE, '||
      ' RL.PREVIOUS_STATE_NAME, '||
      ' RA.STATE_NAME NEW_STATE_NAME, '||
   --   ' CASE '||
  --    '    WHEN RL.PREVIOUS_TELEPHONE <> RA.TELEPHONE '||
  --    '    THEN '||
  --    '       RL.PREVIOUS_TELEPHONE '||
  --    '    ELSE '||
  --    '       ''Sin Cambio en Log'' '||
  --    ' END '||
      ' RL.PREVIOUS_TELEPHONE    PREVIOUS_TELEPHONE, '||
      ' RA.TELEPHONE NEW_TELEPHONE, '||
      ' RL.PREVIOUS_CELLPHONE, '||
      ' RA.CELLPHONE NEW_CELLPHONE, '||
      ' RL.PREVIOUS_EMAIL, '||
      ' RA.EMAIL NEW_EMIL, '||
      ' RL.PREVIOUS_ZIP ,'||
      ' RA.ZIP NEW_ZIP, '||
    --  ' CASE '||
    --  '    WHEN TO_CHAR (RL.NEW_ZONE) <> TO_CHAR (RA.DEFAULT_ZONE) '||
    --  '    THEN '||
    --  '       TO_CHAR (RL.NEW_ZONE) '||
    --  '    ELSE '||
    --  '       ''Sin cambios en Log'' '||
    --  ' END '||
      ' TO_CHAR (RA.DEFAULT_ZONE)   PREVIOUS_ZONE, '||
      ' RL.NEW_ZONE NEW_ZONE, '||
      '    TO_CHAR (RA.UPDATED_AT ,'||'''YYYY-MM-DD HH24:MI:SS'''||') FECHA_HR_APLICACION, '||
      ' CASE '||
      '    WHEN RA.STATUS = ''A'' THEN FN_GET_CAMPAIGN (RA.UPDATED_AT) '||
      '    ELSE NULL '||
      ' END '||
      '    CAMPANA_APLICACION, '||
      ' DECODE (NVL (RA.NR, 0),  ''1'', ''No Reparto'',  ''0'', ''Reparto'') MARCA_NR, '||
      ' DECODE (RA.USER_TYPE, '||
      '         ''G'', ''Gerente'', '||
      '         ''R'', ''Representante'', '||
      '         ''N'', ''Atención y Nombramientos'') '||
      '    PERFIL, '||
      '    RP.REP_STATUS ESTATUS_REPRE, '||
      '       DECODE (UPPER(RA.STATUS), '||
       '               ''P'', ''EN ESPERA DE FECHA DE APLICACIÓN'', '||
      '               ''B'', ''SOLICITUD EN PROCESO'', '||
      '               ''E'', ''SOLICITUD NO APLICADA CONTACTE VÍA WHATSAPP +5511974223520'', '||
      '               ''X'', ''-SOLICITUD NO APLICADA CONTACTE VÍA WHATSAPP +5511974223520-'', '||
      '               ''A'', ''PROCESANDO SOLICITUD'' ,'||
      '               ''D'', ''SOLICITUD EXITOSA'' ,'|| 
      '               ''Y'', ''Zona marcada como Pendiente por parte BIDS sin notificacion'' ,'||
      '               ''G'', ''Zona marcada como Pendiente por parte BIDS repre notificada'' ,'||
      '               ''Z'', ''Zona Rechazada por BIDS'' ,'||
      '               ''W'', ''Zona Aceptada por BIDS'' ,'||  	  
      '               ''S'', ''SOLICITUD RECIBIDA'') ESTATUS_MANTENIMIENTO,'||  
      '     LISTAGG(CE.BIDS_CODE_ERROR_ID || ''-'' || UPPER(BC.DESC_BIDS) || ''-'' ||CE.ERROR_DESC, '', '') WITHIN GROUP (ORDER BY CE.BIDS_CODE_ERROR_ID) MOTIVO_BIDS ' ||      
 ' FROM REPRES_ADDRESS RA '||
      ' LEFT JOIN REPRESENTATIVES RP ON RA.ACCOUNT = RP.ACCOUNT '||
      ' LEFT JOIN REPRES_ADDRESS_LOG RL '||
      '    ON RA.REPRES_ADDRESS_ID = RL.REPRES_ADDRESS_ID '||
      ' LEFT JOIN REPRES_ADDRESS_ERROR RE ON RE.REPRES_ADDRESS_ID = RL.REPRES_ADDRESS_ID ' ||
      ' LEFT JOIN CG_BIDS_CODE_ERROR CE ON RE.BIDS_CODE_ERROR_ID = CE.BIDS_CODE_ERROR_ID  '||
      '  LEFT JOIN cg_bids_code BC ON BC.BIDS_CODE_ID = RE.BIDS_CODE_ERROR_ID ' ||
' WHERE ';

    vGroupBy := 'GROUP BY RA.ACCOUNT,
         RP.DEFAULT_ZONE,
         RP.SECTION,
         RA.CREATED_AT,
         RA.CREATED_BY,
         RA.ADDRES1,
         RL.PREVIOUS_ADDRESS1,
         RA.ADDRES2,
         RL.PREVIOUS_ADDRESS2,
         RA.ADDRES3,
         RL.PREVIOUS_ADDRESS3,
         RA.MUNICIPALITY,
         RL.PREVIOUS_MUNICIPALITY,
         RA.STATE_CODE,
         RL.PREVIOUS_STATE_CODE,
         RA.STATE_NAME,
         RL.PREVIOUS_STATE_NAME,
         RL.PREVIOUS_TELEPHONE,
         RA.TELEPHONE,
         RA.CELLPHONE,
         RL.PREVIOUS_EMAIL,
         RA.EMAIL,
         RL.PREVIOUS_ZIP,
         RA.ZIP,
         RA.DEFAULT_ZONE,
         RL.NEW_ZONE,
         RA.UPDATED_AT,
         RA.STATUS,
         RL.CURRENT_CAMPAIGN,
         USER_TYPE,
         RP.REP_STATUS,
         RL.PREVIOUS_CELLPHONE,
         RA.NR';

   BEGIN
         vCondicion := NULL;
    IF pi_fec_ini IS NULL AND pi_fec_fin IS NULL 
     THEN
         IF pi_campaign IS NOT NULL AND pi_account IS NULL
         THEN
            vCondicion := '  FN_GET_CAMPAIGN (RA.UPDATED_AT) = ' || pi_campaign;
            cSql :=
                  cSqlRepres
               || vCondicion
               || vGroupBy;
               
          ELSIF   pi_account IS NOT NULL AND pi_campaign IS NULL
            THEN
            vCondicion := '  RA.ACCOUNT = ' || pi_account;
            cSql :=
                  cSqlRepres
               || vCondicion
               ||vGroupBy;         
         
          ELSIF   pi_account IS NOT NULL AND pi_campaign IS NOT NULL
            THEN
            vCondicion := '  RA.ACCOUNT = ' || pi_account
                             || 'AND FN_GET_CAMPAIGN (RA.UPDATED_AT) = ' || pi_campaign;
            cSql :=
                  cSqlRepres
               || vCondicion
               || vGroupBy;
                               
         END IF;

    ELSE
          DBMS_OUTPUT.put_line ('c1' );

      IF pi_fec_ini IS NOT NULL AND pi_fec_fin IS NULL  
         THEN
            IF pi_account IS NULL THEN
            vCondicion := '  TO_DATE(TRUNC(RA.CREATED_AT),'||' ''dd/mm/yyyy'' '||') BETWEEN TO_DATE('||''''||pi_fec_ini||''''||',''DD/MM/YYYY'''||') AND TO_DATE('||''''||pi_fec_fin||''''||',''DD/MM/YYYY'''||')'; 
            cSql :=
                  cSqlRepres
               || vCondicion
               || vGroupBy;
               
             ELSE
            vCondicion := ' RA.ACCOUNT = ' || pi_account ||' AND TO_DATE(TRUNC(RA.CREATED_AT),'||' ''dd/mm/yyyy'' '||') BETWEEN TO_DATE('||''''||pi_fec_ini||''''||',''DD/MM/YYYY'''||') AND TO_DATE('||''''||pi_fec_fin||''''||',''DD/MM/YYYY'''||')'; 
            cSql :=
                  cSqlRepres
               || vCondicion
               || vGroupBy;
                           
            END IF; 
          ELSIF   pi_fec_ini IS NULL AND pi_fec_fin IS NOT NULL
            THEN
                    DBMS_OUTPUT.put_line ('c2' );

            IF pi_account IS NULL THEN
            vCondicion := '  TO_DATE(TRUNC(RA.CREATED_AT),'||' ''dd/mm/yyyy'' '||') BETWEEN TO_DATE('||''''||pi_fec_ini||''''||',''DD/MM/YYYY'''||') AND TO_DATE('||''''||pi_fec_fin||''''||',''DD/MM/YYYY'''||')'; 
            cSql :=
                  cSqlRepres
               || vCondicion
               || vGroupBy;
                        
            ELSE
            vCondicion := ' RA.ACCOUNT = ' || pi_account ||' AND TO_DATE(TRUNC(RA.CREATED_AT),'||' ''dd/mm/yyyy'' '||') BETWEEN TO_DATE('||''''||pi_fec_ini||''''||',''DD/MM/YYYY'''||') AND TO_DATE('||''''||pi_fec_fin||''''||',''DD/MM/YYYY'''||')'; 
            cSql :=
                  cSqlRepres
               || vCondicion
               || vGroupBy;
                            
            END IF;               
          ELSIF   pi_fec_ini IS NOT NULL AND pi_fec_fin IS NOT NULL
            THEN
                                DBMS_OUTPUT.put_line ('c3' );

            IF pi_account IS NULL THEN
            vCondicion := '  TO_DATE(TRUNC(RA.CREATED_AT),'||' ''dd/mm/yyyy'' '||') BETWEEN TO_DATE('||''''||pi_fec_ini||''''||',''DD/MM/YYYY'''||') AND TO_DATE('||''''||pi_fec_fin||''''||',''DD/MM/YYYY'''||')'; 
            cSql :=
                  cSqlRepres
               || vCondicion
               || vGroupBy;
               
            ELSE 
            vCondicion := ' RA.ACCOUNT = ' || pi_account ||' AND TO_DATE(TRUNC(RA.CREATED_AT),'||' ''dd/mm/yyyy'' '||') BETWEEN TO_DATE('||''''||pi_fec_ini||''''||',''DD/MM/YYYY'''||') AND TO_DATE('||''''||pi_fec_fin||''''||',''DD/MM/YYYY'''||')'; 
            cSql :=
                  cSqlRepres
               || vCondicion
               || vGroupBy;
                           
            END IF;   
         END IF;
       
      


    END IF;

   END;
         DBMS_OUTPUT.put_line ('cSql1' || '-' || cSql);

      OPEN repreAdrress FOR cSql;
      DBMS_OUTPUT.put_line ('cSql' || '-' || cSql);

   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         NULL;
      WHEN OTHERS
      THEN
         po_cod := SQLCODE;
         --po_msg :=
          --  CONCAT (CONCAT (SQLERRM, '  '),
            --        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
   END SP_REPRES_REPORT_ADDRESS;

END PKG_REPRES_ADRESS;
/

