create PACKAGE BODY PCK_UPSERT_OPCALENDAR IS

  FUNCTION fn_insert_zone_campaign(p_zone_campaigns_tbl PCK_UPSERT_OPCALENDAR.zone_campaigns_tbl
       )
        RETURN NUMBER
    AS
        SQL_STMT  VARCHAR2(32767);
        sql_count NUMBER;
    BEGIN
        FORALL i IN p_zone_campaigns_tbl.first .. p_zone_campaigns_tbl.LAST
                INSERT INTO ZONE_CAMPAIGNS (ZONE,
               DIVISION,
               MAIL_PLAN,
               LDW_CODE,
               CAMPAIGN_YEAR,
               CAMPAIGN,
               CHANGE_FLAG,
               DELETE_FLAG,
               CEDIS,
               UPDATED_AT,
               FULL_CAMPAIGN,
               SENT_AT,
               SUPPLIED_AT,
               BILLED_AT,
               SHIPPED_AT,
               ARRIVED_AT,
               FIRST_ATTEMPT_AT,
               LAST_ATTEMPT_AT,
               ON_PORTEO_UNTIL,
               RESPONSIBLE,
               ESTIMATED_ORDER_QUANTITY,
               REGION
               )
            VALUES ( p_zone_campaigns_tbl(i).ZONE,
               p_zone_campaigns_tbl(i).DIVISION,
               p_zone_campaigns_tbl(i).MAIL_PLAN,
               p_zone_campaigns_tbl(i).LDW_CODE,
               p_zone_campaigns_tbl(i).CAMPAIGN_YEAR,
               p_zone_campaigns_tbl(i).CAMPAIGN,
               p_zone_campaigns_tbl(i).CHANGE_FLAG,
               p_zone_campaigns_tbl(i).DELETE_FLAG,
               p_zone_campaigns_tbl(i).CEDIS,
               p_zone_campaigns_tbl(i).UPDATED_AT,
               p_zone_campaigns_tbl(i).FULL_CAMPAIGN,
               p_zone_campaigns_tbl(i).SENT_AT,
               p_zone_campaigns_tbl(i).SUPPLIED_AT,
               p_zone_campaigns_tbl(i).BILLED_AT,
               p_zone_campaigns_tbl(i).SHIPPED_AT,
               p_zone_campaigns_tbl(i).ARRIVED_AT,
               p_zone_campaigns_tbl(i).FIRST_ATTEMPT_AT,
               p_zone_campaigns_tbl(i).LAST_ATTEMPT_AT,
               p_zone_campaigns_tbl(i).ON_PORTEO_UNTIL,
               p_zone_campaigns_tbl(i).RESPONSIBLE,
               p_zone_campaigns_tbl(i).ESTIMATED_ORDER_QUANTITY,
               p_zone_campaigns_tbl(i).REGION );
               SQL_COUNT:=sql%rowcount;
      RETURN SQL_COUNT;
    end;

  FUNCTION fn_merge_zone_campaign(p_zone_campaigns_tbl PCK_UPSERT_OPCALENDAR.zone_campaigns_tbl
       )
        RETURN NUMBER
    AS
        SQL_STMT  VARCHAR2(32767);
        sql_count NUMBER;
    BEGIN
        FORALL i IN p_zone_campaigns_tbl.first .. p_zone_campaigns_tbl.LAST
            MERGE INTO ZONE_CAMPAIGNS zc
            USING
               ( SELECT p_zone_campaigns_tbl(i).ZONE,
               p_zone_campaigns_tbl(i).DIVISION,
               p_zone_campaigns_tbl(i).MAIL_PLAN,
               p_zone_campaigns_tbl(i).LDW_CODE,
               p_zone_campaigns_tbl(i).CAMPAIGN_YEAR,
               p_zone_campaigns_tbl(i).CAMPAIGN,
               p_zone_campaigns_tbl(i).CHANGE_FLAG,
               p_zone_campaigns_tbl(i).DELETE_FLAG,
               p_zone_campaigns_tbl(i).CEDIS,
               p_zone_campaigns_tbl(i).UPDATED_AT,
               p_zone_campaigns_tbl(i).FULL_CAMPAIGN,
               p_zone_campaigns_tbl(i).SENT_AT,
               p_zone_campaigns_tbl(i).SUPPLIED_AT,
               p_zone_campaigns_tbl(i).BILLED_AT,
               p_zone_campaigns_tbl(i).SHIPPED_AT,
               p_zone_campaigns_tbl(i).ARRIVED_AT,
               p_zone_campaigns_tbl(i).FIRST_ATTEMPT_AT,
               p_zone_campaigns_tbl(i).LAST_ATTEMPT_AT,
               p_zone_campaigns_tbl(i).ON_PORTEO_UNTIL,
               p_zone_campaigns_tbl(i).RESPONSIBLE,
               p_zone_campaigns_tbl(i).ESTIMATED_ORDER_QUANTITY,
               p_zone_campaigns_tbl(i).REGION FROM DUAL ) p
            ON ( zc.ZONE = p_zone_campaigns_tbl(i).ZONE AND
               zc.FULL_CAMPAIGN = p_zone_campaigns_tbl(i).FULL_CAMPAIGN )
               WHEN MATCHED THEN
                  UPDATE SET 
                   zc.ZONE = p_zone_campaigns_tbl(i).ZONE ,
                   zc.DIVISION = p_zone_campaigns_tbl(i).DIVISION ,
                   zc.MAIL_PLAN = p_zone_campaigns_tbl(i).MAIL_PLAN ,
                   zc.LDW_CODE = p_zone_campaigns_tbl(i).LDW_CODE ,
                   zc.CAMPAIGN_YEAR = p_zone_campaigns_tbl(i).CAMPAIGN_YEAR ,
                   zc.CAMPAIGN = p_zone_campaigns_tbl(i).CAMPAIGN ,
                   zc.CHANGE_FLAG = p_zone_campaigns_tbl(i).CHANGE_FLAG ,
                   zc.DELETE_FLAG = p_zone_campaigns_tbl(i).DELETE_FLAG ,
                   zc.CEDIS = p_zone_campaigns_tbl(i).CEDIS ,
                   zc.UPDATED_AT = p_zone_campaigns_tbl(i).UPDATED_AT ,
                   zc.FULL_CAMPAIGN = p_zone_campaigns_tbl(i).FULL_CAMPAIGN ,
                   zc.SENT_AT = p_zone_campaigns_tbl(i).SENT_AT ,
                   zc.SUPPLIED_AT = p_zone_campaigns_tbl(i).SUPPLIED_AT ,
                   zc.BILLED_AT = p_zone_campaigns_tbl(i).BILLED_AT ,
                   zc.SHIPPED_AT = p_zone_campaigns_tbl(i).SHIPPED_AT ,
                   zc.ARRIVED_AT = p_zone_campaigns_tbl(i).ARRIVED_AT ,
                   zc.FIRST_ATTEMPT_AT = p_zone_campaigns_tbl(i).FIRST_ATTEMPT_AT ,
                   zc.LAST_ATTEMPT_AT = p_zone_campaigns_tbl(i).LAST_ATTEMPT_AT ,
                   zc.ON_PORTEO_UNTIL = p_zone_campaigns_tbl(i).ON_PORTEO_UNTIL ,
                   zc.RESPONSIBLE = p_zone_campaigns_tbl(i).RESPONSIBLE ,
                   zc.ESTIMATED_ORDER_QUANTITY = p_zone_campaigns_tbl(i).ESTIMATED_ORDER_QUANTITY ,
                   zc.REGION = p_zone_campaigns_tbl(i).REGION
               WHEN NOT MATCHED THEN INSERT
                         (ZONE,
                       DIVISION,
                       MAIL_PLAN,
                       LDW_CODE,
                       CAMPAIGN_YEAR,
                       CAMPAIGN,
                       CHANGE_FLAG,
                       DELETE_FLAG,
                       CEDIS,
                       UPDATED_AT,
                       FULL_CAMPAIGN,
                       SENT_AT,
                       SUPPLIED_AT,
                       BILLED_AT,
                       SHIPPED_AT,
                       ARRIVED_AT,
                       FIRST_ATTEMPT_AT,
                       LAST_ATTEMPT_AT,
                       ON_PORTEO_UNTIL,
                       RESPONSIBLE,
                       ESTIMATED_ORDER_QUANTITY,
                       REGION)
                    VALUES (p_zone_campaigns_tbl(i).ZONE,
                       p_zone_campaigns_tbl(i).DIVISION,
                       p_zone_campaigns_tbl(i).MAIL_PLAN,
                       p_zone_campaigns_tbl(i).LDW_CODE,
                       p_zone_campaigns_tbl(i).CAMPAIGN_YEAR,
                       p_zone_campaigns_tbl(i).CAMPAIGN,
                       p_zone_campaigns_tbl(i).CHANGE_FLAG,
                       p_zone_campaigns_tbl(i).DELETE_FLAG,
                       p_zone_campaigns_tbl(i).CEDIS,
                       p_zone_campaigns_tbl(i).UPDATED_AT,
                       p_zone_campaigns_tbl(i).FULL_CAMPAIGN,
                       p_zone_campaigns_tbl(i).SENT_AT,
                       p_zone_campaigns_tbl(i).SUPPLIED_AT,
                       p_zone_campaigns_tbl(i).BILLED_AT,
                       p_zone_campaigns_tbl(i).SHIPPED_AT,
                       p_zone_campaigns_tbl(i).ARRIVED_AT,
                       p_zone_campaigns_tbl(i).FIRST_ATTEMPT_AT,
                       p_zone_campaigns_tbl(i).LAST_ATTEMPT_AT,
                       p_zone_campaigns_tbl(i).ON_PORTEO_UNTIL,
                       p_zone_campaigns_tbl(i).RESPONSIBLE,
                       p_zone_campaigns_tbl(i).ESTIMATED_ORDER_QUANTITY,
                       p_zone_campaigns_tbl(i).REGION);
                        SQL_COUNT:=sql%rowcount;

      RETURN SQL_COUNT;
    end;


    FUNCTION fn_update_zone_campaign(p_zone_campaigns_tbl PCK_UPSERT_OPCALENDAR.zone_campaigns_tbl
       )
        RETURN NUMBER
    AS
        SQL_STMT  VARCHAR2(32767);
        sql_count NUMBER;
    BEGIN
        FORALL i IN p_zone_campaigns_tbl.first .. p_zone_campaigns_tbl.LAST
                UPDATE ZONE_CAMPAIGNS zc SET 
                   zc.ZONE = p_zone_campaigns_tbl(i).ZONE ,
                   zc.DIVISION = p_zone_campaigns_tbl(i).DIVISION ,
                   zc.MAIL_PLAN = p_zone_campaigns_tbl(i).MAIL_PLAN ,
                   zc.LDW_CODE = p_zone_campaigns_tbl(i).LDW_CODE ,
                   zc.CAMPAIGN_YEAR = p_zone_campaigns_tbl(i).CAMPAIGN_YEAR ,
                   zc.CAMPAIGN = p_zone_campaigns_tbl(i).CAMPAIGN ,
                   zc.CHANGE_FLAG = p_zone_campaigns_tbl(i).CHANGE_FLAG ,
                   zc.DELETE_FLAG = p_zone_campaigns_tbl(i).DELETE_FLAG ,
                   zc.CEDIS = p_zone_campaigns_tbl(i).CEDIS ,
                   zc.UPDATED_AT = p_zone_campaigns_tbl(i).UPDATED_AT ,
                   zc.FULL_CAMPAIGN = p_zone_campaigns_tbl(i).FULL_CAMPAIGN ,
                   zc.SENT_AT = p_zone_campaigns_tbl(i).SENT_AT ,
                   zc.SUPPLIED_AT = p_zone_campaigns_tbl(i).SUPPLIED_AT ,
                   zc.BILLED_AT = p_zone_campaigns_tbl(i).BILLED_AT ,
                   zc.SHIPPED_AT = p_zone_campaigns_tbl(i).SHIPPED_AT ,
                   zc.ARRIVED_AT = p_zone_campaigns_tbl(i).ARRIVED_AT ,
                   zc.FIRST_ATTEMPT_AT = p_zone_campaigns_tbl(i).FIRST_ATTEMPT_AT ,
                   zc.LAST_ATTEMPT_AT = p_zone_campaigns_tbl(i).LAST_ATTEMPT_AT ,
                   zc.ON_PORTEO_UNTIL = p_zone_campaigns_tbl(i).ON_PORTEO_UNTIL ,
                   zc.RESPONSIBLE = p_zone_campaigns_tbl(i).RESPONSIBLE ,
                   zc.ESTIMATED_ORDER_QUANTITY = p_zone_campaigns_tbl(i).ESTIMATED_ORDER_QUANTITY ,
                   zc.REGION = p_zone_campaigns_tbl(i).REGION
                WHERE zc.ZONE = p_zone_campaigns_tbl(i).ZONE 
                AND zc.FULL_CAMPAIGN = p_zone_campaigns_tbl(i).FULL_CAMPAIGN;
               SQL_COUNT:=sql%rowcount;
      RETURN SQL_COUNT;
    end;

END PCK_UPSERT_OPCALENDAR;
/

