create PACKAGE         PCK_DBA_LOG IS
  /******************************************************************************
   NAME:       PCK_DBA_LOG
   PURPOSE:    GUARDA ERRORES ORACLE

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        25/03/2021  ROSSANA REYES     1. Created this package.
******************************************************************************/

  PROCEDURE INS_DBA_LOG
    (
     PA_OBJECT      IN VARCHAR2,
     PA_PARAMETERS IN VARCHAR2,
     PA_SQLCODE     IN VARCHAR2,
     PA_SQLERRM     IN VARCHAR2
    );

  PROCEDURE INSERT_DBA_LOG
    (
     PA_OBJECT      IN VARCHAR2,
     PA_PARAMETERS IN VARCHAR2,
     PA_SQLCODE     IN VARCHAR2,
     PA_SQLERRM     IN VARCHAR2
    );
  PROCEDURE DEL_DBA_LOG
    (PA_FECHA IN VARCHAR2,
	 PA_ROWNUM IN NUMBER );
END PCK_DBA_LOG;
/

