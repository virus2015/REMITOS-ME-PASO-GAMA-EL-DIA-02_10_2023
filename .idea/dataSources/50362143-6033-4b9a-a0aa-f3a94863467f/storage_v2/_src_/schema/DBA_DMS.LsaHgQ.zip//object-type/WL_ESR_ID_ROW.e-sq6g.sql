create TYPE WL_ESR_ID_ROW AS OBJECT 
( /* TODO enter attribute and method declarations here */
P_ACCOUNT NUMBER,
P_CAMPAING NUMBER
)
/

