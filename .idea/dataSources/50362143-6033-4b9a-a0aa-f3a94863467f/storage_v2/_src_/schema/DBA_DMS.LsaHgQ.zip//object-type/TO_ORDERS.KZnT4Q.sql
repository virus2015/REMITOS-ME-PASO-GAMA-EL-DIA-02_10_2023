create TYPE         to_orders AS OBJECT
( 
ID_ORDER number (38)
);
/

