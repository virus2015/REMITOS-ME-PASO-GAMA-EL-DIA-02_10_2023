create PACKAGE BODY         PKG_REPRES_NO_PAGO
/* ***************************************************************************** */
/* ** Nombre    : DMS_DBA.PKG_REPRES_NO_PAGO                                  ** */
/* ** Para Cía  : AVON                                                        ** */
/* ** Proyecto  : REPRES NO PAGO                                              ** */
/* **                                                                         ** */
/* ** Descripción : Generación de reportes para Identificar Repres            ** */
/* **               NO PAGO, con Factura actual o no pero con adeudo          ** */
/* **                                 .                                       ** */
/* **                                                                         ** */
/* ** Etapas :     * Repres que Facturaron y deben campaña previa             ** */
/* **              * Repres que NO Facturaron y deben campañas previas        ** */
/* **                                                                         ** */
/* **  Objetos que componen PKG:                SP_REPRES_FACTURO             ** */
/* **                                                                         ** */
/* ** Elaborado por:  Ana Gabriela Olvera G.                                  ** */
/* ** Fecha        :  20/10/2022                                              ** */
/* ***************************************************************************** */
AS
   PROCEDURE SP_REPRES_FACTURO (
      pi_zona         IN     NUMBER,
      po_cod             OUT VARCHAR2,
      po_msg             OUT VARCHAR2,
      repreFactura      OUT SYS_REFCURSOR)
   /* *************************************************************** */
   /* ** Nombre  :  SP_REPRES_FACTURO                              ** */
   /* ** Función :  Mostrar todas las Repres Facturados y          ** */
   /* **            con adeudo previo  .                           ** */
   /* *************************************************************** */
   AS
      cSqlRepres     VARCHAR2 (4000);
      cSql           VARCHAR2 (8000);
      vCondicion1    VARCHAR2 (4000);
      vCondicion2    VARCHAR2 (4000);
      vCondicion3    VARCHAR2 (4000);
      vCondicion0    VARCHAR2 (4000);
      
   BEGIN
   
   
cSqlRepres := ' SELECT X.ZONE_ID AS "ZONA", '||
  '     R.SECTION AS "RED",    '||
  '     X.ACCOUNT AS "REGISTRO", ' ||
  '      FF.POP_FLAG , ' ||
  '     R.ACCOUNT_NAME AS "NOMBRE", '||
  '        R.ADDRESS1 || '',''|| R.ADDRESS2 || '', '' || R.MUNICIPALITY || '', '' || R.STATE_NAME AS "DIRECCION", '||
  '    R.CELLPHONE, '||
  '    R.TELEPHONE, '||
  '     R.PARENT_ACCOUNT AS "COD_MAMA_EMPRESARIA",'||
  '      PA.ACCOUNT_NAME AS "NOMBRE_MAMA_EMPRESARIA",'||
  '     (SELECT NVL (Z.CELLPHONE, Z.TELEPHONE)'||
  '        FROM REPRESENTATIVES Z'||
  '       WHERE Z.ACCOUNT = X.ACCOUNT)'||
  '        AS "TEL_MAMA_EMPRESARIA", '||
--  '     X.REPRESENTATIVE_TYPE AS "TP",'||
  '     X.CAMPAIGN_UPDATE AS "CUP",'||
  '     X.CURRENT_BALANCE AS "SALDO",'||
  '     X.COD_AMOUNT AS "C.O.D",'||
  '     X.ORDER_AMOUNT AS "FICHA",'||
  '     X.FULL_CAMPAIGN_1 AS "CAM1",'||
  '     NVL(R1.STATUS_DESC,''NA'') AS "ST1",'||
  '     X.AMOUNT_1 AS "IMPTE_CM1",'||
  '     X.FULL_CAMPAIGN_2 AS "CAM2",'||
  '     NVL(R2.STATUS_DESC,''NA'') AS "ST2",'||
  '     X.AMOUNT_2 AS "IMPTE_CM2"'||
  ' FROM REPRESENTATIVES R '||
  '      INNER JOIN STATUS_BALANCE_REPRES X ON X.ACCOUNT = R.ACCOUNT '||
  '      LEFT JOIN REPRESENTATIVES PA ON PA.ACCOUNT = R.PARENT_ACCOUNT '||
  '  LEFT JOIN  CG_STATUS_BALANCE_BIDS  R1 '||
  ' ON R1.ID_STATUS_BALANCE_BIDS =  X.ID_STATUS_BALANCE_BIDS_1 '||
  '     LEFT JOIN  CG_STATUS_BALANCE_BIDS  R2 '||
  '  ON R2.ID_STATUS_BALANCE_BIDS =  X.ID_STATUS_BALANCE_BIDS_2 '||
  ' LEFT JOIN  CG_STATUS_BALANCE_BIDS  R3 '||
  ' ON R3.ID_STATUS_BALANCE_BIDS =  X.ID_STATUS_BALANCE_BIDS_3 '||
  ' LEFT JOIN  CG_STATUS_BALANCE_BIDS  R4 '||
  ' ON R4.ID_STATUS_BALANCE_BIDS =  X.ID_STATUS_BALANCE_BIDS_4   inner join BIDS_AMOUNTS_FROM_FILE  ff on ff.account=r.account  ';

  vCondicion0 := ' WHERE X.ZONE_ID = '||pi_Zona||
    ' and  FF.POP_FLAG = ''P'' '||
    ' and X.FULL_CAMPAIGN_1 = X.CAMPAIGN_UPDATE '||
    ' and R1.ID_STATUS_BALANCE_BIDS in (1,2) ';


    vCondicion1 := ' WHERE X.ZONE_ID = '||pi_Zona||
    ' and  FF.POP_FLAG is null'||
    ' AND X.FULL_CAMPAIGN_1 in ( select case  when X.CAMPAIGN_UPDATE != fn_get_current_campaign '||
    '    then (  select   FN_GET_PREVIOUS_CAMPAIGN( fn_get_current_campaign-X.CAMPAIGN_UPDATE) from dual )'||
    '     else (select   FN_GET_PREVIOUS_CAMPAIGN(2) from dual) end as CAMPO_01  from dual)'||
    '  and X.FULL_CAMPAIGN_2 in ('||
    ' select   FN_GET_PREVIOUS_CAMPAIGN( fn_get_current_campaign-X.CAMPAIGN_UPDATE) from dual'||
    '                     union'||
    '  select   FN_GET_PREVIOUS_CAMPAIGN( ( fn_get_current_campaign-X.CAMPAIGN_UPDATE)+1) from dual)  '||
    ' and R2.ID_STATUS_BALANCE_BIDS in (1,2)' ;

     
 
  vCondicion2 := '  WHERE X.ZONE_ID = '||pi_Zona||
  '  AND X.FULL_CAMPAIGN_1 in ( select case  when X.CAMPAIGN_UPDATE != fn_get_current_campaign '||
   '           then (  select   FN_GET_PREVIOUS_CAMPAIGN( (fn_get_current_campaign-X.CAMPAIGN_UPDATE)+1) from dual )'||
   '           else (select   FN_GET_PREVIOUS_CAMPAIGN(2) from dual) end as CAMPO_01  from dual'||
    '                                    UNION'||
   '           select case  when X.CAMPAIGN_UPDATE != fn_get_current_campaign '||
   '           then (  select   FN_GET_PREVIOUS_CAMPAIGN( (fn_get_current_campaign-X.CAMPAIGN_UPDATE)+2) from dual )'||
   '           else (select   FN_GET_PREVIOUS_CAMPAIGN(2) from dual) end as CAMPO_01  from dual)'||
   '           and R1.ID_STATUS_BALANCE_BIDS in (1,2) ';
    
     
   cSql := cSqlRepres || 
          vCondicion0 ||        
            ' UNION ' ||
           cSqlRepres ||
         vCondicion1 ||
           ' UNION ' ||
           cSqlRepres ||
         vCondicion2;
              
        --   cSql := cSqlRepres || 
         -- vCondicion1 ;
          
    
       
   
      DBMS_OUTPUT.put_line ('cSql' || '-' || cSql);
      OPEN repreFactura FOR cSql;
      

   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         NULL;
      WHEN OTHERS
      THEN
         po_cod := SQLCODE;
         po_msg :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
   END SP_REPRES_FACTURO;

END PKG_REPRES_NO_PAGO;
/

