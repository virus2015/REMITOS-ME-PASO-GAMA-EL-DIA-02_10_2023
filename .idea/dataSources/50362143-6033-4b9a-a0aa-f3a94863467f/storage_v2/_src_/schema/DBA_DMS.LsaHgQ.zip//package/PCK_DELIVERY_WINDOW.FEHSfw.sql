create PACKAGE         PCK_DELIVERY_WINDOW IS
  /******************************************************************************
   NAME:       PCK_DELIVERY_WINDOW
   PURPOSE:    PERFORMS OPERATIONS BASED ON THE DELIVERY WINDOW BUSINESS PROCESS

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        15/04/2021  JUAN C LOZANO    1. Created this package.
******************************************************************************/

  PROCEDURE STP_UPD_ROUTES_DELIVERY_DATE
    (
      I_INPUT_ROWS IN DBA_DMS.DELIVERY_ROUTES_UPD_DATE_TBL,
      O_ERROR_FLAG OUT VARCHAR2,
      O_ERROR_MESSAGE OUT VARCHAR2,
      O_ERROR_ROWS OUT DBA_DMS.DELVRY_ROUTES_UPD_DT_ERR_TBL,
      O_ROW_COUNT OUT NUMBER
    );

END PCK_DELIVERY_WINDOW;
/

