create PACKAGE         PCK_DELETE_DATA_UTILS
    AUTHID CURRENT_USER
AS
    /******************************************************************************
       NAME:       PCK_DELETE_DATA_UTILS
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        05/05/2021      reyesros       1. Created this package.
    ******************************************************************************/
    PROCEDURE SP_DELETING_LOG (PA_GROUPED_BY                IN NUMBER, ---AGRUPADOS
                               PA_DELETE_DATA_ID            IN NUMBER,   ---ID
                               PA_ITERATION_ID              IN NUMBER, ---ITERACIÓN
                               PA_STARTING_DATA_COUNT       IN NUMBER, -- CONTEO INICIAL DE DATOS
                               PA_DELETING_DATA_COUNT       IN NUMBER, -- CONTEO DE DATOS PARA BORRAR
                               PA_SUCCESSFUL_BACKUP         IN NUMBER, -- TERMINA  BACKUP
                               PA_FILE_CREATION             IN NUMBER, -- COMIENZA A CREAR EL ARCHIVO DE RESPALDO
                               PA_SUCCESSFUL_FILE           IN NUMBER, -- TERMINA A CREAR EL ARCHIVO DE RESPALDO
                               PA_REMAINING_DATA_COUNT      IN NUMBER, -- CONTEO FINAL DE DATOS EN TABLA DESPUES DE BORRADO
                               PA_SUCCESSFUL_REINDEXATION   IN NUMBER, --- MOMENTO DE TÉRMINO DEL LA REINDEXACIÓN
                               PA_END                       IN NUMBER -- FLAG PARA PONER ESTAMPA DE TIEMPO AL FINAL DEL PROCESO
                                                                     --,PA_STATUS                  OUT NUMBER----0 EXITOSO, 1 ALGO PASÓ
                                                                     );

    PROCEDURE SP_GET_GROUP (PA_OWNER          IN     VARCHAR2,    ---- ESQUEMA
                            PA_ITERATION_ID   IN     NUMBER,      ---ITERACIÓN
                            PA_LIST              OUT VARCHAR2, ----LISTA DE TABLAS DE TRABAJO
                            PA_EXECUTION         OUT NUMBER, --  1 - TODO OK, 0 - ALGO SALÍO MAL
                            PA_PROCESS           OUT VARCHAR2   -- IMPRIME LOG
                                                             );
END PCK_DELETE_DATA_UTILS;
/

