create procedure sp_transfer_bank_codes_dms
(	p_bank_code in char,
    p_bank_name   out varchar2, 
    p_cash_flag   out char, 
    p_change_flag out char, 
    p_delete_flag out char, 
    p_updated_at  out timestamp,
    p_transfer_flag  out char,
    p_error_flag out varchar2,
    p_error_code out varchar2,
    p_error_message out varchar2
)
is
begin
    SELECT 
        bank_name,         cash_flag,         change_flag,         delete_flag,         updated_at
    INTO 
        p_bank_name, 
        p_cash_flag, 
        p_change_flag, 
        p_delete_flag, 
        p_updated_at
    FROM BANK_CODES
    WHERE bank_code = p_bank_code;

      p_transfer_flag := 1;
    UPDATE BANK_CODES SET transfer_flag = 1 WHERE bank_code = p_bank_code;
    COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
         p_error_code := SQLCODE;
         p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
         p_error_flag := 'S';


 end sp_transfer_bank_codes_dms;
/

