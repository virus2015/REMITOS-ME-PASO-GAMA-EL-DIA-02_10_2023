create PACKAGE PCK_UPDATE_ADDRESSES IS
  FUNCTION fn_update_addresses1
        RETURN NUMBER;
      FUNCTION fn_update_addresses2(p_limit number)
      return number;
END PCK_UPDATE_ADDRESSES;
/

