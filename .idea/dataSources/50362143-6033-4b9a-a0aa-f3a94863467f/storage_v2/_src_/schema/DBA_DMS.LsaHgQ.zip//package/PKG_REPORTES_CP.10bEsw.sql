create PACKAGE         PKG_REPORTES_CP
AS
   /* PCR Consulta Remitos/MiscelaneosGZ*/
   PROCEDURE SP_REMITOGZ_PORTE (pi_campaign   IN     NUMBER,
                                pi_Ruta       IN     NUMBER,
                                pi_Account    IN     NUMBER,
                                pi_Zona       IN     NUMBER,
                                pi_ldc        IN     VARCHAR2,
                                po_cod           OUT VARCHAR2,
                                po_msg           OUT VARCHAR2,
                                RemitoGZ_CP      OUT SYS_REFCURSOR);


   /* PRC Consulta LH Miscelaneos Sin Agrupar  */
   PROCEDURE SP_LH_SIN_GROUP_MISCELANEOS (pi_campaign   IN     NUMBER,
                                          pi_ldc        IN     VARCHAR2,
                                          pi_zona       IN     NUMBER,
                                          pi_placa      IN     VARCHAR2,
                                          po_cod           OUT VARCHAR2,
                                          po_msg           OUT VARCHAR2,
                                          lhAgrupado       OUT SYS_REFCURSOR);


   /* PRC Consulta LH con Miscelaneos Agrupado  */
   PROCEDURE SP_LH_AGRUPADO_MISCELANEOS (
      pi_campaign     IN     NUMBER,
      pi_ldc          IN     VARCHAR2,
      pi_zona         IN     NUMBER,
      pi_placa        IN     VARCHAR2,
      po_cod             OUT VARCHAR2,
      po_msg             OUT VARCHAR2,
      lhAgrupadoMis      OUT SYS_REFCURSOR);
      


   /* PRC Consulta VEAS ENTREGADOS  */
 PROCEDURE SP_VEAS_ENTREGADOS (pi_campaign   IN     NUMBER,
                                pi_Zona       IN     NUMBER,
                                pi_ldc        IN     VARCHAR2,
                                po_cod           OUT VARCHAR2,
                                po_msg           OUT VARCHAR2,
                                Veas_Entregados      OUT SYS_REFCURSOR);    


   /* PRC Consulta VEAS ENTREGADOS  */
 PROCEDURE SP_VEAS_DEVOLUCIONES (pi_campaign   IN     NUMBER,
                                pi_Zona       IN     NUMBER,
                                pi_ldc        IN     VARCHAR2,
                                po_cod           OUT VARCHAR2,
                                po_msg           OUT VARCHAR2,
                                Veas_Devoluciones      OUT SYS_REFCURSOR);    
END PKG_REPORTES_CP;
/

