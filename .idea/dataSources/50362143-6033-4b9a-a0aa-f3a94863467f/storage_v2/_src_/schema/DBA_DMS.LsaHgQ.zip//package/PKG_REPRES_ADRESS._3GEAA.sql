create PACKAGE         PKG_REPRES_ADRESS
AS
  
   /* PRC Consulta Repres que cambiaron algun valor en sus datos de dirección  */
   PROCEDURE SP_REPRES_REPORT_ADDRESS (
      pi_campaign         IN  VARCHAR2,
      pi_account   IN NUMBER,
      pi_fec_ini IN DATE,
      pi_fec_fin  IN DATE,
      po_cod OUT VARCHAR2,
      repreAdrress OUT SYS_REFCURSOR);
      


END PKG_REPRES_ADRESS;
/

