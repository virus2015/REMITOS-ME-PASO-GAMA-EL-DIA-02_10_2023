create FUNCTION         FN_SUBTRACT_CAMPAIGN(
        baseCamp IN NUMBER,
		numCampBefore IN NUMBER)
	RETURN NUMBER
IS
	tempYear NUMBER;
	tempCamp NUMBER;
	tempFull NUMBER;
	maxCamp NUMBER;
BEGIN
	maxCamp := 19; -- NUMERO DE CAMPAÑAS MAXIMO

	SELECT baseCamp INTO tempFull FROM DUAL;

	tempCamp := MOD(tempFull,100) ;
	tempYear := (tempFull - tempCamp) / 100;

	IF(tempCamp <= numCampBefore) THEN
		tempCamp := maxCamp + tempCamp - numCampBefore;
		tempYear := tempYear - 1;
	ELSE
		tempCamp := tempCamp - numCampBefore;
	END IF;

	RETURN (tempYear * 100) + tempCamp;
END;
/

