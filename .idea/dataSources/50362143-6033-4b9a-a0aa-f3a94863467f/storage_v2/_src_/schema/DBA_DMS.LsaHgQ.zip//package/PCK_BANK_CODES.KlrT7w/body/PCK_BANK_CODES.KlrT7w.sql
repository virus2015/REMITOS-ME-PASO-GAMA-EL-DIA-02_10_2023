create PACKAGE BODY PCK_BANK_CODES IS

  FUNCTION fn_insert_bank_codes(p_bank_codes_tbl PCK_BANK_CODES.bank_codes_tbl
       )
        RETURN NUMBER
    AS
        SQL_STMT  VARCHAR2(32767);
        sql_count NUMBER;
    BEGIN
        FORALL i IN p_bank_codes_tbl.first .. p_bank_codes_tbl.LAST
                INSERT INTO bank_codes 
                (   BANK_CODE, 
                    BANK_NAME, 
                    CASH_FLAG, 
                    CHANGE_FLAG, 
                    DELETE_FLAG, 
                    UPDATED_AT, 
                    TRANSFER_FLAG
               )
            VALUES ( p_bank_codes_tbl(i).BANK_CODE, 
                    p_bank_codes_tbl(i).BANK_NAME, 
                    p_bank_codes_tbl(i).CASH_FLAG, 
                    p_bank_codes_tbl(i).CHANGE_FLAG, 
                    p_bank_codes_tbl(i).DELETE_FLAG, 
                    p_bank_codes_tbl(i).UPDATED_AT, 
                    p_bank_codes_tbl(i).TRANSFER_FLAG );
               SQL_COUNT:=sql%rowcount;
      RETURN SQL_COUNT;
    end;

  FUNCTION fn_merge_bank_codes(p_bank_codes_tbl PCK_BANK_CODES.bank_codes_tbl
       )
        RETURN NUMBER
    AS
        SQL_STMT  VARCHAR2(32767);
        sql_count NUMBER;
    BEGIN
        FORALL i IN p_bank_codes_tbl.first .. p_bank_codes_tbl.LAST
            MERGE INTO bank_codes bc
            USING
               ( SELECT p_bank_codes_tbl(i).BANK_CODE, 
                    p_bank_codes_tbl(i).BANK_NAME, 
                    p_bank_codes_tbl(i).CASH_FLAG, 
                    p_bank_codes_tbl(i).CHANGE_FLAG, 
                    p_bank_codes_tbl(i).DELETE_FLAG, 
                    p_bank_codes_tbl(i).UPDATED_AT, 
                    p_bank_codes_tbl(i).TRANSFER_FLAG FROM DUAL ) p
            ON ( bc.BANK_CODE = p_bank_codes_tbl(i).BANK_CODE AND
               bc.BANK_NAME = p_bank_codes_tbl(i).BANK_NAME )
               WHEN MATCHED THEN
                  UPDATE SET 
                    bc.BANK_CODE = p_bank_codes_tbl(i).BANK_CODE, 
                    bc.BANK_NAME = p_bank_codes_tbl(i).BANK_NAME, 
                    bc.CASH_FLAG = p_bank_codes_tbl(i).CASH_FLAG, 
                    bc.CHANGE_FLAG = p_bank_codes_tbl(i).CHANGE_FLAG, 
                    bc.DELETE_FLAG = p_bank_codes_tbl(i).DELETE_FLAG, 
                    bc.UPDATED_AT = p_bank_codes_tbl(i).UPDATED_AT, 
                    bc.TRANSFER_FLAG = p_bank_codes_tbl(i).TRANSFER_FLAG
               WHEN NOT MATCHED THEN INSERT
                         (  BANK_CODE, 
                            BANK_NAME, 
                            CASH_FLAG, 
                            CHANGE_FLAG, 
                            DELETE_FLAG, 
                            UPDATED_AT, 
                            TRANSFER_FLAG)
                    VALUES (p_bank_codes_tbl(i).BANK_CODE, 
                            p_bank_codes_tbl(i).BANK_NAME, 
                            p_bank_codes_tbl(i).CASH_FLAG, 
                            p_bank_codes_tbl(i).CHANGE_FLAG, 
                            p_bank_codes_tbl(i).DELETE_FLAG, 
                            p_bank_codes_tbl(i).UPDATED_AT, 
                            p_bank_codes_tbl(i).TRANSFER_FLAG);
                        SQL_COUNT:=sql%rowcount;

      RETURN SQL_COUNT;
    end;


    FUNCTION fn_update_bank_codes(p_bank_codes_tbl PCK_BANK_CODES.bank_codes_tbl
       )
        RETURN NUMBER
    AS
        SQL_STMT  VARCHAR2(32767);
        SQL_COUNT NUMBER;
    BEGIN
        FORALL i IN p_bank_codes_tbl.first .. p_bank_codes_tbl.LAST
                UPDATE bank_codes bc SET 
                                       bc.BANK_CODE = p_bank_codes_tbl(i).BANK_CODE, 
                    bc.BANK_NAME = p_bank_codes_tbl(i).BANK_NAME, 
                    bc.CASH_FLAG = p_bank_codes_tbl(i).CASH_FLAG, 
                    bc.CHANGE_FLAG = p_bank_codes_tbl(i).CHANGE_FLAG, 
                    bc.DELETE_FLAG = p_bank_codes_tbl(i).DELETE_FLAG, 
                    bc.UPDATED_AT = p_bank_codes_tbl(i).UPDATED_AT, 
                    bc.TRANSFER_FLAG = p_bank_codes_tbl(i).TRANSFER_FLAG;
               SQL_COUNT:=sql%rowcount;
      RETURN SQL_COUNT;
    end;

    FUNCTION fn_update_bank_codes_array(p_bank_codes_array PCK_BANK_CODES.bank_codes_array
       )
        RETURN NUMBER
    AS
        SQL_STMT  VARCHAR2(32767);
        SQL_COUNT NUMBER;
    BEGIN
        FORALL i IN p_bank_codes_array.first .. p_bank_codes_array.LAST
                UPDATE bank_codes bc SET 
                    bc.CHANGE_FLAG = 'T', 
                    bc.TRANSFER_FLAG = 'T'
                    WHERE bc.BANK_CODE = p_bank_codes_array(i).BANK_CODE;
               SQL_COUNT:=sql%rowcount;
      RETURN SQL_COUNT;
    end;


    PROCEDURE sp_transfer_bank_codes_dms
    (	p_bank_code in char,
        p_bank_name   out varchar2, 
        p_cash_flag   out char, 
        p_change_flag out char, 
        p_delete_flag out char, 
        p_updated_at  out timestamp,
        p_transfer_flag  out char,
        p_error_flag out varchar2,
        p_error_code out varchar2,
        p_error_message out varchar2
    )
    is
    begin
        SELECT 
            bank_name,         cash_flag,         change_flag,         delete_flag,         updated_at
        INTO 
            p_bank_name, 
            p_cash_flag, 
            p_change_flag, 
            p_delete_flag, 
            p_updated_at
        FROM BANK_CODES
        WHERE bank_code = p_bank_code;

          p_transfer_flag := 1;
        UPDATE BANK_CODES SET transfer_flag = 1 WHERE bank_code = p_bank_code;
        COMMIT;

        EXCEPTION
            WHEN OTHERS THEN
             p_error_code := SQLCODE;
             p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
             p_error_flag := 'S';


     end sp_transfer_bank_codes_dms;


    FUNCTION fn_transfer_pending_codes_dms
    (	p_bank_codes_tbl out PCK_BANK_CODES.bank_codes_tbl,
        p_error_flag out varchar2,
        p_error_code out varchar2,
        p_error_message out varchar2
    ) 
    RETURN PCK_BANK_CODES.bank_codes_tbl 
    IS
    BEGIN

        SELECT *
          BULK COLLECT INTO p_bank_codes_tbl
          FROM bank_codes
         WHERE TRANSFER_FLAG = 'F' AND CHANGE_FLAG = 'T';

      RETURN p_bank_codes_tbl;
    END; 

END PCK_BANK_CODES;
/

