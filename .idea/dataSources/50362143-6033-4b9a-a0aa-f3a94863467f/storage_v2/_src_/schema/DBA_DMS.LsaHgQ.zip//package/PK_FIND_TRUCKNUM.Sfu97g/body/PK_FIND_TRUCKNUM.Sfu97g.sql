create PACKAGE BODY         PK_FIND_TRUCKNUM
AS
    FUNCTION FN_FIND_TRUCK (V_ZONA       IN VARCHAR2,
                            V_CAMPAIGN      NUMBER,
                            V_CAMPYEAR      NUMBER)
        RETURN VARCHAR2
    IS
        V_TRUCK_NUMBER_CATS   VARCHAR2 (10);
        V_RET_TRUCNUM_CATS    NUMBER (10) := 0;
        V_ONE                 VARCHAR2 (4) := 1;
    BEGIN
          SELECT MAX (COUNT (*))
            INTO V_RET_TRUCNUM_CATS --- BUSCA EL REGISTRO CON EL MAYOR VOLUMEN
            FROM MANIFEST@CATS
           WHERE     ZONE = V_ZONA
                 AND CAMPAIGN = V_CAMPAIGN
                 AND CAMPYEAR = V_CAMPYEAR
        GROUP BY trucknumber, zone;


          SELECT trucknumber
            INTO V_TRUCK_NUMBER_CATS --- BUSCA EL REGISTRO CON EL MAYOR VOLUMEN
            FROM MANIFEST@CATS
           WHERE     ZONE = V_ZONA
                 AND CAMPAIGN = V_CAMPAIGN
                 AND CAMPYEAR = V_CAMPYEAR
                 AND ROWNUM = V_ONE
        GROUP BY trucknumber;

        RETURN V_TRUCK_NUMBER_CATS;
    END FN_FIND_TRUCK;

    FUNCTION FN_TRUCK_ZONES (V_TRUCKNUMBER   IN VARCHAR2,
                             V_CAMPAIGN         NUMBER,
                             V_CAMPYEAR         NUMBER)
        RETURN NUMBER
    IS
        V_ZONE   NUMBER (10) := 0;
    BEGIN
          SELECT COUNT (DISTINCT (ZONE))
            INTO V_ZONE                                    --- BUSCA LAS ZONAS
            FROM MANIFEST@CATS
           WHERE     CAMPAIGN = V_CAMPAIGN
                 AND CAMPYEAR = V_CAMPYEAR
                 AND TRUCKNUMBER = V_TRUCKNUMBER
        GROUP BY trucknumber;

        RETURN V_ZONE;
    
    END FN_TRUCK_ZONES;


    FUNCTION FN_TRUCK_ORDERS (V_TRUCKNUMBER   IN VARCHAR2,
                              V_ZONE             NUMBER,
                              V_CAMPAIGN         NUMBER,
                              V_CAMPYEAR         NUMBER)
        RETURN NUMBER
    IS
        VL_ORDERS   NUMBER (10) := 0;
    BEGIN
          SELECT COUNT (DISTINCT (ordernum))
            INTO VL_ORDERS                                 --- BUSCA LAS ORDER
            FROM MANIFEST@CATS
           WHERE     ZONE = V_ZONE
                 AND CAMPAIGN = V_CAMPAIGN
                 AND CAMPYEAR = V_CAMPYEAR
                 AND TRUCKNUMBER = V_TRUCKNUMBER
        GROUP BY trucknumber, zone;

        RETURN VL_ORDERS;
    END FN_TRUCK_ORDERS;


    FUNCTION FN_TOTAL_BOXES (V_TRUCKNUMBER   IN VARCHAR2,
                             V_CAMPAIGN         NUMBER,
                             V_CAMPYEAR         NUMBER)
        RETURN NUMBER
    IS
        VL_TOTAL_BOXES   NUMBER (10) := 0;
    BEGIN
          SELECT COUNT (*)
            INTO VL_TOTAL_BOXES                            --- BUSCA LAS ORDER
            FROM MANIFEST@CATS
           WHERE     CAMPAIGN = V_CAMPAIGN
                 AND CAMPYEAR = V_CAMPYEAR
                 AND TRUCKNUMBER = V_TRUCKNUMBER
        GROUP BY trucknumber, CAMPAIGN, CAMPYEAR;

        RETURN VL_TOTAL_BOXES;
    END FN_TOTAL_BOXES;
    
   PROCEDURE         SP_SELECT_TRUCKNUMBER
/******************************************************************************
   NAME:       SP_SELECT_TRUCKNUMBER
   PURPOSE:    SELECCIONA LOS TRUCKNUMBER DE CATS EN LA CAMPAÑA ENVÍADA
******************************************************************************/

   (
                            P_FULLCAMPAIGN    IN  NUMBER,
    PA_CURSOR OUT SYS_REFCURSOR ) AS
    V_CAMPAIGN      NUMBER := SUBSTR(P_FULLCAMPAIGN, 5,2);
    V_CAMPYEAR      NUMBER := SUBSTR(P_FULLCAMPAIGN, 0,4);
    V_COUNT        NUMBER := 0;
  BEGIN
   SELECT COUNT(TRUCKNUMBER) INTO V_COUNT
            FROM MANIFEST@CATS
           WHERE   CAMPAIGN = V_CAMPAIGN
                 AND CAMPYEAR = V_CAMPYEAR;
                 IF V_COUNT >0
                 THEN 
  
  OPEN PA_CURSOR FOR
        SELECT DISTINCT(TRUCKNUMBER) AS TRUCKNUMBER
            FROM MANIFEST@CATS
           WHERE   CAMPAIGN = V_CAMPAIGN
                 AND CAMPYEAR = V_CAMPYEAR;
        COMMIT;
     ELSE 
      OPEN PA_CURSOR FOR
        SELECT 'NO EXISTEN DATOS' AS TRUCKNUMBER FROM DUAL;
        END IF;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN 
        OPEN PA_CURSOR FOR
        SELECT 'NO EXISTEN DATOS' AS TRUCKNUMBER FROM DUAL;
       WHEN OTHERS THEN
        OPEN PA_CURSOR FOR
        SELECT 'ERROR INESPERADO' AS TRUCKNUMBER FROM DUAL;
       ROLLBACK;
  END SP_SELECT_TRUCKNUMBER;
  
  
   FUNCTION FN_TRUCK_ZONE_C (V_TRUCKNUMBER   IN VARCHAR2,
                              V_ZONE             NUMBER,
                              V_CAMPAIGN         NUMBER,
                              V_CAMPYEAR         NUMBER)
        RETURN NUMBER
    IS
        VL_COUNT  NUMBER (10) := 0;
        VL_EXIST  NUMBER (10) := 0;
        
    BEGIN
          SELECT COUNT (DISTINCT (ordernum))
            INTO VL_COUNT                                 --- BUSCA LA ZONA Y CAMIÓN
            FROM MANIFEST@CATS
           WHERE     ZONE = V_ZONE
                 AND CAMPAIGN = V_CAMPAIGN
                 AND CAMPYEAR = V_CAMPYEAR
                 AND TRUCKNUMBER = V_TRUCKNUMBER
        GROUP BY trucknumber, zone;
        IF VL_COUNT >0
        THEN 
        VL_EXIST := 1;
        ELSE 
        VL_EXIST := 0;
        END IF;
      RETURN VL_EXIST;
         EXCEPTION
        WHEN NO_DATA_FOUND THEN RETURN  VL_EXIST ;

       WHEN OTHERS THEN
       RETURN  VL_EXIST ;
    END FN_TRUCK_ZONE_C;
END PK_FIND_TRUCKNUM;
/

