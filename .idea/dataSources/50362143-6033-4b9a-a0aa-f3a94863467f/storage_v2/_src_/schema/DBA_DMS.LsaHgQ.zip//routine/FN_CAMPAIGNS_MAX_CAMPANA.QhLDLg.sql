create Function FN_CAMPAIGNS_MAX_CAMPAÑA
(año in NUMBER)
   RETURN number
IS
   campaña number;

BEGIN
    SELECT MAX(CAMPAIGN) INTO campaña 
    FROM CAMPAIGNS 
    WHERE CAMPAIGN_YEAR = año
    GROUP BY CAMPAIGN_YEAR; 
RETURN campaña;
END;
/

