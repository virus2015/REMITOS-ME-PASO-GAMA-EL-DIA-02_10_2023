create PROCEDURE SP_REMITO_VALORES (
   pi_Valor                  IN     NUMBER,
   pi_campana                IN     NUMBER,
   po_lcd                       OUT VARCHAR2,
   po_poblacion_lcd             OUT VARCHAR2,
   po_zona                      OUT NUMBER,
   po_ruta                      OUT NUMBER,
   po_rfc                       OUT VARCHAR2,
   po_account                   OUT NUMBER,
   po_nombre                    OUT VARCHAR2,
   po_domicilio                 OUT VARCHAR2,
   po_cp                        OUT NUMBER,
   po_municipio                 OUT VARCHAR2,
   po_estado                    OUT VARCHAR2,
   po_pais                      OUT VARCHAR2,
   po_codigo_sat                OUT NUMBER,
   po_descripcion               OUT VARCHAR2,
   po_cantidad_recolectar       OUT NUMBER,
   po_efectivo_recolectado      OUT NUMBER,
   po_clave_unidad_medida       OUT VARCHAR2,
   po_unidad_medida             OUT VARCHAR2,
   po_moneda                    OUT VARCHAR2,
   po_efectivo_pagado           OUT VARCHAR2,
   po_mensaje                   OUT VARCHAR2)
IS
   /******************************************************************************
      NAME:       SP_REMITO_VALORES
      PURPOSE:   REPORTE DE VALORES PARA REMITOS

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        22/12/2021   aosa1bzg       1. Created this procedure.

      NOTES:

      Automatically available Auto Replace Keywords:
         Object Name:     SP_REMITO_VALORES
         Sysdate:         22/12/2021
         Date and Time:   22/12/2021, 03:10:44 p. m., and 22/12/2021 03:10:44 p. m.
         Username:        aosa1bzg (set in TOAD Options, Procedure Editor)
         Table Name:       (set in the "New PL/SQL Object" dialog)

   ******************************************************************************/
   vSentencia                VARCHAR2 (2000);

   TYPE i_cursor_type IS REF CURSOR;

   my_cursor                 i_cursor_type;

   PO_LCD                    VARCHAR2 (32767);
   PO_POBLACION_LCD          VARCHAR2 (32767);
   PO_ZONA                   NUMBER;
   PO_RUTA                   NUMBER;
   PO_RFC                    VARCHAR2 (32767);
   PO_ACCOUNT                NUMBER;
   PO_NOMBRE                 VARCHAR2 (32767);
   PO_DOMICILIO              VARCHAR2 (32767);
   PO_CP                     NUMBER;
   PO_MUNICIPIO              VARCHAR2 (32767);
   PO_ESTADO                 VARCHAR2 (32767);
   PO_PAIS                   VARCHAR2 (32767);
   PO_CODIGO_SAT             NUMBER;
   PO_DESCRIPCION            VARCHAR2 (32767);
   PO_CANTIDAD_RECOLECTAR    NUMBER;
   PO_EFECTIVO_RECOLECTADO   NUMBER;
   PO_CLAVE_UNIDAD_MEDIDA    VARCHAR2 (32767);
   PO_UNIDAD_MEDIDA          VARCHAR2 (32767);
   PO_MONEDA                 VARCHAR2 (32767);
   PO_EFECTIVO_PAGADO        VARCHAR2 (32767);
BEGIN
   vSentencia :=
         'SELECT X.LDC_ID po_lcd,'
      || 'UPPER (X.LOCATION_NAME) po_poblacion_lcd,'
      || 'RP.DEFAULT_ZONE po_zona,'
      || 'NVL (RP.ROUTE, 0) po_ruta,'
      || 'RP.RFC po_rfc,'
      || 'RP.ACCOUNT po_account,'
      || 'RP.ACCOUNT_NAME po_nombre,'
      || 'NVL (RP.ADDRESS1, ''-'') || '' '' || NVL (RP.ADDRESS2, ''-'') po_domicilio,'
      || 'RP.ZIP po_cp,'
      || 'NVL (RP.MUNICIPALITY, ''-'') po_municipio,'
      || 'RP.STATE_NAME po_estado,'
      || '''MÉXICO'' po_pais,'
      || 'RE.TAX_CATEGORY po_codigo_sat,'
      || 'RE.DESCRIPTION po_descripcion,'
      || 'OD.CURRENT_AMOUNT po_cantidad_recolectar,'
      || 'OD.PAYMENT_VALUE po_efectivo_recolectado,'
      || '''H87'' po_clave_unidad_medida,'
      || '''PZA'' po_unidad_medida,'
      || '''MX'' po_moneda'
      || ' FROM SCPI_ORDER_HEADERS SO,'
      || 'REMITO RE,'
      || 'DBA_SCPI.REMITO_HEADER RH,'
      || 'ORDERS OD,'
      || 'REPRESENTATIVES RP,'
      || 'DBA_DMS.LDC X,'
      || 'DBA_DMS.ZONE_CAMPAIGNS Z'
      || ' WHERE RH.ID_REMITO_HEADER = RE.ID_REMITO_HEADER'
      || ' AND RH.ACCOUNT = RP.ACCOUNT'
      || ' AND SO.ACCOUNT = RP.ACCOUNT'
      || ' AND SO.ORDER_ID = OD.ORDER_ID'
      || ' AND SO.FULL_CAMPAIGN = RE.CAMPAIGN'
      || ' AND X.LDC_ID = Z.LDW_CODE'
      || ' AND SO.ZONE = Z.ZONE'
      || ' AND SO.FULL_CAMPAIGN=TO_CHAR (Z.CAMPAIGN_YEAR ||LPAD( Z.CAMPAIGN,2,0))';

   --|| ' AND RH.ACCOUNT = ''3128778''';


   IF pi_campana IS NOT NULL
   THEN
      IF pi_Valor = 1
      THEN                                            --- EFECTIVO RECOLECTADO
         vSentencia :=
               vSentencia
            || ' AND SO.FULL_CAMPAIGN = '
            || pi_campana
            || ' AND OD.PAYMENT_VALUE > 0; ';
         po_efectivo_pagado := 'SI';
      ELSIF pi_Valor = 0
      THEN                                           --- EFECTIVO A RECOLECTAR
         vSentencia :=
               vSentencia
            || ' AND SO.FULL_CAMPAIGN = '
            || pi_campana
            || ' AND OD.PAYMENT_VALUE <= 0; ';
         po_efectivo_pagado := 'NO';
      ELSE
         po_mensaje := 'Sin valor de Efectivo Recolectado/NoRecolectado';
      END IF;
   ELSE
      po_mensaje := 'Requiere ingresar campaña';
   END IF;

   DBMS_OUTPUT.put_line (vSentencia);

   OPEN my_cursor FOR vSentencia;

   LOOP
      FETCH my_cursor
         INTO po_lcd,
              po_poblacion_lcd,
              po_zona,
              po_ruta,
              po_rfc,
              po_account,
              po_nombre,
              po_domicilio,
              po_cp,
              po_municipio,
              po_estado,
              po_pais,
              po_codigo_sat,
              po_descripcion,
              po_cantidad_recolectar,
              po_efectivo_recolectado,
              po_clave_unidad_medida,
              po_unidad_medida,
              po_moneda;

      EXIT WHEN my_cursor%NOTFOUND;
   END LOOP;

   CLOSE my_cursor;
EXCEPTION
   WHEN OTHERS
   THEN
      po_mensaje := ('Error..' || 'CAUSA' || ' ' || SQLERRM);
END SP_REMITO_VALORES;
/

