create PROCEDURE         SP_ORDERS_TO_DMS (p_error_flag      OUT VARCHAR2,
								   
                                              p_error_code      OUT VARCHAR2,
                                              p_error_message   OUT VARCHAR2)
AS
    v_count_registers        NUMBER := 0;
    v_last_id_processed      NUMBER := 0;
    v_count_representative   NUMBER := 0;
    v_first_order            NUMBER := 0;
    c_cert_quality           NUMBER := 0;
    v_new_blocked_status     NUMBER := 0;
    v_old_blocked_status     NUMBER := 0;
    v_correct_cod_amount     NUMBER := 0;

    c_ordenes                SYS_REFCURSOR;
   -- r_orden                  DBA_SCPI.ORDER_HEADER@SCPIP%ROWTYPE;--- QA
    r_orden                  DBA_SCPI.ORDER_HEADER%ROWTYPE; --- PRODUCCIÓN

    v_anio                   NUMBER := 0;
    v_camp                   NUMBER := 0;
    v_id                     NUMBER := 0;
    v_account                NUMBER := 0;

    v_address1               VARCHAR2 (150) := NULL;
    v_address2               VARCHAR2 (150) := NULL;
    v_address3               VARCHAR2 (150) := NULL;
    v_telephone              NUMBER := 0;

    v_BILL_SEQ_ORD           NUMBER (1) := 0;
BEGIN
    p_error_flag := 'N';

    SELECT VALOR
      INTO v_count_registers
      FROM DBA_SCPI.CONFIG_ORDER_HEADER@SCPIP
     WHERE ID_CONFIG = 4;

    SELECT VALOR
      INTO v_last_id_processed
      FROM DBA_SCPI.CONFIG_ORDER_HEADER@SCPI
     WHERE ID_CONFIG = 3;

    OPEN c_ordenes FOR
          SELECT *
            FROM DBA_SCPI.ORDER_HEADER@SCPIP
            -- where    ZONE IN (2704) AND CAMPAIGN = 202313;
              --FROM DBA_SCPI.ORDER_HEADER ---- PRODUCCIÓN
         --  WHERE ID_ORDER > v_last_id_processed AND ROWNUM <= v_count_registers AND ZONE IN (2704) AND CAMPAIGN = 202313;
           WHERE  ZONE IN (2700) AND CAMPAIGN = 202314;
             
    LOOP
        FETCH c_ordenes INTO r_orden;

        EXIT WHEN c_ordenes%NOTFOUND;

        BEGIN
            v_id := r_orden.ID_ORDER;
            v_account := r_orden.ACCOUNT;
            v_anio := SUBSTR (r_orden.CAMPAIGN, 0, 4);
            v_camp := SUBSTR (r_orden.CAMPAIGN, 5, 6);
        EXCEPTION
            WHEN OTHERS
            THEN
                CONTINUE;
        END;

        v_address1 := NULL;
        v_address2 := NULL;
        v_address3 := NULL;
        v_telephone := 0;
        v_BILL_SEQ_ORD := r_orden.BILL_SEQ_ORD;

        BEGIN
            --VALIDA SI EL ESTATUS DE LA ORDEN ES CORRECTA
            IF (r_orden.PROCESS_STATUS != 11 OR r_orden.ORDER_STATUS != 2)
            THEN
                INSERT INTO SCPI_ORDERS_REPROCESS (ORDER_ID)
                     VALUES (r_orden.ID_ORDER);

                COMMIT;
                CONTINUE;
            END IF;

            --valida si ya existe la representante ligada a la orden
            SELECT COUNT (*)
              INTO v_count_representative
              FROM DBA_DMS.REPRESENTATIVES
             WHERE ACCOUNT = r_orden.ACCOUNT;

            IF (v_count_representative = 0 OR v_count_representative IS NULL)
            THEN
                --Si no existe la inserta en la tabla REPRESENTATIVES
                DBMS_OUTPUT.PUT_LINE ('INSERTA REPRE');

                INSERT INTO REPRESENTATIVES (ACCOUNT,
                                             ACCOUNT_NAME,
                                             ADDRESS1,
                                             ADDRESS2,
                                             ADDRESS3,
                                             STATE_CODE,
                                             CHANGE_FLAG,
                                             DELETE_FLAG,
                                             TELEPHONE,
                                             ZIP,
                                             PARENT_ACCOUNT,
                                             UPDATED_AT,
                                             LOS,
                                             LOA,
                                             ROUTE,
                                             LAST_DELIVER_ORDER,
                                             STATE_NAME,
                                             DEFAULT_ZONE,
                                             REP_STATUS,
                                             SECTION)
                     VALUES (TO_NUMBER (r_orden.ACCOUNT),
                             r_orden.ACC_NAME,
                             r_orden.ADDRESS1,
                             r_orden.ADDRESS2,
                             r_orden.ADDRESS3,
                             r_orden.STATE_CODE,
                             'F',
                             'F',
                             r_orden.TELEPHONE,
                             r_orden.ZIP,
                             0,
                             SYSDATE,
                             r_orden.LENGTH_SERVICE,
                             r_orden.LENGTH_ASSOC,
                             TO_NUMBER (SUBSTR (r_orden.CARRIER_CODE, 1, 3)),
                             TO_NUMBER (SUBSTR (r_orden.CARRIER_CODE, 5, 3)),
                             SUBSTR (r_orden.STATE_NAME, 5),
                             r_orden.ZONE,
                             'A',
                             TO_NUMBER (SUBSTR (r_orden.ROUTE_CODE, 2, 2)));

                v_address1 := r_orden.ADDRESS1;
                v_address2 := r_orden.ADDRESS2;
                v_address3 := r_orden.ADDRESS1;
                v_telephone := r_orden.TELEPHONE;
            ELSE
                UPDATE REPRESENTATIVES
                   SET LOS = r_orden.LENGTH_SERVICE,
                       LOA = r_orden.LENGTH_ASSOC,
                       DEFAULT_ZONE = r_orden.ZONE,
                       SECTION =
                           TO_NUMBER (SUBSTR (r_orden.ROUTE_CODE, 2, 2))
                 WHERE ACCOUNT = r_orden.ACCOUNT;

                SELECT ADDRESS1 || ' ' || ADDRESS2    AS ADD1,
                       ADDRESS3                       AS ADD2,
                       MUNICIPALITY                   AS ADD3,
                       CASE
                           WHEN (TELEPHONE IS NOT NULL AND TRIM(TELEPHONE) != 0)
                           THEN
                               TELEPHONE
                           ELSE
                               NVL (CELLPHONE, 0)
                       END                            AS TEL
                  INTO v_address1,
                       v_address2,
                       v_address3,
                       v_telephone
                  FROM DBA_DMS.REPRESENTATIVES
                 WHERE ACCOUNT = r_orden.ACCOUNT;
            END IF;

            IF r_orden.CARRIER_CODE IN ('000-022', '000-011')
            THEN
                UPDATE REPRESENTATIVES
                   SET ROUTE =
                           TO_NUMBER (SUBSTR (r_orden.CARRIER_CODE, 1, 3)),
                       LAST_DELIVER_ORDER =
                           TO_NUMBER (SUBSTR (r_orden.CARRIER_CODE, 5, 3)),
                       UPDATED_AT = CURRENT_TIMESTAMP
                 WHERE ACCOUNT = r_orden.ACCOUNT;
            END IF;

            --Valida si es primera orden, lo indica la bandera S en el campo FIST_ORDER
            IF (   (r_orden.FIRST_ORDER = 'S' AND r_orden.COD_AMOUNT = 0)
                OR r_orden.LENGTH_ASSOC = 0)
            THEN
                v_first_order := 1;

                UPDATE REPRESENTATIVES
                   SET ROUTE = 0, LAST_DELIVER_ORDER = 0
                 WHERE ACCOUNT = r_orden.ACCOUNT;

                v_new_blocked_status := 0;
            ELSE
                v_first_order := 0;

                BEGIN
                       SELECT BLOCKED_STATUS
                      INTO v_old_blocked_status
                      FROM (  SELECT BLOCKED_STATUS
                                FROM DBA_DMS.SCPI_ORDER_HEADERS OH
                                     INNER JOIN DBA_DMS.ORDERS O
                                         ON O.ORDER_ID = OH.ORDER_ID
                               WHERE     ACCOUNT = r_orden.ACCOUNT
                                     AND FULL_CAMPAIGN < r_orden.CAMPAIGN
                            ORDER BY FULL_CAMPAIGN DESC)
                     WHERE ROWNUM = 1;

                EXCEPTION
                    WHEN NO_DATA_FOUND
                    THEN
                        v_old_blocked_status := 0;
                END;

                IF (r_orden.COD_AMOUNT < 50)
                THEN
                    v_new_blocked_status := 0;
                ELSE
                    IF (v_old_blocked_status = 3)
                    THEN
                        v_new_blocked_status := (-99);
                    ELSE
                        v_new_blocked_status := v_old_blocked_status;
                    END IF;
                END IF;
            END IF;

            IF (r_orden.COD_AMOUNT < 0)
            THEN
                v_correct_cod_amount := 0;
            ELSE
                v_correct_cod_amount := r_orden.COD_AMOUNT;
            END IF;

            SELECT COUNT (*)
              INTO c_cert_quality

              FROM ACCFLAG@CATS
             WHERE     ACCOUNT = r_orden.ACCOUNT
                   AND CAMPAIGN = v_camp
                   AND CAMPYEAR = v_anio;
     INSERT INTO SCPI_ORDER_HEADERS (ORDER_ID,
                                                ORDER_NUMBER,
                                                ACCOUNT,
                                                ORDER_DATE,
                                                FULL_CAMPAIGN,
                                                ZONE,
                                                ACC_NAME,
                                                TELEPHONE,
                                                EMAIL,
                                                ADDRESS1,
                                                ADDRESS2,
                                                ADDRESS3,
                                                STATE_NAME,
                                                ZIP,
                                                NUMBER_BOXES,
                                                COD_AMOUNT,
                                                ORD_AMOUNT,
                                                FIRST_ORDER,
                                                MULTIPLE_ORDER,
                                                CERTIFIED_QUALITY,
                                                COD,
                                                CREDIT_CHECK)
                         VALUES (
                                    r_orden.ID_ORDER,
                                    r_orden.ORDER_NUMBER,
                                    TO_NUMBER (r_orden.ACCOUNT),
                                    r_orden.ORDER_DATE,
                                    r_orden.CAMPAIGN,
                                    r_orden.ZONE,
                                    r_orden.ACC_NAME,
                                    v_telephone,
                                    r_orden.EMAIL,
                                    v_address1,
                                    v_address2,
                                    v_address3,
                                    SUBSTR (r_orden.STATE_NAME, 5),
                                    r_orden.ZIP,
                                    r_orden.NUMBER_BOXES,
                                    v_correct_cod_amount,
                                    r_orden.ORD_AMOUNT,
                                    v_first_order,
                                    0,
                                    c_cert_quality,
                                    r_orden.COD,
                                   -- '#COD1'|| SUBSTR( r_orden.ORDER_NUMBER,0,4),
                                    CASE
                                        WHEN r_orden.CREDI_CHECK = 0
                                        THEN
                                            NULL
                                        ELSE
                                            r_orden.CREDI_CHECK
                                    END);


            INSERT INTO DBA_DMS.ORDERS (ORDER_ID,
                                CURRENT_AMOUNT,
                                PREVIOUS_AMOUNT,
                                PICK_UP_POINT_ID,
                                ROUTE,
                                DELIVER_ORDER,
                                BLOCKED_STATUS)
                 VALUES (r_orden.ID_ORDER,
                         v_correct_cod_amount,
                         0,
                         RTRIM (r_orden.ORDER_PUP),
                         TO_NUMBER (SUBSTR (r_orden.CARRIER_CODE, 1, 3)),
                         TO_NUMBER (SUBSTR (r_orden.CARRIER_CODE, 5, 3)),
                         v_new_blocked_status);

            INSERT INTO DBA_DMS.ORDERS_STATUSES
                 VALUES (r_orden.ID_ORDER, SYSDATE, 1);

            ---- inserta tipo de orden principal y complementaria
            INSERT INTO DBA_DMS.ORDERS_INPUT_SEQUENCE (ORDER_ID, ORDER_TYPE)

                 VALUES (r_orden.ID_ORDER, v_BILL_SEQ_ORD);

              IF r_orden.CREDI_CHECK > 0
                THEN
                    --- INSERTA EN CREDIT CHECK
                    INSERT INTO DBA_DMS.CREDIT_CHECK (ORDER_ID,
                                                      FULL_CAMPAIGN,
                                                      ZONE_ID,
                                                      ACCOUNT,
                                                      SECTION,
                                                      LOA)
                             VALUES (
                                        r_orden.ID_ORDER,
                                        r_orden.CAMPAIGN,
                                        r_orden.ZONE,
                                        TO_NUMBER (r_orden.ACCOUNT),
                                        TO_NUMBER (
                                            SUBSTR (r_orden.ROUTE_CODE, 2, 2)),
                                        r_orden.LENGTH_ASSOC);

                END IF;
                COMMIT;
                --- inserta simpli entrega
                DBA_DMS.PCK_SIMPLI_DELIVERY.SP_INS_ORDER_SIMPLI_DELIVERY (
                    r_orden.ID_ORDER,
                    r_orden.ZONE,
                    r_orden.ACCOUNT,
                    r_orden.CAMPAIGN);

        EXCEPTION
            WHEN OTHERS
            THEN
                INSERT INTO DBA_DMS.SCPI_ORDERS_REPROCESS (ORDER_ID)
                     VALUES (v_id);

                IF (p_error_flag = 'N')
                THEN
                    p_error_message :=
                           'ORDEN: '
                        || v_id
                        || ' - CUENTA: '
                        || v_account
                        || ' - Error: '
                        || SQLERRM;
                ELSE
                    p_error_message :=
                        CONCAT (
                            p_error_message,
                               '\n ORDEN: '
                            || v_id
                            || ' - CUENTA: '
                            || v_account
                            || ' - Error: '
                            || SQLERRM);
                END IF;

                p_error_flag := 'OE';
                ROLLBACK;
        END;
    END LOOP;

    CLOSE c_ordenes;

    IF (v_id > v_last_id_processed)
    THEN
        DBMS_OUTPUT.PUT_LINE (v_id);

        UPDATE DBA_SCPI.CONFIG_ORDER_HEADER
         SET VALOR = v_id
          WHERE ID_CONFIG = 3;

        COMMIT;
    END IF;
EXCEPTION
    WHEN OTHERS
    THEN
        p_error_code := SQLCODE;
        p_error_message :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.format_error_backtrace ());
        p_error_flag := 'S';
END SP_ORDERS_TO_DMS;
/

