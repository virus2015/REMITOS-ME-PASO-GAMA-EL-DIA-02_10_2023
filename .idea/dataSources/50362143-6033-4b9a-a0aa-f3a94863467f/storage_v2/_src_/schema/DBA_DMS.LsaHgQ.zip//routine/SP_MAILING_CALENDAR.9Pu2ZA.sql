create PROCEDURE         SP_MAILING_CALENDAR (
        DAYS_BEFORE IN NUMBER,
        P_ERROR_flag out varchar2,
        P_ERROR_code out varchar2,
        P_ERROR_message out varchar2
) IS
    
    ---------------Query SCPI-------------------------------------------------
											
	BILLINGDATEMINMAXCAMPAIGNQUERY	VARCHAR2(1000) := 'SELECT MIN(BILLINGDATE),MAX(BILLINGDATE)
											FROM DBA_SCPI.MAILING_CALENDAR@SCPIP
											WHERE YEAR = :YEAR AND CAMPAIGN = :CAMPAIGN';
											
    BILLINGNULLQUERY	VARCHAR2(1000) := 'SELECT COUNT(*)
											FROM DBA_SCPI.MAILING_CALENDAR@SCPIP
											WHERE YEAR = :YEAR AND CAMPAIGN = :CAMPAIGN  AND BILLINGDATE IS NULL';


  ---------------Query DMS CAMPAIGNS-------------------------------------------

	CAMPAIGNSQUERY					VARCHAR2(1000) := 'SELECT * FROM CAMPAIGNS
											WHERE CAMPAIGN_YEAR = :YEAR AND CAMPAIGN = :CAMPAIGN';
									
    INSERTCAMPAIGNQUERY     		VARCHAR2(1000) := 'INSERT INTO CAMPAIGNS 
											(CAMPAIGN_YEAR, CAMPAIGN, START_DATE, END_DATE, CHANGE_FLAG, UPDATED_AT )
											VALUES(:YEAR, :CAMPAIGN, :BILLINGDATE_MIN, :BILLINGDATE_MAX, :CHANGE_FLAG, CURRENT_TIMESTAMP)';

	UPDATECAMPAIGNQUERY     		VARCHAR2(1000) := 'UPDATE CAMPAIGNS 
										SET START_DATE = :BILLINGDATE_MIN, END_DATE = :BILLINGDATE_MAX, UPDATED_AT = CURRENT_TIMESTAMP, CHANGE_FLAG = :CHANGE_FLAG
										WHERE CAMPAIGN_YEAR = :YEAR AND CAMPAIGN = :CAMPAIGN';
										
  ---------------Query DMS MAILS----------------------------------------------

    
	MAILSQUERY						VARCHAR2(1000) := 'SELECT * FROM MAILS
											WHERE CAMPAIGN_YEAR = :YEAR AND CAMPAIGN = :CAMPAIGN AND MAIL_ID = :MAIL';
											
	INSERTMAILSQUERY     			VARCHAR2(1000) := 'INSERT INTO MAILS 
										(MAIL_ID, CAMPAIGN_YEAR, CAMPAIGN, BILLING_DATE, CHANGE_FLAG )
										VALUES(:MAIL, :YEAR, :CAMPAIGN, :BILLINGDATE, :CHANGE_FLAG)';

	UPDATEMAILSQUERY     			VARCHAR2(1000) := 'UPDATE MAILS 
										SET  BILLING_DATE= :BILLINGDATE, CHANGE_FLAG = :CHANGE_FLAG
										WHERE CAMPAIGN_YEAR = :YEAR AND CAMPAIGN = :CAMPAIGN AND MAIL_ID = :MAIL';
										
    CHANGE_FLAG_DEFAULT 			CAMPAIGNS.CHANGE_FLAG%TYPE := 'T' ;

	EXISTSCAMPAIGN       			BOOLEAN := TRUE;

	EXISTSMAIL      				BOOLEAN := TRUE;
			
	BILLINGDATEMIN					DBA_SCPI.MAILING_CALENDAR.BILLINGDATE@SCPIP%TYPE;

	BILLINGDATEMAX					DBA_SCPI.MAILING_CALENDAR.BILLINGDATE@SCPIP%TYPE;

    R_CAMPAIGNS                     CAMPAIGNS%ROWTYPE;
    
    R_MAILS                         MAILS%ROWTYPE;

    TRACINGRECORD				    VARCHAR2(512);
    
    COUNT_NULL                      NUMBER;

    CURSOR C_YEARCAMPAIGN IS 
            SELECT DISTINCT YEAR,CAMPAIGN
            FROM DBA_SCPI.MAILING_CALENDAR@SCPIP
            WHERE TRUNC(BILLINGDATE) >= TRUNC(SYSDATE)-DAYS_BEFORE ORDER BY YEAR,CAMPAIGN;




    CURSOR C_MAIL(pYEAR IN DBA_SCPI.MAILING_CALENDAR.YEAR@SCPIP%TYPE, pCAMPAIGN IN DBA_SCPI.MAILING_CALENDAR.CAMPAIGN@SCPIP%TYPE) IS 
            SELECT YEAR,CAMPAIGN,MAIL,BILLINGDATE
            FROM DBA_SCPI.MAILING_CALENDAR@SCPIP
            WHERE  YEAR = pYEAR AND CAMPAIGN = pCAMPAIGN
            ORDER BY YEAR,CAMPAIGN,MAIL;
									
  BEGIN
     p_error_flag := 'N';
	FOR R_YEARCAMPAIGN_CURSOR IN C_YEARCAMPAIGN
	LOOP
		IF R_YEARCAMPAIGN_CURSOR.YEAR IS NOT NULL AND R_YEARCAMPAIGN_CURSOR.CAMPAIGN IS NOT NULL THEN
		
		
            BILLINGDATEMIN  := NULL;
			BILLINGDATEMAX  := NULL;
			R_CAMPAIGNS     := NULL;
			TRACINGRECORD := NULL;
			
            --Revisar si existe alguna fecha de facturacion nula 
            EXECUTE IMMEDIATE BILLINGNULLQUERY 
			INTO              COUNT_NULL
			USING             R_YEARCAMPAIGN_CURSOR.YEAR, R_YEARCAMPAIGN_CURSOR.CAMPAIGN;
			
               
			IF COUNT_NULL = 0 THEN
                TRACINGRECORD := 'YEAR : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.YEAR) ||
                    ' CAMPAIGN : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.CAMPAIGN) ||
                    ' MIN-MAX BILLINGDATE';
                    
            
                                    
                EXECUTE IMMEDIATE BILLINGDATEMINMAXCAMPAIGNQUERY 
                INTO              BILLINGDATEMIN, BILLINGDATEMAX
                USING             R_YEARCAMPAIGN_CURSOR.YEAR, R_YEARCAMPAIGN_CURSOR.CAMPAIGN;
            

                --VALIDAMOS QUE LAS FECHAS NO SEAN NULAS
                IF BILLINGDATEMIN IS NOT NULL AND BILLINGDATEMAX IS NOT NULL THEN

                    BEGIN 
                        TRACINGRECORD := 'YEAR : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.YEAR) ||
                            ' CAMPAIGN : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.CAMPAIGN) ||
                            ' FROM CAMPAIGNS';
                        EXECUTE IMMEDIATE CAMPAIGNSQUERY 
                        INTO              R_CAMPAIGNS
                        USING             R_YEARCAMPAIGN_CURSOR.YEAR, R_YEARCAMPAIGN_CURSOR.CAMPAIGN;
                        EXISTSCAMPAIGN := TRUE;
                    EXCEPTION 
                       WHEN NO_DATA_FOUND THEN 
                            EXISTSCAMPAIGN := FALSE; 
                    END;
                
                
                    IF EXISTSCAMPAIGN = TRUE THEN
                        --VALIDAMOS QUE LAS FECHAS DE SCPI SEAN DIFERENTES A LAS ALMACENADAS EN DMS
                        IF BILLINGDATEMIN <> R_CAMPAIGNS.START_DATE OR BILLINGDATEMAX <> R_CAMPAIGNS.END_DATE THEN
                        
                            DBMS_OUTPUT.PUT_LINE('UPDATE CAMPAIGN CAMPAIGN_YEAR: ' || R_YEARCAMPAIGN_CURSOR.YEAR ||
                                    ' CAMPAIGN: ' || R_YEARCAMPAIGN_CURSOR.CAMPAIGN ||
                                    ' START_DATE: ' || BILLINGDATEMIN ||
                                    ' END_DATE: ' || BILLINGDATEMAX );



                            TRACINGRECORD := 'YEAR : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.YEAR) ||
                                ' CAMPAIGN : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.CAMPAIGN) ||
                                ' UPDATE CAMPAIGN';
                                
                            EXECUTE IMMEDIATE UPDATECAMPAIGNQUERY
                            USING  BILLINGDATEMIN, BILLINGDATEMAX, CHANGE_FLAG_DEFAULT, R_YEARCAMPAIGN_CURSOR.YEAR, R_YEARCAMPAIGN_CURSOR.CAMPAIGN;										
                        END IF;
                    ELSE
                    
                        DBMS_OUTPUT.PUT_LINE('INSERT CAMPAIGN CAMPAIGN_YEAR: ' || R_YEARCAMPAIGN_CURSOR.YEAR ||
                                    ' CAMPAIGN: ' || R_YEARCAMPAIGN_CURSOR.CAMPAIGN ||
                                    ' START_DATE: ' || BILLINGDATEMIN ||
                                    ' END_DATE: ' || BILLINGDATEMAX );
                                    
                        TRACINGRECORD := 'YEAR : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.YEAR) ||
                                ' CAMPAIGN : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.CAMPAIGN) ||
                                ' INSERT CAMPAIGN';
                                
                        EXECUTE IMMEDIATE INSERTCAMPAIGNQUERY
                        USING  R_YEARCAMPAIGN_CURSOR.YEAR, R_YEARCAMPAIGN_CURSOR.CAMPAIGN,BILLINGDATEMIN,BILLINGDATEMAX,CHANGE_FLAG_DEFAULT;
                        
                    END IF;
                
                

                    -- <UPDATE_MAILS>
                    FOR R_MAIL_CURSOR IN C_MAIL(R_YEARCAMPAIGN_CURSOR.YEAR,R_YEARCAMPAIGN_CURSOR.CAMPAIGN)
                    LOOP
                        IF R_MAIL_CURSOR.MAIL IS NOT NULL AND  R_MAIL_CURSOR.BILLINGDATE IS NOT NULL THEN

                            R_MAILS     := NULL;
                            EXISTSMAIL := TRUE;
                            
                            BEGIN 
                                TRACINGRECORD := 'YEAR : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.YEAR) ||
                                    ' CAMPAIGN : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.CAMPAIGN) ||
                                    ' FROM MAILS';
                                EXECUTE IMMEDIATE MAILSQUERY 
                                INTO              R_MAILS
                                USING             R_MAIL_CURSOR.YEAR, R_MAIL_CURSOR.CAMPAIGN, R_MAIL_CURSOR.MAIL;
                            EXCEPTION 
                               WHEN NO_DATA_FOUND THEN 
                                    EXISTSMAIL := FALSE; 
                            END;
                            
                            
                            IF EXISTSMAIL = TRUE THEN
                            
                                --VALIDAMOS QUE LA FECHA DEL MAIL DE SCPI SEA DIFERENTES A LA ALMACENADA EN DMS
                                IF R_MAIL_CURSOR.BILLINGDATE <> R_MAILS.BILLING_DATE THEN
                                  
                                    DBMS_OUTPUT.PUT_LINE('UPDATE MAIL CAMPAIGN_YEAR: ' || R_MAIL_CURSOR.YEAR ||
                                    ' CAMPAIGN: ' || R_MAIL_CURSOR.CAMPAIGN ||
                                    ' MAIL_ID: ' || R_MAIL_CURSOR.MAIL  ||
                                    ' BILLINGDATE: ' || R_MAIL_CURSOR.BILLINGDATE );
                                    
                                    
                                    TRACINGRECORD := 'YEAR : '|| TO_CHAR(R_MAIL_CURSOR.YEAR) ||
                                    ' CAMPAIGN : '|| TO_CHAR(R_MAIL_CURSOR.CAMPAIGN) ||
                                    ' MAIL : '|| R_MAIL_CURSOR.MAIL ||
                                    ' UPDATE MAILS';       
                                    
                                    EXECUTE IMMEDIATE UPDATEMAILSQUERY
                                    USING  R_MAIL_CURSOR.BILLINGDATE, CHANGE_FLAG_DEFAULT, R_MAIL_CURSOR.YEAR, R_MAIL_CURSOR.CAMPAIGN, R_MAIL_CURSOR.MAIL;
                                            
                                END IF;
                            ELSE
                                
                                DBMS_OUTPUT.PUT_LINE('INSERT MAIL CAMPAIGN_YEAR: ' || R_MAIL_CURSOR.YEAR ||
                                    ' CAMPAIGN: ' || R_MAIL_CURSOR.CAMPAIGN ||
                                    ' MAIL_ID: ' || R_MAIL_CURSOR.MAIL  ||
                                    ' BILLINGDATE: ' || R_MAIL_CURSOR.BILLINGDATE );
                    
                                TRACINGRECORD := 'YEAR : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.YEAR) ||
                                    ' CAMPAIGN : '|| TO_CHAR(R_YEARCAMPAIGN_CURSOR.CAMPAIGN) ||
                                    ' MAIL : '|| R_MAIL_CURSOR.MAIL ||
                                    ' INSERT MAILS';   
                                    
                                EXECUTE IMMEDIATE INSERTMAILSQUERY
                                USING R_MAIL_CURSOR.MAIL, R_MAIL_CURSOR.YEAR, R_MAIL_CURSOR.CAMPAIGN, R_MAIL_CURSOR.BILLINGDATE, CHANGE_FLAG_DEFAULT;
                                    
                            END IF;
                            
                        
                        END IF;
                    END LOOP;
                    -- </UPDATE_MAILS>
                    COMMIT;
                END IF;
            
			
			ELSE

                p_error_code := -1;
                p_error_message := 'YEAR:'||R_YEARCAMPAIGN_CURSOR.YEAR||', CAMPAIGN:'||R_YEARCAMPAIGN_CURSOR.CAMPAIGN||', FECHA DE FACTURACION CON VALOR NULO EN UNO O MAS MAILS, CAMPO BILLINGDATE DE LA TABLA MAILING_CALENDAR DE LA BASE DE DATOS SCPI'; 
                p_error_flag := 'Y';
                --break;
            END IF;
		END IF;
	END LOOP;
  
EXCEPTION
  WHEN OTHERS THEN
    /*RAISE_APPLICATION_ERROR(-20001, 'Error al llenar el catalogo de campaigns y mail: '               || TRACINGRECORD || 
                                            '. '                                                      || SQLCODE              || 
                                            ': '                                                      || SQLERRM              ||
                                            ' - '                                                     || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    */
    ROLLBACK;
	p_error_code := SQLCODE;
    p_error_message := concat( concat( SQLERRM, '  '), DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() ); 
    p_error_flag := 'Y';
END SP_MAILING_CALENDAR;
/

