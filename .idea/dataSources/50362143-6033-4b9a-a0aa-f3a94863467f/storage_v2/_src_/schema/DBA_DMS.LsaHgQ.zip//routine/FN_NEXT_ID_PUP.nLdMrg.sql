create FUNCTION         FN_NEXT_ID_PUP (P_PROVIDER VARCHAR2--- NOMBRE DEL PROVEERDOR
		)
	RETURN VARCHAR2
/******************************************************************************
NAME:       DBA_DMS.FN_PREVIOUS_CAMPAIGN
PURPOSE:   Obtener la campaña anterior en base al numero de campaña que se desea retroceder y la campaña recibida
REVISIONS:
 Ver        Date        Author           Description
---------  ----------  ---------------  ------------------------------------
1.0        05/11/2021   ROSSANA REYES  1. Created this procedure.

Object Name:     FN_NEXT_ID_PUP
Sysdate:         17/11/2021
Date and Time:   17/11/2021
Username:        ROSSANA REYES
Table Name:      PICKUP POINTS 

******************************************************************************/

IS 
  
	V_PROVIDER VARCHAR2 (50);
    V_SEQ    NUMBER (10)  :=0  ;
    V_ID_PUP   VARCHAR2 (10) := 'ERROR-';
BEGIN
  
CASE UPPER(P_PROVIDER)
WHEN 'ESTAFETA'
THEN
--- VALIDA LA SECUENCIA POR PROVEDOR
    V_PROVIDER := 'E';
	SELECT  PUP_ID_EST_SEQ.NEXTVAL INTO V_SEQ FROM  DUAL;

    ----***** AGREGAR NUEVA SECUENCIA CUANDO HUBIERE NUEVO PROVEEDOR  *****----
    ----**** CREATE SEQUENCE  DBA_DMS.****-----dummie  MINVALUE 1 MAXVALUE 9999999999 INCREMENT BY 1 START WITH 1 NOCACHE ORDER  NOCYCLE ;
    /*
  WHEN 'NUEVO PROVEEDOR' ---AGREGUE NUEVO PROVEEDOR Y SECUENCIA
THEN  
   V_PROVIDER := x;
  SELECT  ------.NEXTVAL INTO V_SEQ FROM  DUAL;
    */
   
ELSE
         V_PROVIDER    := 'ERROR-';---- NO EXISTE SECUENCIA Y VALIDACIÓN PARA ESTE PROVEEDOR
    END CASE;
    V_ID_PUP := V_PROVIDER||V_SEQ;
    RETURN  V_ID_PUP; 
END;
/

