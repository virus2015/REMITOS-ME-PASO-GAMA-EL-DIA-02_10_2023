create PROCEDURE SP_APPLY_ONLINE_PAYMENTS_V2 /******************************************************************************
                                                           NAME:       DBA_DMS.SP_APPLY_ONLINE_PAYMENTS_V2
                                                           PURPOSE:

                                                           REVISIONS:
                                                           Ver        Date        Author           Description
                                                           ---------  ----------  ---------------  ------------------------------------
                                                           1.0        05/11/2021   ROSSANA REYES  1. Created this procedure.

                                                              Object Name:     SP_APPLY_ONLINE_PAYMENTS_V2
                                                              Sysdate:         05/11/2021
                                                              Date and Time:   05/11/2021, 10:03:05 a. m.
                                                              Username:        ROSSANA REYES
                                                              Table Name:       ONLINE_PAYMENTS

                                                        ******************************************************************************/
                                                        (
    P_ERROR_FLAG         OUT VARCHAR2,
    P_ERROR_CODE         OUT VARCHAR2,
    P_ERROR_MESSAGE      OUT VARCHAR2,
    PAYMENTS_PROCESSED   OUT NUMBER,
    AMOUNTS_PROCESSED    OUT NUMBER)
IS
    BEFORE_ROWS_AMOUNTS    NUMBER (19) := 0;
    AFTER_ROWS_AMOUNTS     NUMBER (19) := 0;

    V_ACCOUNT              NUMBER (8) := 0;
    V_CURRENT_AMOUNT_O     NUMBER (10, 2) := 0;
    V_PAYMENT_AMOUNT       NUMBER (10) := 0;
    V_CAMPAIGN_YEAR_P      NUMBER (6) := 0;
    V_CAMPAIGN             NUMBER (2) := 0;
    V_ID_ONLINE_PAYMENTS   NUMBER (38) := 0;
    V_COUNT_ORDER          NUMBER (6)  := 0;

    CURSOR CUR_PAYMENTS
    IS
        SELECT ID,
               CAMPAIGN_YEAR,
               CAMPAIGN,
               ACCOUNT,
               PAYMENT_AMOUNT
          FROM ONLINE_PAYMENTS P
         WHERE     P.BIDS_TRANSACT = '017'        --- QUE SEAN DE TIPO ON LINE
               AND TRUNC (P.created_at) = TRUNC (SYSDATE)    --- PAGOS DEL DÍA
               AND P.updated_at IS NULL              --- NO SE HAYAN PROCESADO
                                       ;
BEGIN
    P_ERROR_FLAG := 'N';

    SELECT COUNT (*) INTO BEFORE_ROWS_AMOUNTS FROM BIDS_DUE_AMOUNTS;

    OPEN CUR_PAYMENTS;

    LOOP
        FETCH CUR_PAYMENTS
            INTO V_ID_ONLINE_PAYMENTS,
                 V_CAMPAIGN_YEAR_P,
                 V_CAMPAIGN,
                 V_ACCOUNT,
                 V_PAYMENT_AMOUNT;

        EXIT WHEN CUR_PAYMENTS%NOTFOUND;
        ---- VALIDA QUE EXISTAN ORDENES
        
        SELECT COUNT (H.ORDER_ID) INTO V_COUNT_ORDER
                      FROM SCPI_ORDER_HEADERS  H
                           INNER JOIN ORDERS_STATUSES S
                               ON S.ORDER_ID = H.ORDER_ID
                     WHERE     S.STATUS NOT IN (6       --Entregado en Reparto
                                                 , 8         -- Entrega en PUP
                                                    , 10 ---Entregado en Ventanilla
                                                        )
                           AND TRUNC (H.ORDER_DATE) > TRUNC (SYSDATE) - 9
                           AND TRUNC (H.ORDER_DATE) < TRUNC (SYSDATE) - 2 --- FECHA DE FACTURACIÓN DE AYER O HASTA 6 DÍAS
                           AND H.ACCOUNT = V_ACCOUNT;
        IF V_COUNT_ORDER > 0 THEN
        --ACTUALIZA LOS SALDOS DE LAS ORDENES
        SELECT MAX (CURRENT_AMOUNT)
          INTO V_CURRENT_AMOUNT_O
          FROM ORDERS ORDER_ID
         WHERE ORDER_ID IN
                   (SELECT DISTINCT (H.ORDER_ID)
                      FROM SCPI_ORDER_HEADERS  H
                           INNER JOIN ORDERS_STATUSES S
                               ON S.ORDER_ID = H.ORDER_ID
                     WHERE     S.STATUS NOT IN (6       --Entregado en Reparto
                                                 , 8         -- Entrega en PUP
                                                    , 10 ---Entregado en Ventanilla
                                                        )
                           AND TRUNC (H.ORDER_DATE) > TRUNC (SYSDATE) - 9
                           AND TRUNC (H.ORDER_DATE) < TRUNC (SYSDATE) - 2 --- FECHA DE FACTURACIÓN DE AYER O HASTA 6 DÍAS
                           AND H.ACCOUNT = V_ACCOUNT);   --- POR REPRESENTANTE

        UPDATE ORDERS
           SET CURRENT_AMOUNT = TRUNC (V_CURRENT_AMOUNT_O) - V_PAYMENT_AMOUNT,
               PREVIOUS_AMOUNT = V_CURRENT_AMOUNT_O,
               TRANSFER_FLAG = 'E',
               PAYMENTS_COUNT = PAYMENTS_COUNT + 1,
               UPDATED_BY = 'ONLINE PAYMENTS',
               UPDATED_AT =
                   CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City'
         WHERE     CURRENT_AMOUNT > 0             --- LA ORDEN ES MAYOR A CERO
               AND ORDER_ID IN
                       (SELECT DISTINCT (H.ORDER_ID)     --- TODAS LAS ORDENES
                          FROM SCPI_ORDER_HEADERS  H
                               INNER JOIN ORDERS_STATUSES S
                                   ON S.ORDER_ID = H.ORDER_ID
                         WHERE     S.STATUS NOT IN (6   --Entregado en Reparto
                                                     , 8     -- Entrega en PUP
                                                        , 10 ---Entregado en Ventanilla
                                                            )
                               AND TRUNC (H.ORDER_DATE) > TRUNC (SYSDATE) - 9
                               AND TRUNC (H.ORDER_DATE) < TRUNC (SYSDATE) - 2 --- FECHA DE FACTURACIÓN DE AYER O HASTA 6 DÍAS
                               AND H.ACCOUNT = V_ACCOUNT); --- POR REPRESENTANTE
                              
               ---ACTUALIZA LOS PAGOS APLICADOS
        UPDATE ONLINE_PAYMENTS
           SET APPLIED_ORDER_NUMBER =
                   (SELECT MAX (H.ORDER_ID)                --- LA ULTIMA ORDEN
                      FROM SCPI_ORDER_HEADERS  H
                           INNER JOIN ORDERS_STATUSES S
                               ON S.ORDER_ID = H.ORDER_ID
                     WHERE     S.STATUS NOT IN (6       --Entregado en Reparto
                                                 , 8         -- Entrega en PUP
                                                    , 10 ---Entregado en Ventanilla
                                                        )
                           AND TRUNC (H.ORDER_DATE) > TRUNC (SYSDATE) - 9
                           AND TRUNC (H.ORDER_DATE) < TRUNC (SYSDATE) - 2 --- FECHA DE FACTURACIÓN DE AYER O HASTA 6 DÍAS
                           AND H.ACCOUNT = V_ACCOUNT), --- ACTULIZA ORDEN POR REPRESENTANTE Y CAMPAÑA
               APPLIED_ORDER_QUANTITY = 1,
               PROCESSED_AT =
                   CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City',
         
               UPDATED_AT =
                   CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City'
         WHERE                                      --- VALIDAR REGISTRO ÚNICO
                   ACCOUNT = V_ACCOUNT
               AND CAMPAIGN_YEAR = V_CAMPAIGN_YEAR_P
               AND CAMPAIGN = V_CAMPAIGN
               AND BIDS_TRANSACT = '017'          --- QUE SEAN DE TIPO ON LINE
               AND TRUNC (created_at) = TRUNC (SYSDATE)     --- RENGO DE FECHA
               AND updated_at IS NULL                --- NO SE HAYAN PROCESADO
               AND ID = V_ID_ONLINE_PAYMENTS                        --- POR ID
                                            ;
ELSE
       --- SOLO ACTUALIZA LOS PAGOS APLICADOS
        UPDATE ONLINE_PAYMENTS
           SET APPLIED_ORDER_NUMBER =
                   (SELECT MAX (H.ORDER_ID)                --- LA ULTIMA ORDEN
                      FROM SCPI_ORDER_HEADERS  H
                           INNER JOIN ORDERS_STATUSES S
                               ON S.ORDER_ID = H.ORDER_ID
                     WHERE     S.STATUS NOT IN (6       --Entregado en Reparto
                                                 , 8         -- Entrega en PUP
                                                    , 10 ---Entregado en Ventanilla
                                                        )
                           AND TRUNC (H.ORDER_DATE) > TRUNC (SYSDATE) - 9
                           AND TRUNC (H.ORDER_DATE) < TRUNC (SYSDATE) - 2 --- FECHA DE FACTURACIÓN DE AYER O HASTA 6 DÍAS
                           AND H.ACCOUNT = V_ACCOUNT), --- ACTULIZA ORDEN POR REPRESENTANTE Y CAMPAÑA
               APPLIED_ORDER_QUANTITY = 1,
               PROCESSED_AT =
                   CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City',
              
               UPDATED_AT =
                   CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City'
         WHERE                                      --- VALIDAR REGISTRO ÚNICO
                   ACCOUNT = V_ACCOUNT
               AND CAMPAIGN_YEAR = V_CAMPAIGN_YEAR_P
               AND CAMPAIGN = V_CAMPAIGN
               AND BIDS_TRANSACT = '017'          --- QUE SEAN DE TIPO ON LINE
               AND TRUNC (created_at) = TRUNC (SYSDATE)     --- RENGO DE FECHA
               AND updated_at IS NULL                --- NO SE HAYAN PROCESADO
               AND ID = V_ID_ONLINE_PAYMENTS                        --- POR ID
                                            ;

END IF;
        
        AFTER_ROWS_AMOUNTS := SQL%ROWCOUNT;
        COMMIT;
    END LOOP;

    CLOSE CUR_PAYMENTS;

    PAYMENTS_PROCESSED := AFTER_ROWS_AMOUNTS;
    AMOUNTS_PROCESSED := AFTER_ROWS_AMOUNTS;
EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
    WHEN OTHERS
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
END SP_APPLY_ONLINE_PAYMENTS_V2;
/

