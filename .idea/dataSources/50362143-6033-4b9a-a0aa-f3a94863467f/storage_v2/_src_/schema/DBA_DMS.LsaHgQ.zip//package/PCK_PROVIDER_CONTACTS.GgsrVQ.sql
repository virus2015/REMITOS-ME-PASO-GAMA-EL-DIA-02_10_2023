create PACKAGE         PCK_PROVIDER_CONTACTS AS
/******************************************************************************
   NAME:       PCK_PROVIDER_CONTACTS
   PURPOSE:    SELECT PROVIDERS' CONTACT

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        23/03/2021  ROSSANA REYES     1. Created this package.
******************************************************************************/

  TYPE TP_CURSOR IS REF CURSOR;


END PCK_PROVIDER_CONTACTS;
/

