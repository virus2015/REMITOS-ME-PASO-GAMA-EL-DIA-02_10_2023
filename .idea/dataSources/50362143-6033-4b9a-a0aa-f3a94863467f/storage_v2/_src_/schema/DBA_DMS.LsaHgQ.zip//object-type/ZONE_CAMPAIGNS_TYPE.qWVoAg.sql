create TYPE           "ZONE_CAMPAIGNS_TYPE"                                          IS TABLE OF ZONE_CAMPAIGNS%ROWTYPE
/

