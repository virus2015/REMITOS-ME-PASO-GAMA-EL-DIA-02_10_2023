create PROCEDURE         SP_JOBS_DMS(
  p_error_flag out varchar2,
  p_error_code out varchar2,
  p_error_message out varchar2,
  C_JOBS OUT sys_refcursor
)
AS
BEGIN
  open C_JOBS for
    SELECT JH.*
    FROM JOB_HEADERS JH
    WHERE (JOB_NAME IN
           (SELECT BPR.JOB_NAME AS "JOB_NAME"
            FROM BIDS_PROCESS_REQUESTS BPR
            WHERE IN_PROCESS = 'D'
            UNION
            SELECT BRR.JOB_NAME_REVERSIONS AS "JOB_NAME"
            FROM BIDS_REVERSIONS_REQUESTS BRR
            WHERE IN_PROCESS = 'D') OR JOB_TYPE = 'RR')
      AND (JH.TRANSFER_FLAG IS NULL OR JH.TRANSFER_FLAG <> 'T')
    ORDER BY JH.PROCESSED_AT ASC;
  p_error_flag := 'N';

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := SQLCODE;
    p_error_message := concat(concat(SQLERRM, '  '), dbms_utility.format_error_backtrace());
    p_error_flag := 'S';
END;
/

