create procedure sp_ins_zone_campaigns_dms
(
 	zone          in number, 
	division      in number, 
	mail_plan     in char, 
	ldw_code      in char, 
	campaign_year in number, 
	campaign      in number, 
	change_flag   in char, 
	delete_flag   in char, 
	cedis         in char, 
	updated_at    in timestamp, 
	full_campaign in number, 
	sent_at       in timestamp, 
	billed_at     in timestamp, 
	shipped_at    in timestamp, 
	arrived_at    in timestamp, 
	first_attempt_at in timestamp, 
	last_attempt_at in timestamp, 
	on_porteo_until in timestamp,
    inserted_row out number,
    p_error_flag out varchar2,
    p_error_code out varchar2,
    p_error_message out varchar2
)
is
BEGIN
p_error_flag := 'N';

insert into ZONE_CAMPAIGNS (ZONE,DIVISION,MAIL_PLAN,LDW_CODE,CAMPAIGN_YEAR,CAMPAIGN,CHANGE_FLAG,DELETE_FLAG,CEDIS,UPDATED_AT,FULL_CAMPAIGN,SENT_AT,BILLED_AT,SHIPPED_AT,ARRIVED_AT,FIRST_ATTEMPT_AT,LAST_ATTEMPT_AT,ON_PORTEO_UNTIL) values 
(
 	zone, 
	division, 
	mail_plan, 
	ldw_code, 
	campaign_year, 
	campaign, 
	change_flag, 
	delete_flag, 
	cedis, 
	updated_at, 
	full_campaign, 
	sent_at, 
	billed_at, 
	shipped_at, 
	arrived_at, 
	first_attempt_at, 
	last_attempt_at, 
	on_porteo_until
 );

EXCEPTION
      WHEN OTHERS THEN
         p_error_code := SQLCODE;
         p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
         p_error_flag := 'S';

end sp_ins_zone_campaigns_dms;
/

