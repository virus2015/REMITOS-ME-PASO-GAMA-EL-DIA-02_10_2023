create PROCEDURE         SP_INS_REJECT_CAMPAIGNS_SIMPLI 
(
  P_ID_CAMPAIGN_ERROR IN VARCHAR2,
  P_MENSAJE_ERROR IN VARCHAR2,
  P_ERROR_FLAG OUT VARCHAR2,
  P_ERROR_CODE OUT VARCHAR2,
  P_ERROR_MESSAGE OUT VARCHAR2
) IS
  --V_ID NUMBER(38,0);
BEGIN

  p_error_flag := 'N';

  if P_ID_CAMPAIGN_ERROR is not null then
     if P_ID_CAMPAIGN_ERROR = '' then
         P_ERROR_FLAG := 'S';
         P_ERROR_CODE := '1';
         P_ERROR_MESSAGE := 'ID.REASON VACIO';
     end if;
  else
    P_ERROR_FLAG := 'S';
    P_ERROR_CODE := '1';
    P_ERROR_MESSAGE := 'ID.REASON NULO';
  end if;

  insert into error_log( id,rejected_id,rejection_type,message ) values ( ERROR_LOG_SEQ.NEXTVAL,NVL( P_ID_CAMPAIGN_ERROR,0), 'CAMPAIGN', P_MENSAJE_ERROR);

  commit;

  EXCEPTION
      WHEN OTHERS THEN
         p_error_code := SQLCODE;
         p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
         p_error_flag := 'S';

END SP_INS_REJECT_CAMPAIGNS_SIMPLI;
/

