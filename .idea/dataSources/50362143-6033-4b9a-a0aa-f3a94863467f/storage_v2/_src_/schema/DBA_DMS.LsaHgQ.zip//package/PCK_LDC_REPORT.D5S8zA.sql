create PACKAGE         PCK_LDC_REPORT AS
/******************************************************************************
   NAME:       PCK_LDC_REPORT
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        07/06/2022      reyesros       1. Created this package.
******************************************************************************/


  PROCEDURE SP_SEL_LDC_REPORT   ( P_OPC             IN NUMBER, -- Consulta por
                                 P_FULL_CAMPAIGN   IN NUMBER, -- full campaign 
                                 P_ZONE            IN NUMBER, ---  enviar con full campaign,P_LDC  P_OPC = 1
                                 P_ACCOUNT         IN NUMBER,--- enviar con full campaign, P_OPC = 4
                                 P_ROUTE           IN NUMBER,--- enviar con full campaign,P_LDC, P_ZONE, P_ROUTE P_OPC = 3
                                 P_LDC             IN VARCHAR2,--- enviar con full campaign,P_LDC y P_ZONE P_OPC = 2
                                 P_TRUCKNUMBER     IN VARCHAR2,
                                 P_ERROR_CODE      OUT VARCHAR2,
                                 P_ERROR_MESSAGE   OUT VARCHAR2,
                                 CUR_REPORT         OUT SYS_REFCURSOR                                                                     
);


END PCK_LDC_REPORT;
/

