create PACKAGE BODY         PCK_ONE_PAGE_REPRES
AS
    PROCEDURE SP_SEL_ONE_PAGE_REPRES (P_ACCOUNT         IN     NUMBER, ---- OBLIGATORIO
                                      P_CAMPAIGN        IN     VARCHAR2, ---- SI VA NULO, DEVUELVE LA ÚLTIMA CAMPAÑA DE FACTURACIÓN DE LA REPRESENTANTE
                                      P_YEAR            IN     NUMBER, ---- EL AÑO DEBE IR UNLO SI LA CAMPAÑA VA NULA
                                      P_ERROR_CODE         OUT VARCHAR2, --- Código SQL,
                                      P_ERROR_MESSAGE      OUT VARCHAR2,
                                      P_CURSOR             OUT SYS_REFCURSOR)
    AS
        V_ACCOUNT         NUMBER (12) := P_ACCOUNT;
        V_FULL_CAMPAIGN   NUMBER (6)  := P_YEAR||P_CAMPAIGN;
    BEGIN
        --- VALIDA SI EL VALOR DE ACCOUNT ES NULO Y LE ASIGNA EL VALOR DE LA ÚLTIMA CAMPAÑA FACTURADA

       IF V_ACCOUNT IS NOT NULL AND V_ACCOUNT > 0
        THEN
        --- VALIDA SI SE RECIBIÓ EL PARÁMETRO DE CAMPAÑA Y AÑO, SINO LE ASIGNA LA ÚLTIMA DELA REPRESENTANTE
            IF (P_YEAR IS  NULL  AND  P_CAMPAIGN IS  NULL )
                THEN
                    SELECT MAX (FULL_CAMPAIGN)
                      INTO V_FULL_CAMPAIGN
                      FROM scpi_order_headers
                     WHERE account = V_ACCOUNT;
                      END IF;
               
             OPEN P_CURSOR FOR
                SELECT S.ORDER_ID,
                       S.ACCOUNT,
                       s.address1 || ', ' || s.address2 || ', ' || s.address3
                           AS DIRECCION,
                    --   ACC_NAME,
                       S.ZONE,
                       s.full_campaign,
                       CASE WHEN c.order_id IS NOT NULL THEN
                                'SI'
                                ELSE
                                'NO'
                                END AS CREDIT_CHECK, 
                       NVL (TO_CHAR (COD), '-')
                           AS COD,
                       COD_AMOUNT,
                       s.ord_amount,
                       PCK_ONE_PAGE_REPRES.FN_ESTATUS_ORDEN (S.ORDER_ID)
                           AS ESTATUS,
                       NVL (C.OUTSTANDING_BALANCE, 0)
                           AS ANTICIPO_CREDIT_CHECK,
                       NVL (TO_CHAR (C.DIGITS), '-')
                           AS DIGITS,
                       z.billed_at
                           FECHA_DE_REPARTO_MAIL,
                       (SELECT COUNT (*)
                          FROM packages P
                         WHERE P.ORDER_ID = s.order_id)
                           AS TOTAL_BULTOS
                  FROM DBA_DMS.scpi_order_headers  S
                       INNER JOIN DBA_DMS.zone_campaigns Z
                           ON (    z.zone = s.zone
                               AND z.full_campaign = s.full_campaign)
                       LEFT JOIN DBA_DMS.credit_check C
                           ON c.order_id = s.order_id
                 WHERE     S.ACCOUNT = V_ACCOUNT
                       AND s.full_campaign = V_FULL_CAMPAIGN;
                      ELSE
                        OPEN P_CURSOR FOR
                SELECT NULL     ORDER_ID,
                       NULL     ACCOUNT,
                       NULL     DIRECCION,
                       NULL     ACC_NAME,
                       NULL     ZONE,
                       NULL     FULL_CAMPAIGN,
                       NULL     CREDIT_CHECK,
                       NULL     COD,
                       NULL     COD_AMOUNT,
                       NULL     ORD_AMOUNT,
                       NULL     ESTATUS,
                       NULL     ANTICIPO_CREDIT_CHECK,
                       NULL     DIGITS,
                       NULL     FECHA_DE_REPARTO_MAIL,
                       NULL     TOTAL_BULTOS
                  FROM DUAL;
                   P_ERROR_MESSAGE := 'NO SE ENCONTRARON DATOS PARA EL REGISTRO: '
                || P_ACCOUNT;

        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            OPEN P_CURSOR FOR
                SELECT NULL     ORDER_ID,
                       NULL     ACCOUNT,
                       NULL     DIRECCION,
                       NULL     ACC_NAME,
                       NULL     ZONE,
                       NULL     FULL_CAMPAIGN,
                       NULL     CREDIT_CHECK,
                       NULL     COD,
                       NULL     COD_AMOUNT,
                       NULL     ORD_AMOUNT,
                       NULL     ESTATUS,
                       NULL     ANTICIPO_CREDIT_CHECK,
                       NULL     DIGITS,
                       NULL     FECHA_DE_REPARTO_MAIL,
                       NULL     TOTAL_BULTOS
                  FROM DUAL;

            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_ONE_PAGE_REPRES.SP_SEL_ONE_PAGE_REPRES',
                   'Error de ejecucion en SP_SEL_ONE_PAGE_REPRES se recibieron los siguiente parámetros, P_ACCOUNT: '
                || P_ACCOUNT
                || ', P_CAMPAIGN: '
                || P_CAMPAIGN
                || 'P_YEAR: '
                || P_YEAR,
                SQLCODE,
                SQLERRM);
            P_ERROR_CODE := SQLCODE;
            P_ERROR_MESSAGE := 'NO SE ENCONTRARON DATOS CON LOS PARÁMETROS P_ACCOUNT: '
                || P_ACCOUNT
                || ', P_CAMPAIGN: '
                || P_CAMPAIGN
                || 'P_YEAR: '
                || P_YEAR||';';
         
            ROLLBACK;
        WHEN OTHERS
        THEN
            OPEN P_CURSOR FOR
                SELECT NULL     ORDER_ID,
                       NULL     ACCOUNT,
                       NULL     DIRECCION,
                       NULL     ACC_NAME,
                       NULL     ZONE,
                       NULL     FULL_CAMPAIGN,
                       NULL     CREDIT_CHECK,
                       NULL     COD,
                       NULL     COD_AMOUNT,
                       NULL     ORD_AMOUNT,
                       NULL     ESTATUS,
                       NULL     ANTICIPO_CREDIT_CHECK,
                       NULL     DIGITS,
                       NULL     FECHA_DE_REPARTO_MAIL,
                       NULL     TOTAL_BULTOS
                  FROM DUAL;

            DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                'DBA_DMS.PCK_ONE_PAGE_REPRES.SP_SEL_ONE_PAGE_REPRES',
                   'Error de ejecucion en SP_SEL_ONE_PAGE_REPRES se recibieron los siguiente parámetros, P_ACCOUNT: '
                || P_ACCOUNT
                || ', P_CAMPAIGN: '
                || P_CAMPAIGN
                || 'P_YEAR_ '
                || P_YEAR,
                SQLCODE,
                SQLERRM);
            P_ERROR_CODE := SQLCODE;
            P_ERROR_MESSAGE :=
                CONCAT (CONCAT (SQLERRM, '  '),
                        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
            ROLLBACK;
    END SP_SEL_ONE_PAGE_REPRES;

    FUNCTION FN_ESTATUS_ORDEN (P_ORDER_ID NUMBER)
        RETURN VARCHAR2
    AS
        V_ESTATUS     VARCHAR2 (3800)
                          := 'AÚN O SE TIENE ALGÚN ESTATUS DE LA ÓRDEN';
        V_C_ESTATUS   NUMBER (10);
    BEGIN
        SELECT COUNT (*)
          INTO V_C_ESTATUS
          FROM ORDERS_STATUSES  X
               INNER JOIN available_order_statuses A ON a.id = X.STATUS
         WHERE     X.order_id IN (P_ORDER_ID)
               AND x.ROWID IN
                       (SELECT MIN (y.ROWID)  --, ORDER_ID, UPDATED_AT, STATUS
                          FROM ORDERS_STATUSES y
                         WHERE     x.order_id = y.order_id
                               AND x.STATUS = y.STATUS --GROUP BY A.DESCRIPTION, x.ORDER_ID
                                                      );

          SELECT LISTAGG (A.SHORT_DESCRIPTION
                     || ' '
                     || TO_CHAR (x.UPDATED_AT, 'dd/MM/YYYY HH24:MI:SS'),
                     ' , ')
                 WITHIN GROUP (ORDER BY x.UPDATED_AT desc)    "ESTATUS" 
            INTO V_ESTATUS
            FROM ORDERS_STATUSES X
                 INNER JOIN available_order_statuses A ON a.id = X.STATUS
           WHERE     X.order_id IN (P_ORDER_ID)
                 AND a.id NOT IN (16)
                 AND x.ROWID IN
                         (SELECT MIN (y.ROWID) --, ORDER_ID, UPDATED_AT, STATUS
                            FROM ORDERS_STATUSES y
                           WHERE     x.order_id = y.order_id
                                 AND x.STATUS = y.STATUS --GROUP BY A.DESCRIPTION, x.ORDER_ID
                                                        )
        ORDER BY x.UPDATED_AT;

        RETURN V_ESTATUS;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN V_ESTATUS;
    END FN_ESTATUS_ORDEN;
END PCK_ONE_PAGE_REPRES;
/

