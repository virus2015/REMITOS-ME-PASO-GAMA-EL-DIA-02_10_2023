create trigger TRG_WHITE_LIST_SEQ
    before insert
    on WHITE_LIST
    for each row
BEGIN
  SELECT DBA_DMS.WHITE_LIST_SEQ.NEXTVAL
  INTO   :new.WHITE_LIST_ID
  FROM   DUAL;
END TRG_WHITE_LIST_SEQ;
/

