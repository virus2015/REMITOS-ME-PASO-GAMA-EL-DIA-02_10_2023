create PROCEDURE         SP_TRANDIVISIONS(
	P_ERROR_flag out varchar2,
	P_ERROR_code out varchar2,
	P_ERROR_message out varchar2,
	l_count out NUMBER,
    l_divisions OUT SYS_REFCURSOR
)
AS
    l_divs               SYS_REFCURSOR;
    r_division			 DIVISION%ROWTYPE;
	CHANGEFLAGQUERY 	 VARCHAR2(1000) := 'UPDATE DIVISION 
											SET                 
												CHANGE_FLAG = :CHANGEFLAG
											WHERE DIVISION = :DIV ';
	CHANGE_FLAG_DEFAULT  DIVISION.CHANGE_FLAG%TYPE := 'F' ;
BEGIN
    l_count := 0;   
	p_error_flag := 'N';
		
    OPEN l_divisions FOR
    SELECT *
		 FROM DIVISION
		WHERE CHANGE_FLAG = 'T'
		ORDER BY DIVISION;
		
	OPEN l_divs FOR
    SELECT *
		 FROM DIVISION
		WHERE CHANGE_FLAG = 'T'
		ORDER BY DIVISION;
		
	LOOP
        FETCH l_divs INTO r_division;
        EXIT WHEN l_divs%NOTFOUND;
        
        EXECUTE IMMEDIATE CHANGEFLAGQUERY 
        USING CHANGE_FLAG_DEFAULT, r_division.DIVISION;
        
        COMMIT;    
        l_count := l_count + 1;
	END LOOP;
		
	CLOSE l_divs;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
	p_error_code := SQLCODE;
    p_error_message := concat( concat( SQLERRM, '  '), DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() ); 
    p_error_flag := 'Y';
END SP_TRANDIVISIONS;
/

