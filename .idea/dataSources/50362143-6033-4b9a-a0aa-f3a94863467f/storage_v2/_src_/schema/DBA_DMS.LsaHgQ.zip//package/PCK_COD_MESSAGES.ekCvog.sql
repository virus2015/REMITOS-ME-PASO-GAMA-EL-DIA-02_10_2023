create PACKAGE PCK_COD_MESSAGES AS
/******************************************************************************
   NAME:       PCK_COD_MESSAGES
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        23/02/2022      reyesros       1. Created this package.
******************************************************************************/


  PROCEDURE SP_SELECT_MESSAGES  (P_SEND_TO IN VARCHAR2, ---C campaña, Z campaña y zona, A ACCONT
                                 P_FULL_CAMPAIGN IN NUMBER,
                                 P_ZONE IN NUMBER,
                                 P_ACCOUNT IN NUMBER,
                                 P_MAIL IN VARCHAR2,
                                 P_LDC  IN VARCHAR2,
                                 P_REGION IN NUMBER,
                                 P_DIVISION IN NUMBER,
                                  P_ERROR_FLAG         OUT VARCHAR2, --- S = CON ERROR N = SIN ERROR
                                 P_ERROR_CODE         OUT VARCHAR2,
                                 P_ERROR_MESSAGE      OUT VARCHAR2,
                                 P_CURSOR_MESS OUT SYS_REFCURSOR  );

END PCK_COD_MESSAGES;
/

