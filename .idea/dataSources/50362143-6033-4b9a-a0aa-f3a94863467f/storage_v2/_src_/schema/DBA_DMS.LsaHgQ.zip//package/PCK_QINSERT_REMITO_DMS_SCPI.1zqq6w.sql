create PACKAGE PCK_QINSERT_REMITO_DMS_SCPI AS 

/* TODO enter package declarations (types, exceptions, methods etc) here */ 
PROCEDURE SP_QRY_REMITO_DMS_SCPI 
(
  p_in_remito_date in varchar2,
  insert_count_rows out INTEGER,
  p_error_flag out varchar2,
  p_error_code out varchar2,
  p_error_message out varchar2
);

PROCEDURE SP_QUPSERT_REMITO_DMS_SCPI 
(
  p_in_campaign in integer,
  p_in_recolection_flag in varchar2,
  p_in_remito_route in integer,
  p_in_remito_truck in varchar2,
  p_in_zone in integer,
  p_in_account in integer,
  p_in_remito_date in varchar2,
  p_in_collected_quantity number(10,0),
  p_in_return_update date,
  p_in_reaco_date date,
  p_in_comments varchar2(150 byte),
  p_in_return_status varchar2(25 byte),
  p_in_remito_status varchar2(20 byte),
  p_in_quantity_to_collect number(10,0),
  p_in_porteo varchar2(8 byte),
  insert_count_rows out INTEGER,
  p_error_flag out varchar2,
  p_error_code out varchar2,
  p_error_message out varchar2
);

PROCEDURE SP_QINSERT_REMITO_HEADER_DMS_SCPI 
(
  --P_IN_ID IN VARCHAR2, 
  insert_count_rows out INTEGER,
  p_error_flag out varchar2,
  p_error_code out varchar2,
  p_error_message out varchar2
);

FUNCTION SP_GET_SEQ_DMS_SCPI
(
    seq_name in varchar2
);

END PCK_QINSERT_REMITO_DMS_SCPI;
/

