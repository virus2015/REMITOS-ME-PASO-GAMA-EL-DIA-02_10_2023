create PACKAGE BODY PCK_CHARGE_FREE_REPRES AS

  PROCEDURE SP_UPD_CHARGE_FREE_REPRES ( P_ROWS              OUT VARCHAR2,--- REGISTROS PROCESADOS
                                P_ERROR_CODE         OUT VARCHAR2,--- NUM DE ERROR
                                P_ERROR_MESSAGE      OUT VARCHAR2,
                                PAYMENTS_PROCESSED   OUT NUMBER,
                                AMOUNTS_PROCESSED    OUT NUMBER) 
 IS
    V_PAYMENTS_PROCESSED   NUMBER (8) := 0;
    V_AMOUNTS_PROCESSED    NUMBER (8) := 0;
    BEFORE_ROWS_AMOUNTS    NUMBER (19) := 0;
    AFTER_ROWS_AMOUNTS     NUMBER (19) := 0;
    V_ACCOUNT              NUMBER (8) := 0;
    V_CURRENT_AMOUNT_O     NUMBER (10, 2) := 0;
    V_PAYMENT_AMOUNT       NUMBER (10) := 0;
    V_CAMPAIGN_YEAR_P      NUMBER (6) := 0;
    V_CAMPAIGN             NUMBER (2) := 0;
    V_ID_ONLINE_PAYMENTS   NUMBER (38) := 0;
    V_CAMPAIGN_PAYED       NUMBER (6) := 0;
    V_COUNT_ORDER_A        NUMBER (6) := 0;
    V_TOTAL_PAYMENT        NUMBER (12) := 0;
    V_PREVIUS_CAMPAIGN     NUMBER (6) := 0;
    V_ORDER                NUMBER (19) := 0;
    V_FULLCAMPAIGN         NUMBER (6) := 0;
    ---       --- PROCESA ÓRDENES SOLICITADAS POR NEGOCIO
       


    --- OBTIENE TODOS LOS PAGOS VIRTUALES DEL DÍA DEL HOY
    CURSOR CUR_PAYMENTS IS
          SELECT ID,
                 CAMPAIGN_YEAR,
                 CAMPAIGN,
                 ACCOUNT,
                 PAYMENT_AMOUNT
            FROM ONLINE_PAYMENTS P
           WHERE     P.BIDS_TRANSACT = '017'      --- QUE SEAN DE TIPO ON LINE
                 AND TRUNC (P.created_at) = TRUNC (SYSDATE) --- PAGOS SÓLO DEL DÍA DE HOY
                 AND P.updated_at IS NULL            --- NO SE HAYAN PROCESADO
                 AND BANK_CODE = 70 --- QUE SEAN PAGOS VIRTUALES
        ORDER BY created_at, ID ASC; ---ORDENAR POR FECHA DE CREACIÓN Y PRIMERA ORDEN
BEGIN
    P_ERROR_FLAG := 'N';

    SELECT COUNT (*)
      INTO BEFORE_ROWS_AMOUNTS
      FROM ONLINE_PAYMENTS P
     WHERE     P.BIDS_TRANSACT = '017'            --- QUE SEAN DE TIPO ON LINE
           AND TRUNC (P.created_at) = TRUNC (SYSDATE)   --- PAGOS SÓLO DEL DÍA
           AND P.updated_at IS NULL                  --- NO SE HAYAN PROCESADO
           AND BANK_CODE = 70 --- QUE SEAN PAGOS VIRTUALES
           ;

    OPEN CUR_PAYMENTS;

    LOOP
        FETCH CUR_PAYMENTS
            INTO V_ID_ONLINE_PAYMENTS,
                 V_CAMPAIGN_YEAR_P,
                 V_CAMPAIGN,
                 V_ACCOUNT,
                 V_PAYMENT_AMOUNT;

        EXIT WHEN CUR_PAYMENTS%NOTFOUND;
        V_PAYMENTS_PROCESSED := V_PAYMENTS_PROCESSED + SQL%ROWCOUNT;

                --- PONE EN CERO EL CURRENT AMOUNT
                V_TOTAL_PAYMENT := 0;
                --ACTUALIZA LOS SALDOS DE LAS ORDENES
                UPDATE ORDERS
                   SET CURRENT_AMOUNT = V_TOTAL_PAYMENT,
                       PREVIOUS_AMOUNT = V_CURRENT_AMOUNT_O,
                       TRANSFER_FLAG =
                           DECODE (TRANSFER_FLAG,
                                   'B', 'B',                 ---SE FUE A BIDS,
                                   'R', 'R',                         ---RETURN
                                   'F', 'F',
                                   'E')                   --- QUE LO ACTUALICE
                                       ,
                       PAYMENTS_COUNT = PAYMENTS_COUNT + 1,
                       UPDATED_BY = 'ONLINE PAYMENTS',
                       UPDATED_AT =
                           CURRENT_TIMESTAMP
                               AT TIME ZONE 'America/Mexico_City'
                 WHERE     CURRENT_AMOUNT > 0     --- LA ORDEN ES MAYOR A CERO
                       AND ORDER_ID IN         --- APLICADO ATODAS LAS ÓRDENES
                               (SELECT DISTINCT (C.ORDER_ID) --- TODAS LAS ORDENES
                                  FROM DBA_DMS.CHARGE_FREE_REPRES C
                                 WHERE    
                                      C.ACCOUNT = V_ACCOUNT)
                                       AND BANK_CODE = 70 --- QUE SEAN PAGOS VIRTUALES
                                       ; --- POR REPRESENTANTE

                ---ACTUALIZA LOS PAGOS APLICADOS
                UPDATE ONLINE_PAYMENTS
                   SET APPLIED_ORDER_NUMBER = V_ORDER,     --- LA ULTIMA ORDEN
                       APPLIED_ORDER_QUANTITY = 1,
                       PROCESSED_AT =
                           CURRENT_TIMESTAMP
                               AT TIME ZONE 'America/Mexico_City',
                       UPDATED_AT =
                           CURRENT_TIMESTAMP
                               AT TIME ZONE 'America/Mexico_City'
                 WHERE                              --- VALIDAR REGISTRO ÚNICO
                           ACCOUNT = V_ACCOUNT
                       AND CAMPAIGN_YEAR = V_CAMPAIGN_YEAR_P
                       AND CAMPAIGN = V_CAMPAIGN
                       AND BIDS_TRANSACT = '017'  --- QUE SEAN DE TIPO ON LINE
                       AND TRUNC (created_at) = TRUNC (SYSDATE) --- RANGO DE FECHA
                       AND updated_at IS NULL        --- NO SE HAYAN PROCESADO
                       AND ID = V_ID_ONLINE_PAYMENTS                --- POR ID
                       AND BANK_CODE = 70 --- QUE SEAN PAGOS VIRTUALES
                                                    ;

                V_AMOUNTS_PROCESSED := V_AMOUNTS_PROCESSED + 1;
                COMMIT;
      
    END LOOP;
    CLOSE CUR_PAYMENTS;

    PAYMENTS_PROCESSED := V_PAYMENTS_PROCESSED;
    AMOUNTS_PROCESSED := V_AMOUNTS_PROCESSED;
EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
    WHEN OTHERS
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';

    END SP_UPD_CHARGE_FREE_REPRES;
    
   
   PROCEDURE SP_UPD_CHARGE_FREE_REPRES_1 ( P_ROWS              OUT VARCHAR2,--- REGISTROS PROCESADOS
                                P_ERROR_CODE         OUT VARCHAR2,--- NUM DE ERROR
                                P_ERROR_MESSAGE      OUT VARCHAR2)
                                AS 
        BEGIN
     P_ERROR_FLAG := 'N';
            For i in (
        
        SELECT  h.ORDER_ID, ACCOUNT, CURRENT_AMOUNT, FULL_CAMPAIGN FROM ORDERS O
        INNER JOIN DBA_DMS.scpi_order_headers H
        ON H.ORDER_ID = O.ORDER_ID
        WHERE FULL_CAMPAIGN  IN (fn_get_current_campaign)
        AND CURRENT_AMOUNT > 0
        AND account IN (SELECT account FROM DBA_DMS.CHARGE_FREE_REPRES
        WHERE CHECK_ORDER = 'F' ---- QUE NO HAYAN SIDO PROCESADAS
        )
        
        ) 
        LOOP
        Update DBA_DMS.CHARGE_FREE_REPRES set  ORDER_ID =  I.ORDER_ID,  CURRENT_AMOUNT = I.CURRENT_AMOUNT, 
        ORDER_CAMPAIGN=  I.FULL_CAMPAIGN , CHECK_ORDER = 'T',
        UPDATED_AT = CURRENT_TIMESTAMP AT TIME ZONE 'America/Mexico_City'
        where ACCOUNT = i.ACCOUNT  ;
        END LOOP;



EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
    WHEN OTHERS
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
  END SP_UPD_CHARGE_FREE_REPRES_1;

END PCK_CHARGE_FREE_REPRES;
/

