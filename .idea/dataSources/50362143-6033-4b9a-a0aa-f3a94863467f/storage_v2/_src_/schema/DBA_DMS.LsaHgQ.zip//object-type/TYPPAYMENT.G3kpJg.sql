create TYPE           "TYPPAYMENT"                                          AS OBJECT(
	ACCOUNT varchar2(20),
	ORDER_NUMBER varchar2(20),
	FULL_CAMPAIGN number(6),
	REMAINING_AMOUNT number(15,2),
	BILL_DATE timestamp,
	ID number(19),
	PAYMENT_AMOUNT number(12,2)
)
/

