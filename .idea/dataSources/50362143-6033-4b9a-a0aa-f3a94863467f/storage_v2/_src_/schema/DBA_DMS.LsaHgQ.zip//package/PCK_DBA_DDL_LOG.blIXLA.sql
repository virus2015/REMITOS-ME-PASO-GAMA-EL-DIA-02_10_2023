create PACKAGE PCK_DBA_DDL_LOG IS
  /******************************************************************************
   NAME:       PCK_DBA_LOG
   PURPOSE:    GUARDA ERRORES ORACLE

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        11/05/2021  JUAN C LOZANO    1. Created this package.
******************************************************************************/
    PROCEDURE INSERT_DBA_DDL_LOG
    (
     I_OBJECT   IN VARCHAR2,
     I_AUTHOR   IN VARCHAR2,
     I_SQL_TEXT IN VARCHAR2,
     I_SQLCODE  IN VARCHAR2,
     I_SQLERRM  IN VARCHAR2
    );
END PCK_DBA_DDL_LOG;
/

