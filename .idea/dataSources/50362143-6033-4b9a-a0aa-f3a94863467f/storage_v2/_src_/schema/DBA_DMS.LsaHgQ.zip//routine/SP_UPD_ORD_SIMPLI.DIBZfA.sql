create PROCEDURE SP_UPD_ORD_SIMPLI 
(
  P_ORDER_ID IN VARCHAR2,
  P_PAYMENT_VALUE IN VARCHAR2,
  P_BANK_CODE IN VARCHAR2,
  P_PAYMENT_DATE IN VARCHAR2,
  P_ROUND_NUM IN VARCHAR2,
  P_RETURN_REASON IN VARCHAR2,
  P_NOTES IN VARCHAR2,
  P_DLV_TYP IN VARCHAR2,
  P_DELIVERY1ST IN VARCHAR2,
  P_RETURN_VAL IN VARCHAR2,
  P_PICK_UP_POINT_ID IN VARCHAR2,
  P_BLOCKED_STATUS IN VARCHAR2,
  P_STOLEN IN VARCHAR2,
  P_STATUSES IN VARCHAR2
) IS
  V_ORDER_ID NUMBER(19,0);
  V_PAYMENT_VALUE NUMBER(11,2);
  V_BANK_CODE CHAR(3 BYTE);
  V_PAYMENT_DATE TIMESTAMP(6);
  V_ROUND_NUM CHAR(2 BYTE);
  V_RETURN_REASON CHAR(2 BYTE);
  V_NOTES VARCHAR2(50 BYTE);
  V_DLV_TYP CHAR(3 BYTE);
  V_DELIVERY1ST CHAR(2 BYTE);
  V_RETURN_VAL NUMBER(11,2);
  V_PICK_UP_POINT_ID VARCHAR2(10 BYTE);
  V_BLOCKED_STATUS NUMBER(4,0);
  V_STOLEN CHAR(1 BYTE);
  V_STATUSES NUMBER(19,0);
BEGIN

  if P_ORDER_ID is not null then
     if P_ORDER_ID = '' then
         V_ORDER_ID := null;
     else
         V_ORDER_ID := to_number(P_ORDER_ID);
     end if;
  else
    V_ORDER_ID := null;
  end if;
  
  if P_PAYMENT_VALUE is not null then
     if P_PAYMENT_VALUE = '' then
         V_PAYMENT_VALUE := null;
     else
         V_PAYMENT_VALUE := to_number(P_PAYMENT_VALUE);
     end if;
  else
    V_PAYMENT_VALUE := null;
  end if;
  
  if P_BANK_CODE is not null then
     if P_BANK_CODE = '' then
         V_BANK_CODE := null;
     else
         V_BANK_CODE := to_char(P_BANK_CODE);
     end if;
  else
    V_BANK_CODE := null;
  end if;
  
  if P_PAYMENT_DATE is not null then
     if P_PAYMENT_DATE = '' then
         V_PAYMENT_DATE := null;
     else
         V_PAYMENT_DATE := TO_TIMESTAMP(P_PAYMENT_DATE,'DD-MM-YYYY HH24:MI:SS');
     end if;
  else
    V_PAYMENT_DATE := null;
  end if;
  
  if P_ROUND_NUM is not null then
     if P_ROUND_NUM = '' then
         V_ROUND_NUM := null;
     else
         V_ROUND_NUM := to_char(P_ROUND_NUM);
     end if;
  else
    V_ROUND_NUM := null;
  end if;
  
  if P_RETURN_REASON is not null then
     if P_RETURN_REASON = '' then
         V_RETURN_REASON := null;
     else
         V_RETURN_REASON := to_char(P_RETURN_REASON);
     end if;
  else
    V_RETURN_REASON := null;
  end if;

  if P_DLV_TYP is not null then
     if P_DLV_TYP = '' then
         V_DLV_TYP := null;
     else
         V_DLV_TYP := to_char(P_DLV_TYP);
     end if;
  else
    V_DLV_TYP := null;
  end if;
  
  if P_DELIVERY1ST is not null then
     if P_DELIVERY1ST = '' then
         V_DELIVERY1ST := null;
     else
         V_DELIVERY1ST := to_char(P_DELIVERY1ST);
     end if;
  else
    V_DELIVERY1ST := null;
  end if;
  
  if P_RETURN_VAL is not null then
     if P_RETURN_VAL = '' then
         V_RETURN_VAL := null;
     else
         V_RETURN_VAL := to_number(P_RETURN_VAL);
     end if;
  else
    V_RETURN_VAL := null;
  end if;
  
  --if P_PICK_UP_POINT_ID is not null then
  --   if P_PICK_UP_POINT_ID = '' then
  --       V_PICK_UP_POINT_ID := null;
  --   else
  --       V_PICK_UP_POINT_ID := to_number(P_PICK_UP_POINT_ID);
  --   end if;
  --else
  --  V_PICK_UP_POINT_ID := null;
  --end if;
  
  if P_BLOCKED_STATUS is not null then
     if P_BLOCKED_STATUS = '' then
         V_BLOCKED_STATUS := null;
     else
         V_BLOCKED_STATUS := to_number(P_BLOCKED_STATUS);
     end if;
  else
    V_BLOCKED_STATUS := null;
  end if;
  
  if P_STOLEN is not null then
     if P_STOLEN = '' then
         V_STOLEN := null;
     else
         V_STOLEN := to_char(P_STOLEN);
     end if;
  else
    V_STOLEN := null;
  end if;
  
  if P_STATUSES is not null then
     if P_STATUSES = '' then
         V_STATUSES := null;
     else
         V_STATUSES := to_number(P_STATUSES);
     end if;
  else
    V_STATUSES := null;
  end if;
  
  if ( V_ORDER_ID is not null and V_STATUSES is not null ) then
  
      update orders set
                  payment_value = V_PAYMENT_VALUE,
                  bank_code = V_BANK_CODE,
                  payment_date = V_PAYMENT_DATE,
                  round_num = V_ROUND_NUM,
                  return_reason = V_RETURN_REASON,
                  notes = P_NOTES,
                  dlv_typ = V_DLV_TYP,
                  delivery1st = V_DELIVERY1ST,
                  return_val = V_RETURN_VAL,
                  pick_up_point_id = P_PICK_UP_POINT_ID,
                  blocked_status = V_BLOCKED_STATUS,
                  stolen = V_STOLEN,
                  change_flag = 'T',
                  UPDATED_AT = CURRENT_TIMESTAMP
        where order_id = V_ORDER_ID;
        
        insert into orders_statuses(order_id, updated_at, status)
        VALUES
        (V_ORDER_ID,CURRENT_TIMESTAMP,V_STATUSES);
        
        commit;
        
  end if;
  
  EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20001,
                            'HA OCURRIDO UN ERROR AL INTENTAR ACTUALIZAR LA ORDEN ' || V_ORDER_ID ||' - ' ||
                            SQLCODE || ' -ERROR- ' || SQLERRM);

END SP_UPD_ORD_SIMPLI;
/

