create procedure sp_ins_zone_manager_dms
(	id            in varchar2, 
	zone_id       in number, 
	given_name    in varchar2, 
	last_name     in varchar2, 
	second_last_name in varchar2, 
	email         in varchar2, 
	zone_status   in number,
    inserted_row out number,
    p_error_flag out varchar2,
    p_error_code out varchar2,
    p_error_message out varchar2
)
is

BEGIN
p_error_flag := 'N';

insert into ZONE_MANAGER (ID,ZONE_ID,GIVEN_NAME,LAST_NAME,SECOND_LAST_NAME,EMAIL,ZONE_STATUS) values 
(	id, 
	zone_id, 
	given_name, 
	last_name, 
	second_last_name, 
	email, 
	zone_status
);

EXCEPTION
      WHEN OTHERS THEN
         p_error_code := SQLCODE;
         p_error_message := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
         p_error_flag := 'S';

end sp_ins_zone_manager_dms;
/

