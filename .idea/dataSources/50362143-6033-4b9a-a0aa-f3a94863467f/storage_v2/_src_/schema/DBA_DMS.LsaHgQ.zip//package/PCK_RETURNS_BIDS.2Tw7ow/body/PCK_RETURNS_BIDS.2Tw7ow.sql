create PACKAGE BODY PCK_RETURNS_BIDS
AS
    PROCEDURE SP_BIDS_RETURN_HEADER (P_ERROR_CODE      OUT VARCHAR2, --- Código SQL,
                                     P_ERROR_MESSAGE   OUT VARCHAR2,
                                     P_CUR_OUT         OUT SYS_REFCURSOR)
    AS
        V_COUNT   VARCHAR2 (6) := 0;
    BEGIN
        ---VALIDAR SI SE TIENEN REGISTROS
        SELECT COUNT (*)
          INTO V_COUNT
          FROM DBA_DMS.BIDS_RETURN_HEADER
         WHERE TRANSFER_FLAG = 'F';

        IF V_COUNT > 0
        THEN                                                      --- CONSULTA
            OPEN P_CUR_OUT FOR
                SELECT PROCESS_ID,
                       JOB_NAME,
                       JOB_TYPE,
                       TRANSACTION_COUNT,
                       ERROR_COUNT,
                       TO_CHAR  (UPDATED_AT, 'YYYY-MM-DD HH24:MI:SS')
                           AS PROCESSED_AT,
                       NULL
                           AS TRANSACTION_ID,
                       TRANSACTION_VALUE,
                       ERROR_VALUE,
                       TRANSACTION_STATUS
                  FROM DBA_DMS.BIDS_RETURN_HEADER
                    WHERE TRANSFER_FLAG = 'F';
        ELSE
            OPEN P_CUR_OUT FOR
                SELECT NULL     AS PROCESS_ID,
                       NULL     AS JOB_NAME,
                       NULL     AS JOB_TYPE,
                       NULL     AS TRANSACTION_COUNT,
                       NULL     AS ERROR_COUNT,
                       NULL     AS PROCESSED_AT,
                       NULL     AS TRANSACTION_ID,
                       NULL     AS TRANSACTION_VALUE,
                       NULL     AS ERROR_VALUE,
                       NULL     AS TRANSACTION_STATUS
                  FROM DUAL;
        END IF;
           EXCEPTION
        WHEN OTHERS
        THEN
              DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                  'DBA_DMS.PCK_RETURNS_BIDS.SP_BIDS_RETURN_HEADER',
                  'hubo un error al ejecutar la consulta de devoluciones bids, para el envío a simpli en el header',
                  SQLCODE,
                  SQLERRM);
            P_ERROR_CODE := SQLCODE;
            P_ERROR_MESSAGE :=
                CONCAT (CONCAT (SQLERRM, '  '),
                        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
            ROLLBACK;
    END SP_BIDS_RETURN_HEADER;

    PROCEDURE SP_BIDS_RETURN_DETAIL (P_PROCESS_ID      IN     NUMBER,
                                     P_ERROR_CODE         OUT VARCHAR2, --- Código SQL
                                     P_ERROR_MESSAGE      OUT VARCHAR2,
                                     P_CUR_OUT            OUT SYS_REFCURSOR)
    AS
        V_COUNT   VARCHAR2 (6) := 0;
    BEGIN
        ---VALIDAR SI SE TIENEN REGISTROS
        SELECT COUNT (*)
          INTO V_COUNT
          FROM DBA_DMS.BIDS_RETURN_DETAIL  d
               INNER JOIN DBA_DMS.BIDS_RETURN_HEADER H
                   ON d.PROCESS_ID = h.PROCESS_ID
         WHERE d.PROCESS_ID = P_PROCESS_ID AND TRANSFER_FLAG = 'F';

        IF V_COUNT > 0
        THEN                                                      --- CONSULTA
            OPEN P_CUR_OUT FOR
                SELECT D.PROCESS_ID,
                       D.ACCOUNT,
                       H.JOB_TYPE,
                       D.ZONE,
                       D.TRANSACTION_VALUE,
                       TO_CHAR (D.TRANSACTION_DATE, 'YYYY-MM-DD HH24:MI:SS')
                           AS TRANSACTION_DATE,
                       SUBSTR (D.FULL_CAMPAIGN, 0, 4)
                           TRANSACTION_YEAR,
                       SUBSTR (D.FULL_CAMPAIGN, 5, 2)
                           TRANSACTION_CAMPAIGN,
                       D.ERROR_TYPE,
                       D.REPROCESS_FLAG,
                       D.REPROCESS_DONE,
                       D.FULL_CAMPAIGN,
                       D.ORDER_ID,
                       D.TRANSACTION_STATUS
                           AS ESTATUS
                  FROM DBA_DMS.BIDS_RETURN_DETAIL  d
                       INNER JOIN DBA_DMS.BIDS_RETURN_HEADER H
                           ON d.PROCESS_ID = h.PROCESS_ID
                 WHERE d.PROCESS_ID = P_PROCESS_ID ;
        ELSE
            OPEN P_CUR_OUT FOR
                SELECT NULL     AS PROCESS_ID,
                       NULL     AS ACCOUNT,
                       NULL     AS JOB_TYPE,
                       NULL     AS ZONE,
                       NULL     AS TRANSACTION_VALUE,
                       NULL     AS TRANSACTION_DATE,
                       NULL     AS TRANSACTION_YEAR,
                       NULL     AS TRANSACTION_CAMPAIGN,
                       NULL     AS ERROR_TYPE,
                       NULL     AS REPROCESS_FLAG,
                       NULL     AS REPROCESS_DONE,
                       NULL     AS FULL_CAMPAIGN,
                       NULL     AS ORDER_ID,
                       NULL     AS ESTATUS
                  FROM DUAL;
        END IF;
          EXCEPTION
        WHEN OTHERS
        THEN
              DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG (
                  'DBA_DMS.PCK_RETURNS_BIDS.SP_BIDS_RETURN_DETAIL',
                  'hubo un error al ejecutar la consulta de devoluciones bids, para el envío a simpli en el detail',
                  SQLCODE,
                  SQLERRM);
            P_ERROR_CODE := SQLCODE;
            P_ERROR_MESSAGE :=
                CONCAT (CONCAT (SQLERRM, '  '),
                        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
            ROLLBACK;
    END SP_BIDS_RETURN_DETAIL;
END PCK_RETURNS_BIDS;
/

