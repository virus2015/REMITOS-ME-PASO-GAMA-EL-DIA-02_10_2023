create PACKAGE BODY         PCK_WHITE_LIST AS
/******************************************************************************
   NAME:       SP_SELECT_WHITE_LIST
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        23/03/2022      reyesros     1. Genera los datos dela tabla White_list a partir de una selección a la tabla de representantes con zona o cuenta
******************************************************************************/
  PROCEDURE SP_INS_WHITE_LIST  (
                                     P_FULL_CAMPAIGN IN NUMBER,
                                     P_ZONE          IN NUMBER,
                                     P_ACCOUNT       IN NUMBER,
                                     P_LOADED_BY     IN VARCHAR2,
                                     P_UPDATED_BY    IN VARCHAR2,
                                     P_ERROR_FLAG         OUT VARCHAR2, --- S = CON ERROR N = SIN ERROR
                                     P_ERROR_CODE         OUT VARCHAR2,
                                     P_ERROR_MESSAGE      OUT VARCHAR2,
                                     P_COUNT              OUT NUMBER ) AS
                                 
               V_FULL_CAMPAIGN    NUMBER (6)  :=    P_FULL_CAMPAIGN;  
               V_ZONE             NUMBER (4)   :=   P_ZONE;
               V_ACCOUNT          NUMBER (18)  :=   P_ACCOUNT;
               V_LOADED_BY        VARCHAR2 (1) :=   P_LOADED_BY;
               V_UPDATED_BY       VARCHAR2 (80)  :=  P_UPDATED_BY;
               V_COUNT            VARCHAR2 (1) :=   0;
               
                                 
  BEGIN
   P_ERROR_FLAG := 'N';
   P_COUNT := 0;
   CASE V_LOADED_BY 
   WHEN 'Z'
   THEN
        ---- INSERTA POR ZONA
    INSERT INTO DBA_DMS.WHITE_LIST(WHITE_LIST_ID, FULLCAMPAIGN, ACCOUNT, ZONE_ID, LOADED_BY, UPDATED_BY) 
    SELECT DBA_DMS.WHITE_LIST_SEQ.NEXTVAL WHITE_LIST_ID, V_FULL_CAMPAIGN FULLCAMPAIGN, ACCOUNT, DEFAULT_ZONE ZONE_ID, V_LOADED_BY LOADED_BY, P_UPDATED_BY 
    FROM DBA_DMS.REPRESENTATIVES WHERE DEFAULT_ZONE = V_ZONE 
    AND (V_FULL_CAMPAIGN, ACCOUNT) NOT IN (SELECT FULLCAMPAIGN, ACCOUNT FROM WHITE_LIST );--- QUE NO EXISTAN EN LA TABLA
    P_COUNT   := SQL%ROWCOUNT;
    COMMIT;
    WHEN 'A'
    THEN
   --- INSERTA POR REPRESENTANTE
    INSERT INTO DBA_DMS.WHITE_LIST(WHITE_LIST_ID, FULLCAMPAIGN, ACCOUNT, ZONE_ID, LOADED_BY, UPDATED_BY) 
    SELECT DBA_DMS.WHITE_LIST_SEQ.NEXTVAL WHITE_LIST_ID, V_FULL_CAMPAIGN FULLCAMPAIGN, ACCOUNT, DEFAULT_ZONE ZONE_ID, V_LOADED_BY LOADED_BY, P_UPDATED_BY 
    FROM DBA_DMS.REPRESENTATIVES WHERE ACCOUNT = V_ACCOUNT
    AND (V_FULL_CAMPAIGN, ACCOUNT) NOT IN (SELECT FULLCAMPAIGN, ACCOUNT FROM WHITE_LIST );--- QUE NO EXISTAN EN LA TABLA
    P_COUNT   := SQL%ROWCOUNT;
    COMMIT;
    END CASE;
     EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
    WHEN OTHERS
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
        P_ERROR_FLAG := 'S';
  END SP_INS_WHITE_LIST;


     PROCEDURE SP_SEND_WL_SIMPLI
     (
      P_CURSOR_WL             OUT SYS_REFCURSOR  ---- 
    )
    AS
    BEGIN
    
    OPEN P_CURSOR_WL FOR
    SELECT
    WHITE_LIST_ID, FULLCAMPAIGN, ACCOUNT, ZONE_ID, LOADED_BY, TRANSFER_FLAG, CREATED_AT, UPDATED_BY
    FROM DBA_DMS.WHITE_LIST where TRANSFER_FLAG = 'F' and ROWNUM <= 1000;
  
     EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        ROLLBACK;
      OPEN P_CURSOR_WL FOR  SELECT
    NULL WHITE_LIST_ID, NULL FULLCAMPAIGN, NULL ACCOUNT, NULL ZONE_ID, NULL LOADED_BY, NULL TRANSFER_FLAG, NULL CREATED_AT, NULL UPDATED_BY
    FROM DUAL;
        
    WHEN OTHERS
    THEN
        ROLLBACK;
      OPEN P_CURSOR_WL FOR  SELECT
    NULL WHITE_LIST_ID, NULL FULLCAMPAIGN, NULL ACCOUNT, NULL ZONE_ID, NULL LOADED_BY, NULL TRANSFER_FLAG, NULL CREATED_AT, NULL UPDATED_BY
    FROM DUAL;   
END SP_SEND_WL_SIMPLI;

PROCEDURE SP_UPD_WHITE_LIST (P_FULL_CAMPAIGN   IN     NUMBER,
                             P_ACCOUNT         IN     NUMBER,
                             P_ERROR_FLAG         OUT VARCHAR2, --- S = CON ERROR N = SIN ERROR
                             P_ERROR_CODE         OUT VARCHAR2,
                             P_ERROR_MESSAGE      OUT VARCHAR2,
                             P_COUNT              OUT NUMBER)
AS
   V_FULL_CAMPAIGN   NUMBER (6) := P_FULL_CAMPAIGN;
   V_ACCOUNT         NUMBER (18) := P_ACCOUNT;
   V_COUNT           VARCHAR2 (1) := 0;
BEGIN
   P_ERROR_FLAG := 'N';
   P_COUNT := 0;

   ---- UPDATE POR FULL_CAMPAIGN AND ACCOUNT
   UPDATE DBA_DMS.WHITE_LIST
      SET TRANSFER_FLAG = 'T'
    WHERE     ACCOUNT = V_ACCOUNT
          AND FULLCAMPAIGN = V_FULL_CAMPAIGN
          AND TRANSFER_FLAG = 'F';

   P_COUNT := SQL%ROWCOUNT;
   COMMIT;
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      ROLLBACK;
      P_ERROR_CODE := SQLCODE;
      P_ERROR_MESSAGE :=
         CONCAT (CONCAT (SQLERRM, '  '),
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
      P_ERROR_FLAG := 'S';
   WHEN OTHERS
   THEN
      ROLLBACK;
      P_ERROR_CODE := SQLCODE;
      P_ERROR_MESSAGE :=
         CONCAT (CONCAT (SQLERRM, '  '),
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
      P_ERROR_FLAG := 'S';
END SP_UPD_WHITE_LIST;

END PCK_WHITE_LIST;
/

