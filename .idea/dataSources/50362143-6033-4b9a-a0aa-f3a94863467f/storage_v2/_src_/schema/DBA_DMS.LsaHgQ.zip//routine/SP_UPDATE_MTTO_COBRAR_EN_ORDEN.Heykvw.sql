create PROCEDURE         sp_update_mtto_cobrar_en_orden
IS 
    p_campaign_year					NUMBER(4,0);
	p_campaign_number				NUMBER(2,0);
	p_account						NUMBER(8,0);

	p_process_date					timestamp;

	p_default_zone						int;
	p_id_order						NUMBER(19,0);
	p_orden							VARCHAR2(20);
	p_TotalOrdenes					int;

	p_MontoACobrar					number(14,2);
	p_MontoACobrarAnterior			number(14,2);
	p_Modif_seq						VARCHAR2(20);
	p_MontoACobrarNuevo				number(14,2);
	p_modif_monto_a_pagar			float;
	p_modif_date					timestamp;
	p_campaign_tmp					VARCHAR2(10);
    p_full_campaign					VARCHAR2(10);

    P_ERROR_FLAG                    VARCHAR2(500);
    P_ERROR_CODE                    VARCHAR2(500);
    P_ERROR_MESSAGE                 VARCHAR2(500);

    --  Variables para órdenes iniciales
    p_DMSCurrentAmount				number(14,2);
	p_DMSPreviousAmount			    number(14,2);

    p_ScpiOrdAmount					number(14,2);
	p_ScpiCodAmount			        number(14,2);

    CURSOR c_Modifications IS
            SELECT SUBSTR(TO_CAMPAIGN,1,4) as campaign_year, SUBSTR(TO_CAMPAIGN,5,6) as campaign_number,
                   account, MODI_ID as clave_modi, TO_VAL as modif_monto_a_pagar, created_at, to_campaign
            FROM MODIS M
            WHERE processed_at IS NULL and STATUS LIKE '%45%'
            AND not exists (
                select 1 from MODIS M2
                where M2.TO_CAMPAIGN = M.TO_CAMPAIGN AND M2.TO_VAL = M.TO_VAL and M2.ACCOUNT = M.ACCOUNT
                and (M2.APPLIED_ORDER_NUMBER is not null)
            )
            --AND (TO_CAMPAIGN=201718 or TO_CAMPAIGN=201719) AND account in
            -- (SELECT account FROM REPRESENTATIVES R INNER JOIN ZONE Z ON
            -- Z.ZONE_ID=R.DEFAULT_ZONE WHERE Z.ZONE_ID=461) --- Solo para pruebas
            --AND (TO_CAMPAIGN=201718 or TO_CAMPAIGN=201719) AND account in
            -- (SELECT account FROM REPRESENTATIVES R INNER JOIN ZONE Z ON
            -- Z.ZONE_ID=R.DEFAULT_ZONE WHERE Z.ZONE_ID=12) --- Solo para pruebas, zona 12 de Xalapa
            order by to_campaign,account, created_at;
    BEGIN
        P_ERROR_FLAG := 'N';
            
        OPEN c_Modifications;
        LOOP
          FETCH c_Modifications into p_campaign_year, p_campaign_number, p_account, p_modif_seq, p_modif_monto_a_pagar, p_modif_date, p_campaign_tmp;
          EXIT WHEN c_Modifications%notfound;
            dbms_output.put_line(p_campaign_tmp);
            dbms_output.put_line(p_account);
      
            --WHILE p_p_FETCH_STATUS = 0
            --LOOP        
                p_default_zone := NULL ;
                p_full_campaign := NULL ;
                p_MontoACobrarAnterior := NULL ;
                p_MontoACobrar := NULL ;

                SELECT account, default_zone INTO p_account, p_default_zone FROM representatives WHERE account = p_account ;
                
                p_full_campaign := p_campaign_tmp ;
                
                SELECT count (so.order_id) INTO p_TotalOrdenes
                FROM scpi_order_headers so
                INNER JOIN modis m ON so.account = m.account
                WHERE so.full_campaign = p_full_campaign 
                AND   so.account = p_account ;
                  

                -- Evaluamos si existen ordenes en DMS para la Repre en campaña que se recibe modificación
                --PRINT 'Modificación obtenidad : '  +  p_Modif_seq + ' - $' + convert(VARCHAR2,p_modif_monto_a_pagar) + ' ,para aplicar en orden de Repre: ' + p_account + ' en campaña:' + p_campaign_tmp
                IF (p_TotalOrdenes >0 )
                    THEN
                        -------------------------------------------------------------------------------------------------------------
                        -- Obtener la 1er o única orden que pudiera tener la Repre en una misma campaña - 
                        -------------------------------------------------------------------------------------------------------------
                        dbms_output.put_line('In 01');
                  
                        SELECT o.ORDER_ID, m.MODI_ID
                        INTO p_id_order, p_orden
                        FROM orders o, scpi_order_headers so, modis m
                        WHERE o.order_id = so.order_id
                        AND so.account = m.account 
                        AND so.full_campaign = p_full_campaign 
                        AND m.account = p_account 
                        AND m.modi_id = p_modif_seq
                        AND rownum < 2
                        ORDER BY o.UPDATED_AT DESC;

              

                        SELECT o.CURRENT_AMOUNT, o.PREVIOUS_AMOUNT
                        INTO p_MontoACobrar, p_MontoACobrarAnterior
                        FROM orders o WHERE o.order_id = p_id_order
                        ORDER BY o.UPDATED_AT DESC;


                        SELECT ors.CURRENT_AMOUNT , ors.PREVIOUS_AMOUNT, oh.COD_AMOUNT, oh.ORD_AMOUNT
                        INTO p_DMSCurrentAmount, p_DMSPreviousAmount, p_ScpiCodAmount, p_ScpiOrdAmount
                        from scpi_order_headers oh
                        inner join orders ors on ors.ORDER_ID = oh.ORDER_ID
                        where oh.FULL_CAMPAIGN = p_full_campaign 
                        and ors.order_id = p_id_order
                        ;

                            IF (p_modif_monto_a_pagar >= 0 and  p_modif_monto_a_pagar < 1 )
                             THEN
                                p_MontoACobrarNuevo := 0;
                            --	PRINT 'ID de orden:' + convert(VARCHAR2,p_id_order) + ', Clave orden:' +  convert(VARCHAR2,p_orden) + ', Monto a cobrar en orden: ' + convert(VARCHAR2,p_MontoACobrar) + ', Monto a cobrar original en orden: ' + convert(VARCHAR2,p_MontoACobrarAnterior) + ' actualizar monto a cobrar en orden por:' +  convert(VARCHAR2,p_MontoACobrarNuevo) 
                            ELSE
                                p_MontoACobrarNuevo := p_modif_monto_a_pagar;
                            --	PRINT 'ID de orden:' + convert(VARCHAR2,p_id_order) + ', Clave orden:' +  convert(VARCHAR2,p_orden) + ', Monto a cobrar en orden: ' + convert(VARCHAR2,p_MontoACobrar) + ', Monto a cobrar original en orden: ' + convert(VARCHAR2,p_MontoACobrarAnterior) + ' actualizar monto a cobrar en orden por:' +  convert(VARCHAR2,p_MontoACobrarNuevo) 
                             END IF;
                            --PRINT '============================================================================================================================================'					
                            SELECT sysdate INTO p_process_date FROM DUAL;
-------------------------------------------------------------------------------------------------------------
					-- Actualizamos el monto a cobrar reciente en una o más ordenes que pudiera tener la Repre en una misma campaña - En PROD llegó a presentarse que una Repre tenía dos ordenes en una misma campaña.
					------------------------------------------------------------------------------------------------------------
					-- Incluir la condición para validar que sea la primer orden
                    --IF ( p_ScpiOrdAmount=p_DMSCurrentAmount AND p_ScpiCodAmount=p_DMSPreviousAmount ) THEN
                    --    UPDATE orders 
                    --    SET current_amount = p_MontoACobrarNuevo, updated_at = p_process_date, transfer_flag = 'E'
                    --    WHERE order_id = p_id_order;
                    --    COMMIT;

                    --ELSE
                        UPDATE orders 
                        SET current_amount = p_MontoACobrarNuevo,
                            previous_amount = p_MontoACobrar, 
                            updated_at = p_process_date, transfer_flag = 'E',
                            UPDATED_BY = 'MODIS',
                            PAYMENTS_COUNT = (NVL(PAYMENTS_COUNT,0) + 1)
                        WHERE order_id = p_id_order;
                        COMMIT;
                        
                    dbms_output.put_line('In 02');
                    dbms_output.put_line(p_modif_monto_a_pagar);
                    dbms_output.put_line(to_char(p_full_campaign ||' ' ||p_account || ' ' || p_TotalOrdenes));


                     --END IF;

					-------------------------------------------------------------------------------------------------------------
					-- Actualizamos en monto previo en catálogo de Representante -- se obtuvo del sp "SP_Actualiza_Orden " que desarrollo DW y respeto la actualización considerando el monto nuevo a cobrar
					------------------------------------------------------------------------------------------------------------
					-- Los campos en DMS están en ORDERS
                    --UPDATE representatives SET MONTO_PREVIO=p_MontoACobrarNuevo, FECHA_ACTUALIZADO = p_process_date, USUARIO_ACTUALIZA = 'IT-AplicaModif'
					--WHERE ID_REPRESENTANTE = p_id_representante

					-------------------------------------------------------------------------------------------------------------
					-- Se coloca el monto a cobrar reciente para que la ruta correspondiente que anda en reparto lo tome a traves de 
					-- del consumo de un ws obtenga de esta tabla la actualización del monto a cobrar. - Query obtenido del SP_Actualiza_Orden.
					------------------------------------------------------------------------------------------------------------
					--INSERT INTO MODIS (ACCOUNT, MODI_ID, APPLIED_ORDER_NUMBER, PROCESSED_AT)
					--VALUES (p_account, p_modi_id, p_id_order, p_process_date);

					-------------------------------------------------------------------------------------------------------------
					-- Marcamos modificación como aplicado, relacionando la orden a la q se aplico y si fue más de una orden se coloca el total
					------------------------------------------------------------------------------------------------------------
					UPDATE modis
					SET processed_at = p_process_date, applied_order_number = to_char(p_id_order), applied_order_quantity = p_TotalOrdenes
					WHERE modi_id = p_orden AND to_campaign = p_campaign_tmp AND account = p_account AND created_at = p_modif_date AND STATUS = '45-Aceptada por BIDS'; 
                    COMMIT;

       	ELSE 
					--PRINT 'No existe orden con ID de campaña:' + convert(VARCHAR2,p_id_campania) + ' y ID Repre: ' + convert(VARCHAR2,p_id_representante) + ' para aplicar modi- Ver si es conveniente ponerlo en bitacora' 
				   	UPDATE MODIS
					SET applied_order_number = 'No se encontro orden en camapaña:' || to_char(p_campaign_tmp)
					WHERE to_campaign = to_number(p_campaign_tmp) and account = p_account and created_at = p_modif_date and STATUS = '45-Aceptada por BIDS';
                    COMMIT;

             END IF;
         --END LOOP;

       END LOOP;

        close c_Modifications;   

        EXCEPTION
             WHEN OTHERS THEN
             ROLLBACK;
             P_ERROR_CODE := SQLCODE;
             P_ERROR_MESSAGE := concat( concat( SQLERRM, '  '), dbms_utility.format_error_backtrace() ); 
             P_ERROR_FLAG := 'Y';

    END sp_update_mtto_cobrar_en_orden;
/

