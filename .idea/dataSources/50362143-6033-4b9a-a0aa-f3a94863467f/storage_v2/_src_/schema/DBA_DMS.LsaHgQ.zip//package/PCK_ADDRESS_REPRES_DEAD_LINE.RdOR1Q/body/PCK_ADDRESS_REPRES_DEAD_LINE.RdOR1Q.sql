create PACKAGE BODY         PCK_ADDRESS_REPRES_DEAD_LINE
AS
    FUNCTION FN_ADDRESS_REPRES_DEAD_LINE (P_ZONE NUMBER)
        RETURN SYS_REFCURSOR
    AS
        V_ZONE                     NUMBER (4) := P_ZONE;

        TYPE TYP_REF_CUR IS REF CURSOR;

        V_REF_CUR                  TYP_REF_CUR;
        V_FULL_CAMPAIGN            NUMBER (8);
        V_COUNT_CAMPAIGN           NUMBER (2);
        V_COUNT_ZONE_CAMPAIGN      NUMBER (2);
        V_COUNT_ZONE_ON_DEADLINE   NUMBER (2);
        V_TOTAL_DAYS_INI           NUMBER (2) := 2;
        V_TOTAL_DAYS_END           NUMBER (2) := 4;
    BEGIN
        --- VALIDA QUE EXISTAN DATOS EN CAMPAIGN
        SELECT COUNT (*)
          INTO V_COUNT_CAMPAIGN
          FROM CAMPAIGNS
         WHERE     CURRENT_TIMESTAMP BETWEEN START_DATE AND END_DATE
               AND CAMPAIGN BETWEEN 1 AND 20;

        ---- SETEA CAMPAÑA CURRENT
        SELECT (CAMPAIGN_YEAR * 100 + CAMPAIGN)
          INTO V_FULL_CAMPAIGN
          FROM CAMPAIGNS
         WHERE     CURRENT_TIMESTAMP BETWEEN START_DATE AND END_DATE
               AND CAMPAIGN BETWEEN 1 AND 20;

        ---- VALIDA  QUE EXISTAN DATOS EN ZONE_CAMPAIGN
        SELECT COUNT (*)
          INTO V_COUNT_ZONE_CAMPAIGN
          FROM DBA_DMS.zone_campaigns
         WHERE zone = V_ZONE AND FULL_CAMPAIGN = V_FULL_CAMPAIGN;

        IF V_COUNT_ZONE_CAMPAIGN > 0 AND V_COUNT_CAMPAIGN > 0
        THEN                                          --- ESTA EN SU DEAD LINE
            SELECT COUNT (*)
              INTO V_COUNT_ZONE_ON_DEADLINE
              FROM DBA_DMS.zone_campaigns
             WHERE     zone = V_ZONE
                      AND  full_campaign = (select (CAMPAIGN_YEAR*100+CAMPAIGN) 
        from CAMPAIGNS where current_timestamp between START_DATE and END_DATE and CAMPAIGN between 1 and 20)
         AND  TRUNC (billed_at+V_TOTAL_DAYS_END) >= TRUNC (SYSDATE); --- YA FACTURÓ
            IF V_COUNT_ZONE_ON_DEADLINE > 0
            THEN                                 --- PONLE LA CAMPAÑA ANTERIOR
                SELECT FULL_CAMPAIGN
                  INTO V_FULL_CAMPAIGN
                  FROM DBA_DMS.zone_campaigns
                 WHERE     zone = V_ZONE
                     AND  full_campaign = (select (CAMPAIGN_YEAR*100+CAMPAIGN) 
        from CAMPAIGNS where current_timestamp between START_DATE and END_DATE and CAMPAIGN between 1 and 20)
         AND  TRUNC (billed_at+V_TOTAL_DAYS_END) >= TRUNC (SYSDATE); --- YA FACTURÓ
                OPEN V_REF_CUR FOR
                    SELECT TO_CHAR (billed_at - V_TOTAL_DAYS_INI,
                                    'DD/MM/YYYY')    AS START_DEADLINE, --- 1 DÍA ANTES DE LA FACTURA
                          -- TO_CHAR (FIRST_ATTEMPT_AT + V_TOTAL_DAYS_END,  'DD/MM/YYYY')    AS END_DEADLINE, --- DOS DÍAS DESÚES DEL PRIMER REPARTO SE CAMBIA POR SOLICITUD DE NEGOCIO
                          TO_CHAR (billed_at + V_TOTAL_DAYS_END,  'DD/MM/YYYY')    AS END_DEADLINE, --- CUATRO DÍAS DESPUÉS DE LA FACTURA
                           FULL_CAMPAIGN
                      FROM DBA_DMS.zone_campaigns
                     WHERE zone = V_ZONE AND FULL_CAMPAIGN = V_FULL_CAMPAIGN;

                RETURN V_REF_CUR;
            ELSE ---- SI YA PASÓ SU DEAD LINE, BUSCA LOS DATOS CON LA SIGUIENTE CAMPAÑA LA SIGUIENTE CAMPAÑA
                OPEN V_REF_CUR FOR
                    SELECT TO_CHAR (MIN(billed_at) - V_TOTAL_DAYS_INI,
                                    'DD/MM/YYYY')    AS START_DEADLINE, --- 1 DÍA ANTES DE LA FACTURA
                             -- TO_CHAR (FIRST_ATTEMPT_AT + V_TOTAL_DAYS_END,  'DD/MM/YYYY')    AS END_DEADLINE, --- DOS DÍAS DESÚES DEL PRIMER REPARTO SE CAMBIA POR SOLICITUD DE NEGOCIO
                          TO_CHAR (billed_at + V_TOTAL_DAYS_END,  'DD/MM/YYYY')    AS END_DEADLINE, --- CUATRO DÍAS DESPUÉS DE LA FACTURA
                           FULL_CAMPAIGN
                      FROM DBA_DMS.zone_campaigns
                     WHERE zone = V_ZONE --AND FULL_CAMPAIGN = V_FULL_CAMPAIGN
                     AND TRUNC (billed_at) >= TRUNC (SYSDATE)
                     AND ROWNUM = 1
                     GROUP BY billed_at, --FIRST_ATTEMPT_AT,
                     FULL_CAMPAIGN, ZONE;

                RETURN V_REF_CUR;
            END IF;
        ELSE
            OPEN V_REF_CUR FOR
                SELECT '00/00/0000'     START_DEADLINE,
                       '00/00/0000'     AS END_DEADLINE,
                       0                AS FULL_CAMPAIGN
                  FROM DUAL;

            RETURN V_REF_CUR;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            OPEN V_REF_CUR FOR
                SELECT '00/00/0000'     START_DEADLINE,
                       '00/00/0000'     AS END_DEADLINE,
                       0                AS FULL_CAMPAIGN
                  FROM DUAL;


            RETURN V_REF_CUR;
    END FN_ADDRESS_REPRES_DEAD_LINE;


    FUNCTION FN_NR_ADDRESS_REPRES (P_ACCOUNT NUMBER, P_FULLCAMPAIGN NUMBER)
        RETURN NUMBER
    AS
        V_NR   NUMBER (2);
    BEGIN
        SELECT DECODE (NR, 1, '-99')
          INTO V_NR
          FROM REPRES_ADDRESS
         WHERE     NR = 1
               AND ACCOUNT = P_ACCOUNT
               AND NR_CAMPAIGN = P_FULLCAMPAIGN;

        RETURN V_NR;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            V_NR := NULL;
            RETURN V_NR;
    END FN_NR_ADDRESS_REPRES;

END PCK_ADDRESS_REPRES_DEAD_LINE;
/

