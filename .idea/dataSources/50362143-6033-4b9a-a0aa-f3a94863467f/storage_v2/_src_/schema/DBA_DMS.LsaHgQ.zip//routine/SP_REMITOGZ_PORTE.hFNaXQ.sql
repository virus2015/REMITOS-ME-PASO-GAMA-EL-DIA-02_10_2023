create PROCEDURE         SP_REMITOGZ_PORTE (
   pi_campaign   IN     NUMBER,
   pi_Ruta       IN     NUMBER,
   pi_Account    IN     NUMBER,
   pi_Zona       IN     NUMBER,
   pi_ldc        IN     VARCHAR2,
   RemitoGZ_CP      OUT SYS_REFCURSOR)
AS
   cSqlRemito     VARCHAR2 (4000);
   cSqlGroup      VARCHAR2 (4000);
   cSqlMisGz      VARCHAR2 (4000);
   vSql           VARCHAR2 (4000);
   vCondicion     VARCHAR2 (2000);
   vCondicionGZ   VARCHAR2 (2000);
   
campaign       REMITO_HEADER.CAMPAIGN%TYPE;

BEGIN
   cSqlRemito :=
         ' SELECT X.LDC_ID LDC, '
      || 'UPPER (X.LOCATION_NAME) POBLACION_LDC, '
      || 'RP.DEFAULT_ZONE AS ZONA, '
      || 'NVL (RP.ROUTE, 0) RUTA, '
      || 'RP.RFC, '
      || 'RP.ACCOUNT, '
      || 'RP.ACCOUNT_NAME NOMBRE, '
      || 'NVL (RP.ADDRESS1, ''-'') || '' '' || NVL (RP.ADDRESS2, ''-'') DOMICILIO, '
      || 'RP.ZIP CP, '
      || 'NVL (RP.MUNICIPALITY, ''-'') MUNICIPIO, '
      || 'RP.STATE_NAME ESTADO, '
      || '''MÉXICO'' PAIS, '
      || 'RE.TAX_CATEGORY AS CODIGO_SAT, '
      || 'RE.FSC CODIGO_AVON, '
      || 'RE.LINE_NUMBER, '
      || 'RE.DESCRIPTION DESCRIPCION, '
      || 'NVL (RE.PRODUCTS_NUM, 1) CANTIDAD, '
      || '''H87'' CLAVE_UNIDAD_MEDIDA, '
      || '''PZA'' UNIDAD_MEDIDA, '
      || 'TO_NUMBER (SUBSTR (MAX (TI.WEIGHT) / 1000, 1, 8)) PESO_UNITARIO, '
      || 'TO_NUMBER (SUBSTR ( (MAX (TI.WEIGHT) / 1000) * RE.PRODUCTS_NUM, 1, 8)) PESO_TOTAL, '
      || '''MX'' MONEDA, '
      || '(RE.PRICE * RE.PRODUCTS_NUM) PRECIO_TOTAL, '
      || '''FACTURADOS'' TIPO_DE_ARTICULO '
      || ' FROM DBA_SCPI.REMITO_HEADER RH, '
      || ' DBA_SCPI.REMITO RE, '
      || ' REPRESENTATIVES RP, '
      || ' DBA_SCPI.ITEM_DATA TI, '
      || ' DBA_DMS.LDC X, '
      || ' DBA_DMS.ZONE_CAMPAIGNS Z '
      || ' WHERE     RH.ID_REMITO_HEADER = RE.ID_REMITO_HEADER '
      || '  AND RH.ACCOUNT = RP.ACCOUNT '
      || '  AND RE.FSC = TI.FSC '
      || '  AND RE.LINE_NUMBER = TI.LINNO '
      || '  AND X.LDC_ID = Z.LDW_CODE '
      || '  AND RH.ZONE = Z.ZONE '
      || '  AND RH.CAMPAIGN = TO_CHAR (Z.CAMPAIGN_YEAR || LPAD (Z.CAMPAIGN, 2, 0)) '
      || '  AND RH.CAMPAIGN = '
      || pi_campaign
      || 'AND ROWNUM =1';
   cSqlGroup :=
         '  GROUP BY RH.CAMPAIGN, '
      || 'X.LDC_ID, '
      || 'X.LOCATION_NAME, '
      || 'RP.DEFAULT_ZONE, '
      || 'RP.ROUTE, '
      || 'RP.RFC, '
      || 'RP.ACCOUNT, '
      || 'RP.ACCOUNT_NAME, '
      || 'RP.ADDRESS1, '
      || 'RP.ADDRESS2, '
      || 'RP.ZIP, '
      || 'RP.MUNICIPALITY, '
      || 'RP.STATE_NAME, '
      || 'RE.TAX_CATEGORY, '
      || 'RE.FSC, '
      || 'RE.LINE_NUMBER, '
      || 'RE.DESCRIPTION, '
      || 'RE.PRODUCTS_NUM, '
      || 'RE.PRICE ';
   cSqlMisGz :=
         '  UNION ALL '
      || ' SELECT X.LDC_ID AS LDC, '
      || ' UPPER (X.LOCATION_NAME) POBLACION_LDC, '
      || ' GZ.ZONE AS ZONA, '
      || ' NVL (RP.ROUTE, 0) RUTA, '
      || ' RP.RFC, '
      || ' GZ.ACCOUNT, '
      || ' RP.ACCOUNT_NAME NOMBRE, '
      || ' NVL (RP.ADDRESS1, ''-'') || '' '' || NVL (RP.ADDRESS2, ''-'') DOMICILIO, '
      || ' RP.ZIP CP, '
      || ' NVL (RP.MUNICIPALITY, ''-'') MUNICIPIO, '
      || ' RP.STATE_NAME ESTADO, '
      || '''MÉXICO'' PAIS, '
      || ' GZ.TAX_CATEGORY AS CODIGO_SAT, '
      || ' GZ.FSC AS CODIGO_AVON, '
      || ''' '' LINE_NUMBER, '
      || 'GZ.PRODUCT_DESC AS DESCRIPCION, '
      || 'GZ.PIECES AS CANTIDAD, '
      || '''H87'' AS CLAVE_UNIDAD_MEDIDA, '
      || '''PZA'' AS UNIDAD_MEDIDA, '
      || '0 AS PESO_UNITARIO, '
      || '0 AS PESO_TOTAL, '
      || '''MX'' AS MONEDA, '
      || '0 AS TOTAL, '
      || '''MISCELANEOS'' AS TIPO_ARTICULO '
      || ' FROM MISCELLANEOUS_GZ GZ, '
      || ' DBA_DMS.LDC X, '
      || ' DBA_DMS.ZONE_CAMPAIGNS Z, '
      || ' REPRESENTATIVES RP '
      || ' WHERE     GZ.FULL_CAMPAIGN = Z.FULL_CAMPAIGN '
      || ' AND GZ.ACCOUNT = RP.ACCOUNT '
      || ' AND GZ.ZONE = Z.ZONE '
      || ' AND X.LDC_ID = Z.LDW_CODE '
      || ' AND GZ.shipping_type = 2 '
      || ' AND GZ.FULL_CAMPAIGN = '
      || pi_campaign
      || 'AND ROWNUM =1';

   BEGIN
      vCondicion := NULL;


      vSql := cSqlRemito || cSqlGroup || cSqlMisGz;

      IF pi_Ruta IS NOT NULL
      THEN
         vCondicion := ' AND RP.ROUTE = ' || pi_Ruta;
         vSql :=
            cSqlRemito || vCondicion || cSqlGroup || cSqlMisGz || vCondicion;
      END IF;

      IF pi_Account IS NOT NULL
      THEN
         vCondicion := vCondicion || ' AND RP.ACCOUNT = ' || pi_Account;
         vSql :=
            cSqlRemito || vCondicion || cSqlGroup || cSqlMisGz || vCondicion;
      END IF;

      IF pi_ldc IS NOT NULL
      THEN
         vCondicion := vCondicion || ' AND X.LDC_ID = '''||pi_ldc||''' ';
         vSql :=
            cSqlRemito || vCondicion || cSqlGroup || cSqlMisGz || vCondicion;
      END IF;

      IF pi_Zona IS NOT NULL
      THEN
         vCondicion := vCondicion || ' AND RH.ZONE = ' || pi_Zona;
         vCondicionGZ := vCondicion || ' AND GZ.ZONE = ' || pi_Zona;
         vSql :=
               cSqlRemito
            || vCondicion
            || cSqlGroup
            || cSqlMisGz
            || vCondicionGZ;
      END IF;


  END;
  
   OPEN RemitoGZ_CP FOR vSql;
   
    FETCH RemitoGZ_CP INTO campaign; 
   
 LOOP

    if RemitoGZ_CP%notfound then
      EXIT            ;
      end if;

    END LOOP;
    CLOSE RemitoGZ_CP;

EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (SQLERRM);
END SP_REMITOGZ_PORTE;
/

