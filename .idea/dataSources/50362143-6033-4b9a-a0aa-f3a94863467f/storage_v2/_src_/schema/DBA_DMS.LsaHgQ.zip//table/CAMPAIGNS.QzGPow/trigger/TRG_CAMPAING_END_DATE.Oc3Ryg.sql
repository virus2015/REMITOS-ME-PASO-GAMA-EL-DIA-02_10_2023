create trigger TRG_CAMPAING_END_DATE
    before insert or update
    on CAMPAIGNS
    for each row
    when (TRUNC(new.END_DATE) = new.END_DATE)
BEGIN
    :new.END_DATE := :new.END_DATE + 86399/86400;
END;
/

