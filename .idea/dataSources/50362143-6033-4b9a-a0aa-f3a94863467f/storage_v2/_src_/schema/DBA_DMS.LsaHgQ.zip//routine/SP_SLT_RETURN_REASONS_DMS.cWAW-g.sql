create PROCEDURE SP_SLT_RETURN_REASONS_DMS (
    reasonsDMS OUT SYS_REFCURSOR
)
AS

    v_last_id_processed number := 0;


BEGIN



    SELECT LONG_VALUE
      INTO v_last_id_processed  
      FROM PARAMETERS
    WHERE ID = 17;

    OPEN reasonsDMS FOR

                SELECT  rr.REASON_ID, rr.DESCRIPTION, rr.LASTUPD_TS
                FROM    RETURN_REASONS rr
                WHERE   rr.REASON_ID >  v_last_id_processed
                ORDER   BY rr.REASON_ID ASC;


END SP_SLT_RETURN_REASONS_DMS;
/

