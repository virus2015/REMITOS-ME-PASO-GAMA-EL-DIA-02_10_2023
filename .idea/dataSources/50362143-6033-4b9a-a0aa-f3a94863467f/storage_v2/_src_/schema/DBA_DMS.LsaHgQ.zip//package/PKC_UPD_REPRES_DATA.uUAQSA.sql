create PACKAGE         PKC_UPD_REPRES_DATA
AS
    /******************************************************************************
       NAME:       PKC_UPD_REPRES_DATA
       PURPOSE:    ACTUALIZA LOS DATOS DE LAS REPRESENTANTES EN LA TABLA SCPI_ORDER_HEADER
                   CON LOS DATOS DE LA TABLA DE REPRESENTANTES

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        29/11/2021      Rossana Reyes       1. Created this package.
    ******************************************************************************/
    TYPE CUR_TYPE  IS REF CURSOR;
   -- FUNCTION FN_STRING_TYPE (P_DATES VARCHAR2)
   -- RETURN DBA_DMS.PKC_UPD_REPRES_DATA.CUR_TYPE;

    PROCEDURE SP_UPD_REPRES_DATA (P_DATE            IN     VARCHAR2, --- fechas, sepadas por comas DD/MM/YYYY
                                  P_ERROR_FLAG         OUT VARCHAR2, ---N sin error, S error
                                  P_ERROR_CODE         OUT VARCHAR2, --- SQLCODE
                                  P_ERROR_MESSAGE      OUT VARCHAR2, --- mensaje del error Oracle
                                  P_TOTAL_UPDATE       OUT NUMBER, --- total de datos a procesar
                                  P_REAL_UPDATE        OUT NUMBER) --- total de datos procesados
                                                                  ;
END PKC_UPD_REPRES_DATA;
/

