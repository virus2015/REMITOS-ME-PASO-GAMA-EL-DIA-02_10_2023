create PACKAGE BODY PCK_LDC_REPORT AS

  PROCEDURE SP_SEL_LDC_REPORT  ( P_OPC             IN NUMBER, -- Consulta por
                                 P_FULL_CAMPAIGN   IN NUMBER, -- full campaign 
                                 P_ZONE            IN NUMBER, ---  enviar con full campaign,P_LDC  P_OPC = 1
                                 P_ACCOUNT         IN NUMBER,--- enviar con full campaign, P_OPC = 4
                                 P_ROUTE           IN NUMBER,--- enviar con full campaign,P_LDC, P_ZONE, P_ROUTE P_OPC = 3
                                 P_LDC             IN VARCHAR2,--- enviar con full campaign,P_LDC y P_ZONE P_OPC = 2
                                 P_TRUCKNUMBER     IN VARCHAR2,
                                 P_ERROR_CODE      OUT VARCHAR2,
                                 P_ERROR_MESSAGE   OUT VARCHAR2,
                                 CUR_REPORT         OUT SYS_REFCURSOR                                       
) AS
               V_OPC              NUMBER (2)  :=    P_OPC; 
               V_FULL_CAMPAIGN    NUMBER (6)  :=    P_FULL_CAMPAIGN;  
               V_ZONE             NUMBER (4)   :=   P_ZONE;
               V_ACCOUNT          NUMBER (18)  :=   P_ACCOUNT;
               V_ROUTE            NUMBER (6) :=   P_ROUTE;
               V_LDC              VARCHAR2 (3 CHAR)  :=  P_LDC;
               V_TRUCKNUMBER      VARCHAR2 (40) :=   P_TRUCKNUMBER;
  BEGIN
    CASE V_OPC
    WHEN 1 ----- CONSULTA POR PORTEO Y CAMPAÑA
    THEN 
    OPEN CUR_REPORT FOR
    SELECT T.*,
                             ROW_NUMBER ()
                                 OVER (ORDER BY T.RUTA, ACCOUNT, CODIGO_AVON)    AS NUM_PAGINADO
                        FROM (SELECT order_id,
                                     P.FULL_CAMPAIGN
                                         AS FULL_CAMPAIGN,
                                    TRIM( L.LDC_ID)
                                         AS LDC,
                                     UPPER (LOCATION_NAME)
                                         AS POBLACION_LDC,
                                     P.ZONE
                                         AS ZONA,
                                     NVL (R.ROUTE, 0)
                                         AS RUTA,
                                     R.ACCOUNT,
                                     R.ACCOUNT_NAME
                                         AS NOMBRE,
                                     R.RFC,
                                     NVL (R.ADDRESS1, '-')
                                         AS CALLE_NUM,
                                     NVL (R.ADDRESS2, '-')
                                         AS COLONIA,
                                     R.ZIP
                                         AS CP,
                                     NVL (R.MUNICIPALITY, '-')
                                         AS MUNICIPIO,
                                     R.STATE_NAME
                                         AS ESTADO,
                                     'MÉXICO'
                                         AS PAIS,
                                     'MEXICANA'
                                         AS NACIONALIDAD,
                                     CASE PACKAGE_TYPE
                                         WHEN 'H'
                                         THEN
                                             DECODE (
                                                 P.TAX_CATEGORY,
                                                 0, (SELECT STRING_VALUE
                                                       FROM dba_dms.parameters
                                                      WHERE id = 30),
                                                 NULL, (SELECT STRING_VALUE
                                                          FROM dba_dms.parameters
                                                         WHERE id = 30),
                                                 P.TAX_CATEGORY)
                                         ELSE
                                             DECODE (
                                                 P.TAX_CATEGORY,
                                                 0, (SELECT STRING_VALUE
                                                       FROM dba_dms.parameters
                                                      WHERE id = 33),
                                                 NULL, (SELECT STRING_VALUE
                                                          FROM dba_dms.parameters
                                                         WHERE id = 33),
                                                 P.TAX_CATEGORY)
                                     END
                                         AS CODIGO_SAT,
                                     CODIGO_AVON,
                                     DESCRIPCION,
                                     NVL (CANTIDAD, 1)
                                         AS CANTIDAD,
                                     'H87'
                                         AS CLAVE_UNIDAD_MEDIDA,
                                     'PZA'
                                         AS UNIDAD_MEDIDA,
                                     PIECES_PER_BOX
                                         AS PIEZAS_CAJA,
                                     COSMETICS_PER_BOX
                                         AS PIEZAS_COSMETICOS,
                                     ROUND (PESO_INDIVIDUAL, 1)
                                         AS PESO_INDIVIDUAL,
                                     ROUND (PESO_INDIVIDUAL * CANTIDAD, 1)
                                         AS PESO_TOTAL,
                                     PACKAGE_COST
                                         AS PRECIO_CATALOGO,
                                     'MX'
                                         AS MONEDA,
                                     (PACKAGE_COST * NVL (CANTIDAD, 1))
                                         AS TOTAL,
                                     'FACTURADO'
                                         AS TIPO_ARTICULO
                                FROM (  SELECT OD.ORDER_ID,
                                               OD.FULL_CAMPAIGN,
                                               OD.ZONE,
                                               OD.ACCOUNT,
                                               TAX_CATEGORY,
                                               PK.WEIGHT,
                                               PT.CURRENT_WEIGHT,
                                               PK.PACKAGE_TYPE,
                                               NVL (CS.DESCRIPTION,
                                                    'CAJA COSMÉTICOS')
                                                   AS DESCRIPCION,
                                               DECODE (COUNT (*),
                                                       0, 1,
                                                       COUNT (*))
                                                   AS CANTIDAD,
                                               'H87'
                                                   AS CLAVE_UNIDAD_MEDIDA,
                                               'PZA'
                                                   AS UNIDAD_MEDIDA,
                                               NVL (TO_CHAR (PIECES_PER_BOX),
                                                    'N/A')
                                                   AS PIECES_PER_BOX,
                                               NVL (TO_CHAR (COSMETICS_PER_BOX),
                                                    'N/A')
                                                   AS COSMETICS_PER_BOX,
                                               (DECODE (
                                                    PK.PACKAGE_TYPE,
                                                    'H', (PK.WEIGHT / 1000000), --unitarios
                                                    (  (  PT.CURRENT_WEIGHT
                                                        + (SELECT TO_NUMBER (
                                                                      LONG_VALUE)
                                                             FROM PARAMETERS
                                                            WHERE ID = 31))
                                                     / 1000)))
                                                   AS PESO_INDIVIDUAL,
                                               PK.PACKAGE_COST,
                                               DECODE (PK.PACKAGE_TYPE,
                                                       'H', CS.FSC,
                                                       BARCODE)
                                                   AS CODIGO_AVON
                                          FROM DBA_DMS.PACKAGES PK
                                               INNER JOIN
                                               DBA_DMS.SCPI_ORDER_HEADERS OD
                                                   ON OD.ORDER_ID = PK.ORDER_ID
                                               LEFT JOIN ITEMS CS
                                                   ON     PK.ORDER_ID =
                                                          CS.ORDER_ID
                                                      AND CS.PACKAGE_ID =
                                                          PK.PACKAGE_ID
                                               LEFT JOIN
                                               DBA_DMS.PACKAGE_TOTALS PT
                                                   ON (    PT.ORDER_ID =
                                                           PK.ORDER_ID
                                                       AND PT.PACKAGE_ID =
                                                           PK.PACKAGE_ID
                                                       AND PK.PACKAGE_TYPE != 'H')
                                         WHERE     ORDER_NUMBER IS NOT NULL
                                               AND PK.SHORTED IS NULL --- SACA SHORTS
                                               AND OD.FULL_CAMPAIGN =
                                                   V_FULL_CAMPAIGN
                                               AND PK.ORDER_ID NOT IN
                                                       (SELECT S.ORDER_ID
                                                          FROM orders_statuses S
                                                         WHERE S.STATUS = 15) --- DISCRIMINAR ESTATUS = 15 Cancelada
                                      GROUP BY OD.ORDER_ID,
                                               PK.PACKAGE_COST,
                                               CS.TAX_CATEGORY,
                                               PIECES_PER_BOX,
                                               COSMETICS_PER_BOX,
                                               PK.PACKAGE_TYPE,
                                               CS.FSC,
                                               PK.WEIGHT,
                                               PT.CURRENT_WEIGHT,
                                               PK.PACKAGE_TYPE,
                                               CS.DESCRIPTION,
                                               OD.FULL_CAMPAIGN,
                                               OD.ZONE,
                                               OD.ACCOUNT,
                                               DECODE (PK.PACKAGE_TYPE,
                                                       'H', CS.FSC,
                                                       BARCODE)) P
                                     INNER JOIN REPRESENTATIVES R
                                         ON P.ACCOUNT = R.ACCOUNT
                                     INNER JOIN
                                     (  SELECT Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               TRIM (LDC.LDC_ID) AS LDC_ID,
                                               LDC.LOCATION_NAME
                                          FROM DBA_DMS.ZONE_CAMPAIGNS Z
                                               INNER JOIN DBA_DMS.LDC LDC
                                                   ON LDC.LDC_ID = Z.LDW_CODE
                                         WHERE    Z.CAMPAIGN_YEAR
                                               || LPAD (Z.CAMPAIGN, 2, 0) =
                                               V_FULL_CAMPAIGN ----- CAMBIO DE FULL CAMPAIGN
                                              --- AND TRIM (LDC.LDC_ID) = V_LDC
                                      GROUP BY Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               LDC.LDC_ID,
                                               LDC.LOCATION_NAME) L
                                         ON     L.ZONE = P.ZONE
                                            AND    L.CAMPAIGN_YEAR
                                                || LPAD (L.CAMPAIGN, 2, 0) =
                                                P.FULL_CAMPAIGN ----- CAMBIO DE FULL CAMPAIGN
                              UNION ALL
                              SELECT 0
                                         ORDER_ID,
                                     FULL_CAMPAIGN,
                                    L.LDC_ID
                                         AS LDC,
                                     UPPER (LOCATION_NAME)
                                         AS POBLACION_LDC,
                                     GZ.ZONE
                                         AS ZONA,
                                     R.ROUTE
                                         AS RUTA,
                                     GZ.ACCOUNT,
                                     ACCOUNT_NAME
                                         AS NOMBRE,
                                     R.RFC,
                                     NVL (R.ADDRESS1, '-')
                                         AS CALLE_NUM,
                                     NVL (R.ADDRESS2, '-')
                                         AS COLONIA,
                                     R.ZIP
                                         AS CP,
                                     NVL (R.MUNICIPALITY, '-')
                                         AS MUNICIPIO,
                                     R.STATE_NAME
                                         AS ESTADO,
                                     'MÉXICO'
                                         AS PAIS,
                                     'MEXICANA'
                                         AS NACIONALIDAD,
                                     TO_CHAR (TAX_CATEGORY)
                                         AS CODIGO_SAT,
                                     NVL (FSC, '-')
                                         AS CODIGO_AVON,
                                     PRODUCT_DESC
                                         AS DESCRIPCION,
                                     PIECES
                                         AS CANTIDAD,
                                     'H87'
                                         AS CLAVE_UNIDAD_MEDIDA,
                                     'PZA'
                                         AS UNIDAD_MEDIDA,
                                     'N/A'
                                         AS PIEZAS_CAJA,
                                     'N/A'
                                         AS PIEZAS_COSMETICOS,
                                     0
                                         AS PESO_INDIVIDUAL,
                                     0
                                         AS PESO_TOTAL,
                                     0
                                         AS PRECIO_CATALOGO,
                                     'MX'
                                         AS MONEDA,
                                     0
                                         AS TOTAL,
                                     'MISCELANEO'
                                         AS TIPO_ARTICULO
                                FROM DBA_DMS.MISCELLANEOUS_GZ GZ
                                     INNER JOIN DBA_DMS.REPRESENTATIVES R
                                         ON R.ACCOUNT = GZ.ACCOUNT
                                     INNER JOIN
                                     (  SELECT Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               TRIM (LDC.LDC_ID) AS LDC_ID,
                                               LDC.LOCATION_NAME,
                                                  Z.CAMPAIGN_YEAR
                                               || LPAD (Z.CAMPAIGN, 2, 0)    AS FULLCAMPAIGN
                                          FROM DBA_DMS.ZONE_CAMPAIGNS Z
                                               INNER JOIN DBA_DMS.LDC LDC
                                                   ON LDC.LDC_ID = Z.LDW_CODE
                                         WHERE    Z.CAMPAIGN_YEAR
                                               || LPAD (Z.CAMPAIGN, 2, 0) =
                                               V_FULL_CAMPAIGN ----- CAMBIO DE FULL CAMPAIGN
                                               -- AND TRIM (LDC.LDC_ID) = V_LDC
                                      GROUP BY Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               LDC.LDC_ID,
                                               LDC.LOCATION_NAME) L
                                         ON     GZ.ZONE = L.ZONE
                                            AND L.FULLCAMPAIGN =
                                                GZ.FULL_CAMPAIGN
                               WHERE     GZ.shipping_type = 1
                                     AND full_campaign = V_FULL_CAMPAIGN
                                     -- AND TRIM (LDC_ID) = V_LDC
                                                         ) T
                      WHERE  LDC = V_LDC ---- POR PORTEO
                    ORDER BY RUTA, ACCOUNT, CODIGO_AVON ASC;
--- POR FULL_CAMAPAIGN, LDC y ZONE P_OPC = 2

WHEN 2
THEN
OPEN CUR_REPORT FOR


 SELECT T.*,
                             ROW_NUMBER ()
                                 OVER (ORDER BY T.RUTA, ACCOUNT, CODIGO_AVON)    AS NUM_PAGINADO
                        FROM (SELECT order_id,
                                     P.FULL_CAMPAIGN
                                         AS FULL_CAMPAIGN,
                                    TRIM( L.LDC_ID)
                                         AS LDC,
                                     UPPER (LOCATION_NAME)
                                         AS POBLACION_LDC,
                                     P.ZONE
                                         AS ZONA,
                                     NVL (R.ROUTE, 0)
                                         AS RUTA,
                                     R.ACCOUNT,
                                     R.ACCOUNT_NAME
                                         AS NOMBRE,
                                     R.RFC,
                                     NVL (R.ADDRESS1, '-')
                                         AS CALLE_NUM,
                                     NVL (R.ADDRESS2, '-')
                                         AS COLONIA,
                                     R.ZIP
                                         AS CP,
                                     NVL (R.MUNICIPALITY, '-')
                                         AS MUNICIPIO,
                                     R.STATE_NAME
                                         AS ESTADO,
                                     'MÉXICO'
                                         AS PAIS,
                                     'MEXICANA'
                                         AS NACIONALIDAD,
                                     CASE PACKAGE_TYPE
                                         WHEN 'H'
                                         THEN
                                             DECODE (
                                                 P.TAX_CATEGORY,
                                                 0, (SELECT STRING_VALUE
                                                       FROM dba_dms.parameters
                                                      WHERE id = 30),
                                                 NULL, (SELECT STRING_VALUE
                                                          FROM dba_dms.parameters
                                                         WHERE id = 30),
                                                 P.TAX_CATEGORY)
                                         ELSE
                                             DECODE (
                                                 P.TAX_CATEGORY,
                                                 0, (SELECT STRING_VALUE
                                                       FROM dba_dms.parameters
                                                      WHERE id = 33),
                                                 NULL, (SELECT STRING_VALUE
                                                          FROM dba_dms.parameters
                                                         WHERE id = 33),
                                                 P.TAX_CATEGORY)
                                     END
                                         AS CODIGO_SAT,
                                     CODIGO_AVON,
                                     DESCRIPCION,
                                     NVL (CANTIDAD, 1)
                                         AS CANTIDAD,
                                     'H87'
                                         AS CLAVE_UNIDAD_MEDIDA,
                                     'PZA'
                                         AS UNIDAD_MEDIDA,
                                     PIECES_PER_BOX
                                         AS PIEZAS_CAJA,
                                     COSMETICS_PER_BOX
                                         AS PIEZAS_COSMETICOS,
                                     ROUND (PESO_INDIVIDUAL, 1)
                                         AS PESO_INDIVIDUAL,
                                     ROUND (PESO_INDIVIDUAL * CANTIDAD, 1)
                                         AS PESO_TOTAL,
                                     PACKAGE_COST
                                         AS PRECIO_CATALOGO,
                                     'MX'
                                         AS MONEDA,
                                     (PACKAGE_COST * NVL (CANTIDAD, 1))
                                         AS TOTAL,
                                     'FACTURADO'
                                         AS TIPO_ARTICULO
                                FROM (  SELECT OD.ORDER_ID,
                                               OD.FULL_CAMPAIGN,
                                               OD.ZONE,
                                               OD.ACCOUNT,
                                               TAX_CATEGORY,
                                               PK.WEIGHT,
                                               PT.CURRENT_WEIGHT,
                                               PK.PACKAGE_TYPE,
                                               NVL (CS.DESCRIPTION,
                                                    'CAJA COSMÉTICOS')
                                                   AS DESCRIPCION,
                                               DECODE (COUNT (*),
                                                       0, 1,
                                                       COUNT (*))
                                                   AS CANTIDAD,
                                               'H87'
                                                   AS CLAVE_UNIDAD_MEDIDA,
                                               'PZA'
                                                   AS UNIDAD_MEDIDA,
                                               NVL (TO_CHAR (PIECES_PER_BOX),
                                                    'N/A')
                                                   AS PIECES_PER_BOX,
                                               NVL (TO_CHAR (COSMETICS_PER_BOX),
                                                    'N/A')
                                                   AS COSMETICS_PER_BOX,
                                               (DECODE (
                                                    PK.PACKAGE_TYPE,
                                                    'H', (PK.WEIGHT / 1000000), --unitarios
                                                    (  (  PT.CURRENT_WEIGHT
                                                        + (SELECT TO_NUMBER (
                                                                      LONG_VALUE)
                                                             FROM PARAMETERS
                                                            WHERE ID = 31))
                                                     / 1000)))
                                                   AS PESO_INDIVIDUAL,
                                               PK.PACKAGE_COST,
                                               DECODE (PK.PACKAGE_TYPE,
                                                       'H', CS.FSC,
                                                       BARCODE)
                                                   AS CODIGO_AVON
                                          FROM DBA_DMS.PACKAGES PK
                                               INNER JOIN
                                               DBA_DMS.SCPI_ORDER_HEADERS OD
                                                   ON OD.ORDER_ID = PK.ORDER_ID
                                               LEFT JOIN ITEMS CS
                                                   ON     PK.ORDER_ID =
                                                          CS.ORDER_ID
                                                      AND CS.PACKAGE_ID =
                                                          PK.PACKAGE_ID
                                               LEFT JOIN
                                               DBA_DMS.PACKAGE_TOTALS PT
                                                   ON (    PT.ORDER_ID =
                                                           PK.ORDER_ID
                                                       AND PT.PACKAGE_ID =
                                                           PK.PACKAGE_ID
                                                       AND PK.PACKAGE_TYPE != 'H')
                                         WHERE     ORDER_NUMBER IS NOT NULL
                                               AND PK.SHORTED IS NULL --- SACA SHORTS
                                               AND OD.FULL_CAMPAIGN =
                                                   V_FULL_CAMPAIGN
                                               AND PK.ORDER_ID NOT IN
                                                       (SELECT S.ORDER_ID
                                                          FROM orders_statuses S
                                                         WHERE S.STATUS = 15) --- DISCRIMINAR ESTATUS = 15 Cancelada
                                      GROUP BY OD.ORDER_ID,
                                               PK.PACKAGE_COST,
                                               CS.TAX_CATEGORY,
                                               PIECES_PER_BOX,
                                               COSMETICS_PER_BOX,
                                               PK.PACKAGE_TYPE,
                                               CS.FSC,
                                               PK.WEIGHT,
                                               PT.CURRENT_WEIGHT,
                                               PK.PACKAGE_TYPE,
                                               CS.DESCRIPTION,
                                               OD.FULL_CAMPAIGN,
                                               OD.ZONE,
                                               OD.ACCOUNT,
                                               DECODE (PK.PACKAGE_TYPE,
                                                       'H', CS.FSC,
                                                       BARCODE)) P
                                     INNER JOIN REPRESENTATIVES R
                                         ON P.ACCOUNT = R.ACCOUNT
                                     INNER JOIN
                                     (  SELECT Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               LDC.LDC_ID,
                                               LDC.LOCATION_NAME
                                          FROM DBA_DMS.ZONE_CAMPAIGNS Z
                                               INNER JOIN DBA_DMS.LDC LDC
                                                   ON LDC.LDC_ID = Z.LDW_CODE
                                         WHERE    Z.CAMPAIGN_YEAR
                                               || LPAD (Z.CAMPAIGN, 2, 0) =
                                               V_FULL_CAMPAIGN ----- CAMBIO DE FULL CAMPAIGN
                                      GROUP BY Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               LDC.LDC_ID,
                                               LDC.LOCATION_NAME) L
                                         ON     L.ZONE = P.ZONE
                                            AND    L.CAMPAIGN_YEAR
                                                || LPAD (L.CAMPAIGN, 2, 0) =
                                                P.FULL_CAMPAIGN ----- CAMBIO DE FULL CAMPAIGN
                              UNION ALL
                              SELECT 0
                                         ORDER_ID,
                                     FULL_CAMPAIGN,
                                     L.LDC_ID
                                         AS LDC,
                                     UPPER (LOCATION_NAME)
                                         AS POBLACION_LDC,
                                     GZ.ZONE
                                         AS ZONA,
                                     R.ROUTE
                                         AS RUTA,
                                     GZ.ACCOUNT,
                                     ACCOUNT_NAME
                                         AS NOMBRE,
                                     R.RFC,
                                     NVL (R.ADDRESS1, '-')
                                         AS CALLE_NUM,
                                     NVL (R.ADDRESS2, '-')
                                         AS COLONIA,
                                     R.ZIP
                                         AS CP,
                                     NVL (R.MUNICIPALITY, '-')
                                         AS MUNICIPIO,
                                     R.STATE_NAME
                                         AS ESTADO,
                                     'MÉXICO'
                                         AS PAIS,
                                     'MEXICANA'
                                         AS NACIONALIDAD,
                                     TO_CHAR (TAX_CATEGORY)
                                         AS CODIGO_SAT,
                                     NVL (FSC, '-')
                                         AS CODIGO_AVON,
                                     PRODUCT_DESC
                                         AS DESCRIPCION,
                                     PIECES
                                         AS CANTIDAD,
                                     'H87'
                                         AS CLAVE_UNIDAD_MEDIDA,
                                     'PZA'
                                         AS UNIDAD_MEDIDA,
                                     'N/A'
                                         AS PIEZAS_CAJA,
                                     'N/A'
                                         AS PIEZAS_COSMETICOS,
                                     0
                                         AS PESO_INDIVIDUAL,
                                     0
                                         AS PESO_TOTAL,
                                     0
                                         AS PRECIO_CATALOGO,
                                     'MX'
                                         AS MONEDA,
                                     0
                                         AS TOTAL,
                                     'MISCELANEO'
                                         AS TIPO_ARTICULO
                                FROM DBA_DMS.MISCELLANEOUS_GZ GZ
                                     INNER JOIN DBA_DMS.REPRESENTATIVES R
                                         ON R.ACCOUNT = GZ.ACCOUNT
                                     INNER JOIN
                                     (  SELECT Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               LDC.LDC_ID,
                                               LDC.LOCATION_NAME,
                                                  Z.CAMPAIGN_YEAR
                                               || LPAD (Z.CAMPAIGN, 2, 0)    AS FULLCAMPAIGN
                                          FROM DBA_DMS.ZONE_CAMPAIGNS Z
                                               INNER JOIN DBA_DMS.LDC LDC
                                                   ON LDC.LDC_ID = Z.LDW_CODE
                                         WHERE    Z.CAMPAIGN_YEAR
                                               || LPAD (Z.CAMPAIGN, 2, 0) =
                                               V_FULL_CAMPAIGN ----- CAMBIO DE FULL CAMPAIGN
                                      GROUP BY Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               LDC.LDC_ID,
                                               LDC.LOCATION_NAME) L
                                         ON     GZ.ZONE = L.ZONE
                                            AND L.FULLCAMPAIGN =
                                                GZ.FULL_CAMPAIGN
                               WHERE     GZ.shipping_type = 1
                                     AND full_campaign = V_FULL_CAMPAIGN
                                     AND GZ.ZONE = V_ZONE        ---- POR ZONA
                                                         ) T
                      WHERE ZONA = V_ZONE                       ---- POR ZONA
                    AND LDC = V_LDC ---- POR PORTEO
                    ORDER BY RUTA, ACCOUNT, CODIGO_AVON ASC;

WHEN 3 -- FULL_CAMPAIGN LDC, ZONE Y RUTA
THEN
 OPEN CUR_REPORT FOR

 SELECT T.*,
                             ROW_NUMBER ()
                                 OVER (ORDER BY T.RUTA, ACCOUNT, CODIGO_AVON)    AS NUM_PAGINADO
                        FROM (SELECT order_id,
                                     P.FULL_CAMPAIGN
                                         AS FULL_CAMPAIGN,
                                    TRIM( L.LDC_ID)
                                         AS LDC,
                                     UPPER (LOCATION_NAME)
                                         AS POBLACION_LDC,
                                     P.ZONE
                                         AS ZONA,
                                     NVL (R.ROUTE, 0)
                                         AS RUTA,
                                     R.ACCOUNT,
                                     R.ACCOUNT_NAME
                                         AS NOMBRE,
                                     R.RFC,
                                     NVL (R.ADDRESS1, '-')
                                         AS CALLE_NUM,
                                     NVL (R.ADDRESS2, '-')
                                         AS COLONIA,
                                     R.ZIP
                                         AS CP,
                                     NVL (R.MUNICIPALITY, '-')
                                         AS MUNICIPIO,
                                     R.STATE_NAME
                                         AS ESTADO,
                                     'MÉXICO'
                                         AS PAIS,
                                     'MEXICANA'
                                         AS NACIONALIDAD,
                                     CASE PACKAGE_TYPE
                                         WHEN 'H'
                                         THEN
                                             DECODE (
                                                 P.TAX_CATEGORY,
                                                 0, (SELECT STRING_VALUE
                                                       FROM dba_dms.parameters
                                                      WHERE id = 30),
                                                 NULL, (SELECT STRING_VALUE
                                                          FROM dba_dms.parameters
                                                         WHERE id = 30),
                                                 P.TAX_CATEGORY)
                                         ELSE
                                             DECODE (
                                                 P.TAX_CATEGORY,
                                                 0, (SELECT STRING_VALUE
                                                       FROM dba_dms.parameters
                                                      WHERE id = 33),
                                                 NULL, (SELECT STRING_VALUE
                                                          FROM dba_dms.parameters
                                                         WHERE id = 33),
                                                 P.TAX_CATEGORY)
                                     END
                                         AS CODIGO_SAT,
                                     CODIGO_AVON,
                                     DESCRIPCION,
                                     NVL (CANTIDAD, 1)
                                         AS CANTIDAD,
                                     'H87'
                                         AS CLAVE_UNIDAD_MEDIDA,
                                     'PZA'
                                         AS UNIDAD_MEDIDA,
                                     PIECES_PER_BOX
                                         AS PIEZAS_CAJA,
                                     COSMETICS_PER_BOX
                                         AS PIEZAS_COSMETICOS,
                                     ROUND (PESO_INDIVIDUAL, 1)
                                         AS PESO_INDIVIDUAL,
                                     ROUND (PESO_INDIVIDUAL * CANTIDAD, 1)
                                         AS PESO_TOTAL,
                                     PACKAGE_COST
                                         AS PRECIO_CATALOGO,
                                     'MX'
                                         AS MONEDA,
                                     (PACKAGE_COST * NVL (CANTIDAD, 1))
                                         AS TOTAL,
                                     'FACTURADO'
                                         AS TIPO_ARTICULO
                                FROM (  SELECT OD.ORDER_ID,
                                               OD.FULL_CAMPAIGN,
                                               OD.ZONE,
                                               OD.ACCOUNT,
                                               TAX_CATEGORY,
                                               PK.WEIGHT,
                                               PT.CURRENT_WEIGHT,
                                               PK.PACKAGE_TYPE,
                                               NVL (CS.DESCRIPTION,
                                                    'CAJA COSMÉTICOS')
                                                   AS DESCRIPCION,
                                               DECODE (COUNT (*),
                                                       0, 1,
                                                       COUNT (*))
                                                   AS CANTIDAD,
                                               'H87'
                                                   AS CLAVE_UNIDAD_MEDIDA,
                                               'PZA'
                                                   AS UNIDAD_MEDIDA,
                                               NVL (TO_CHAR (PIECES_PER_BOX),
                                                    'N/A')
                                                   AS PIECES_PER_BOX,
                                               NVL (TO_CHAR (COSMETICS_PER_BOX),
                                                    'N/A')
                                                   AS COSMETICS_PER_BOX,
                                               (DECODE (
                                                    PK.PACKAGE_TYPE,
                                                    'H', (PK.WEIGHT / 1000000), --unitarios
                                                    (  (  PT.CURRENT_WEIGHT
                                                        + (SELECT TO_NUMBER (
                                                                      LONG_VALUE)
                                                             FROM PARAMETERS
                                                            WHERE ID = 31))
                                                     / 1000)))
                                                   AS PESO_INDIVIDUAL,
                                               PK.PACKAGE_COST,
                                               DECODE (PK.PACKAGE_TYPE,
                                                       'H', CS.FSC,
                                                       BARCODE)
                                                   AS CODIGO_AVON
                                          FROM DBA_DMS.PACKAGES PK
                                               INNER JOIN
                                               DBA_DMS.SCPI_ORDER_HEADERS OD
                                                   ON OD.ORDER_ID = PK.ORDER_ID
                                               LEFT JOIN ITEMS CS
                                                   ON     PK.ORDER_ID =
                                                          CS.ORDER_ID
                                                      AND CS.PACKAGE_ID =
                                                          PK.PACKAGE_ID
                                               LEFT JOIN
                                               DBA_DMS.PACKAGE_TOTALS PT
                                                   ON (    PT.ORDER_ID =
                                                           PK.ORDER_ID
                                                       AND PT.PACKAGE_ID =
                                                           PK.PACKAGE_ID
                                                       AND PK.PACKAGE_TYPE != 'H')
                                         WHERE     ORDER_NUMBER IS NOT NULL
                                               AND PK.SHORTED IS NULL --- SACA SHORTS
                                               AND OD.FULL_CAMPAIGN =
                                                   V_FULL_CAMPAIGN
                                               AND PK.ORDER_ID NOT IN
                                                       (SELECT S.ORDER_ID
                                                          FROM orders_statuses S
                                                         WHERE S.STATUS = 15) --- DISCRIMINAR ESTATUS = 15 Cancelada
                                      GROUP BY OD.ORDER_ID,
                                               PK.PACKAGE_COST,
                                               CS.TAX_CATEGORY,
                                               PIECES_PER_BOX,
                                               COSMETICS_PER_BOX,
                                               PK.PACKAGE_TYPE,
                                               CS.FSC,
                                               PK.WEIGHT,
                                               PT.CURRENT_WEIGHT,
                                               PK.PACKAGE_TYPE,
                                               CS.DESCRIPTION,
                                               OD.FULL_CAMPAIGN,
                                               OD.ZONE,
                                               OD.ACCOUNT,
                                               DECODE (PK.PACKAGE_TYPE,
                                                       'H', CS.FSC,
                                                       BARCODE)) P
                                     INNER JOIN REPRESENTATIVES R
                                         ON P.ACCOUNT = R.ACCOUNT
                                     INNER JOIN
                                     (  SELECT Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               LDC.LDC_ID,
                                               LDC.LOCATION_NAME
                                          FROM DBA_DMS.ZONE_CAMPAIGNS Z
                                               INNER JOIN DBA_DMS.LDC LDC
                                                   ON LDC.LDC_ID = Z.LDW_CODE
                                         WHERE    Z.CAMPAIGN_YEAR
                                               || LPAD (Z.CAMPAIGN, 2, 0) =
                                               V_FULL_CAMPAIGN ----- CAMBIO DE FULL CAMPAIGN
                                      GROUP BY Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               LDC.LDC_ID,
                                               LDC.LOCATION_NAME) L
                                         ON     L.ZONE = P.ZONE
                                            AND    L.CAMPAIGN_YEAR
                                                || LPAD (L.CAMPAIGN, 2, 0) =
                                                P.FULL_CAMPAIGN ----- CAMBIO DE FULL CAMPAIGN
                              UNION ALL
                              SELECT 0
                                         ORDER_ID,
                                     FULL_CAMPAIGN,
                                     L.LDC_ID
                                         AS LDC,
                                     UPPER (LOCATION_NAME)
                                         AS POBLACION_LDC,
                                     GZ.ZONE
                                         AS ZONA,
                                     R.ROUTE
                                         AS RUTA,
                                     GZ.ACCOUNT,
                                     ACCOUNT_NAME
                                         AS NOMBRE,
                                     R.RFC,
                                     NVL (R.ADDRESS1, '-')
                                         AS CALLE_NUM,
                                     NVL (R.ADDRESS2, '-')
                                         AS COLONIA,
                                     R.ZIP
                                         AS CP,
                                     NVL (R.MUNICIPALITY, '-')
                                         AS MUNICIPIO,
                                     R.STATE_NAME
                                         AS ESTADO,
                                     'MÉXICO'
                                         AS PAIS,
                                     'MEXICANA'
                                         AS NACIONALIDAD,
                                     TO_CHAR (TAX_CATEGORY)
                                         AS CODIGO_SAT,
                                     NVL (FSC, '-')
                                         AS CODIGO_AVON,
                                     PRODUCT_DESC
                                         AS DESCRIPCION,
                                     PIECES
                                         AS CANTIDAD,
                                     'H87'
                                         AS CLAVE_UNIDAD_MEDIDA,
                                     'PZA'
                                         AS UNIDAD_MEDIDA,
                                     'N/A'
                                         AS PIEZAS_CAJA,
                                     'N/A'
                                         AS PIEZAS_COSMETICOS,
                                     0
                                         AS PESO_INDIVIDUAL,
                                     0
                                         AS PESO_TOTAL,
                                     0
                                         AS PRECIO_CATALOGO,
                                     'MX'
                                         AS MONEDA,
                                     0
                                         AS TOTAL,
                                     'MISCELANEO'
                                         AS TIPO_ARTICULO
                                FROM DBA_DMS.MISCELLANEOUS_GZ GZ
                                     INNER JOIN DBA_DMS.REPRESENTATIVES R
                                         ON R.ACCOUNT = GZ.ACCOUNT
                                     INNER JOIN
                                     (  SELECT Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               LDC.LDC_ID,
                                               LDC.LOCATION_NAME,
                                                  Z.CAMPAIGN_YEAR
                                               || LPAD (Z.CAMPAIGN, 2, 0)    AS FULLCAMPAIGN
                                          FROM DBA_DMS.ZONE_CAMPAIGNS Z
                                               INNER JOIN DBA_DMS.LDC LDC
                                                   ON LDC.LDC_ID = Z.LDW_CODE
                                         WHERE    Z.CAMPAIGN_YEAR
                                               || LPAD (Z.CAMPAIGN, 2, 0) =
                                               V_FULL_CAMPAIGN ----- CAMBIO DE FULL CAMPAIGN
                                      GROUP BY Z.ZONE,
                                               Z.CAMPAIGN_YEAR,
                                               Z.CAMPAIGN,
                                               LDC.LDC_ID,
                                               LDC.LOCATION_NAME) L
                                         ON     GZ.ZONE = L.ZONE
                                            AND L.FULLCAMPAIGN =
                                                GZ.FULL_CAMPAIGN
                               WHERE     GZ.shipping_type = 1
                                     AND full_campaign = V_FULL_CAMPAIGN
                                     AND GZ.ZONE = V_ZONE        ---- POR ZONA
                                                         ) T
                      WHERE ZONA = V_ZONE                       ---- POR ZONA
                        AND LDC = V_LDC ---PORTEO
                        AND RUTA = V_ROUTE --- RUTA
                    ORDER BY RUTA, ACCOUNT, CODIGO_AVON ASC;

WHEN 4 ---POR ACCOUNT
THEN
 OPEN CUR_REPORT FOR
SELECT T.*,
         ROW_NUMBER () OVER (ORDER BY T.RUTA, ACCOUNT, CODIGO_AVON)
             AS NUM_PAGINADO
    FROM (SELECT order_id,
                 P.FULL_CAMPAIGN
                     AS FULL_CAMPAIGN,
                 L.LDC_ID
                     AS LDC,
                 UPPER (LOCATION_NAME)
                     AS POBLACION_LDC,
                 P.ZONE
                     AS ZONA,
                 NVL (R.ROUTE, 0)
                     AS RUTA,
                 R.ACCOUNT,
                 R.ACCOUNT_NAME
                     AS NOMBRE,
                 R.RFC,
                 NVL (R.ADDRESS1, '-')
                     AS CALLE_NUM,
                 NVL (R.ADDRESS2, '-')
                     AS COLONIA,
                 R.ZIP
                     AS CP,
                 NVL (R.MUNICIPALITY, '-')
                     AS MUNICIPIO,
                 R.STATE_NAME
                     AS ESTADO,
                 'MÉXICO'
                     AS PAIS,
                 'MEXICANA'
                     AS NACIONALIDAD,
                 CASE PACKAGE_TYPE
                     WHEN 'H'
                     THEN
                         DECODE (P.TAX_CATEGORY,
                                 0, (SELECT STRING_VALUE
                                       FROM dba_dms.parameters
                                      WHERE id = 30),
                                 NULL, (SELECT STRING_VALUE
                                          FROM dba_dms.parameters
                                         WHERE id = 30),
                                 P.TAX_CATEGORY)
                     ELSE
                         DECODE (P.TAX_CATEGORY,
                                 0, (SELECT STRING_VALUE
                                       FROM dba_dms.parameters
                                      WHERE id = 33),
                                 NULL, (SELECT STRING_VALUE
                                          FROM dba_dms.parameters
                                         WHERE id = 33),
                                 P.TAX_CATEGORY)
                 END
                     AS CODIGO_SAT,
                 CODIGO_AVON,
                 DESCRIPCION,
                 NVL (CANTIDAD, 1)
                     AS CANTIDAD,
                 'H87'
                     AS CLAVE_UNIDAD_MEDIDA,
                 'PZA'
                     AS UNIDAD_MEDIDA,
                 PIECES_PER_BOX
                     AS PIEZAS_CAJA,
                 COSMETICS_PER_BOX
                     AS PIEZAS_COSMETICOS,
                 ROUND (PESO_INDIVIDUAL, 1)
                     AS PESO_INDIVIDUAL,
                 ROUND (PESO_INDIVIDUAL * CANTIDAD, 1)
                     AS PESO_TOTAL,
                 PACKAGE_COST
                     AS PRECIO_CATALOGO,
                 'MX'
                     AS MONEDA,
                 (PACKAGE_COST * NVL (CANTIDAD, 1))
                     AS TOTAL,
                 'FACTURADO'
                     AS TIPO_ARTICULO
            FROM (  SELECT OD.ORDER_ID,
                           OD.FULL_CAMPAIGN,
                           OD.ZONE,
                           OD.ACCOUNT,
                           TAX_CATEGORY,
                           PK.WEIGHT,
                           PT.CURRENT_WEIGHT,
                           PK.PACKAGE_TYPE,
                           NVL (CS.DESCRIPTION, 'CAJA COSMÉTICOS')
                               AS DESCRIPCION,
                           DECODE (COUNT (*), 0, 1, COUNT (*))
                               AS CANTIDAD,
                           'H87'
                               AS CLAVE_UNIDAD_MEDIDA,
                           'PZA'
                               AS UNIDAD_MEDIDA,
                           NVL (TO_CHAR (PIECES_PER_BOX), 'N/A')
                               AS PIECES_PER_BOX,
                           NVL (TO_CHAR (COSMETICS_PER_BOX), 'N/A')
                               AS COSMETICS_PER_BOX,
                           (DECODE (PK.PACKAGE_TYPE,
                                    'H', (PK.WEIGHT / 1000000),    --unitarios
                                    (  (  PT.CURRENT_WEIGHT
                                        + (SELECT TO_NUMBER (LONG_VALUE)
                                             FROM PARAMETERS
                                            WHERE ID = 31))
                                     / 1000)))
                               AS PESO_INDIVIDUAL,
                           PK.PACKAGE_COST,
                           DECODE (PK.PACKAGE_TYPE, 'H', CS.FSC, BARCODE)
                               AS CODIGO_AVON
                      FROM DBA_DMS.PACKAGES PK
                           INNER JOIN DBA_DMS.SCPI_ORDER_HEADERS OD
                               ON OD.ORDER_ID = PK.ORDER_ID
                           LEFT JOIN ITEMS CS
                               ON     PK.ORDER_ID = CS.ORDER_ID
                                  AND CS.PACKAGE_ID = PK.PACKAGE_ID
                           LEFT JOIN DBA_DMS.PACKAGE_TOTALS PT
                               ON (    PT.ORDER_ID = PK.ORDER_ID
                                   AND PT.PACKAGE_ID = PK.PACKAGE_ID
                                   AND PK.PACKAGE_TYPE != 'H')
                     WHERE     ORDER_NUMBER IS NOT NULL
                           AND PK.SHORTED IS NULL              --- SACA SHORTS
                           AND OD.FULL_CAMPAIGN = V_FULL_CAMPAIGN
                           AND PK.ORDER_ID NOT IN (SELECT S.ORDER_ID
                                                     FROM orders_statuses S
                                                    WHERE S.STATUS = 15) --- DISCRIMINAR ESTATUS = 15 Cancelada
                  GROUP BY OD.ORDER_ID,
                           PK.PACKAGE_COST,
                           CS.TAX_CATEGORY,
                           PIECES_PER_BOX,
                           COSMETICS_PER_BOX,
                           PK.PACKAGE_TYPE,
                           CS.FSC,
                           PK.WEIGHT,
                           PT.CURRENT_WEIGHT,
                           PK.PACKAGE_TYPE,
                           CS.DESCRIPTION,
                           OD.FULL_CAMPAIGN,
                           OD.ZONE,
                           OD.ACCOUNT,
                           DECODE (PK.PACKAGE_TYPE, 'H', CS.FSC, BARCODE)) P
                 INNER JOIN REPRESENTATIVES R ON P.ACCOUNT = R.ACCOUNT
                 INNER JOIN
                 (  SELECT Z.ZONE,
                           Z.CAMPAIGN_YEAR,
                           Z.CAMPAIGN,
                           LDC.LDC_ID,
                           LDC.LOCATION_NAME
                      FROM DBA_DMS.ZONE_CAMPAIGNS Z
                           INNER JOIN DBA_DMS.LDC LDC ON LDC.LDC_ID = Z.LDW_CODE
                     WHERE Z.CAMPAIGN_YEAR || LPAD (Z.CAMPAIGN, 2, 0) =
                           V_FULL_CAMPAIGN      ----- CAMBIO DE FULL CAMPAIGN
                  GROUP BY Z.ZONE,
                           Z.CAMPAIGN_YEAR,
                           Z.CAMPAIGN,
                           LDC.LDC_ID,
                           LDC.LOCATION_NAME) L
                     ON     L.ZONE = P.ZONE
                        AND L.CAMPAIGN_YEAR || LPAD (L.CAMPAIGN, 2, 0) =
                            P.FULL_CAMPAIGN      ----- CAMBIO DE FULL CAMPAIGN
          UNION ALL
          SELECT 0                       ORDER_ID,
                 FULL_CAMPAIGN,
                 L.LDC_ID                AS LDC,
                 UPPER (LOCATION_NAME)   AS POBLACION_LDC,
                 GZ.ZONE                 AS ZONA,
                 R.ROUTE                 AS RUTA,
                 GZ.ACCOUNT,
                 ACCOUNT_NAME            AS NOMBRE,
                 R.RFC,
                 NVL (R.ADDRESS1, '-')   AS CALLE_NUM,
                 NVL (R.ADDRESS2, '-')   AS COLONIA,
                 R.ZIP                   AS CP,
                 NVL (R.MUNICIPALITY, '-') AS MUNICIPIO,
                 R.STATE_NAME            AS ESTADO,
                 'MÉXICO'               AS PAIS,
                 'MEXICANA'              AS NACIONALIDAD,
                 TO_CHAR (TAX_CATEGORY)  AS CODIGO_SAT,
                 NVL (FSC, '-')          AS CODIGO_AVON,
                 PRODUCT_DESC            AS DESCRIPCION,
                 PIECES                  AS CANTIDAD,
                 'H87'                   AS CLAVE_UNIDAD_MEDIDA,
                 'PZA'                   AS UNIDAD_MEDIDA,
                 'N/A'                   AS PIEZAS_CAJA,
                 'N/A'                   AS PIEZAS_COSMETICOS,
                 0                       AS PESO_INDIVIDUAL,
                 0                       AS PESO_TOTAL,
                 0                       AS PRECIO_CATALOGO,
                 'MX'                    AS MONEDA,
                 0                       AS TOTAL,
                 'MISCELANEO'            AS TIPO_ARTICULO
            FROM DBA_DMS.MISCELLANEOUS_GZ GZ
                 INNER JOIN DBA_DMS.REPRESENTATIVES R ON R.ACCOUNT = GZ.ACCOUNT
                 INNER JOIN
                 (  SELECT Z.ZONE,
                           Z.CAMPAIGN_YEAR,
                           Z.CAMPAIGN,
                           LDC.LDC_ID,
                           LDC.LOCATION_NAME,
                           Z.CAMPAIGN_YEAR || LPAD (Z.CAMPAIGN, 2, 0)
                               AS FULLCAMPAIGN
                      FROM DBA_DMS.ZONE_CAMPAIGNS Z
                           INNER JOIN DBA_DMS.LDC LDC ON LDC.LDC_ID = Z.LDW_CODE
                     WHERE Z.CAMPAIGN_YEAR || LPAD (Z.CAMPAIGN, 2, 0) =
                           V_FULL_CAMPAIGN      ----- CAMBIO DE FULL CAMPAIGN
                  GROUP BY Z.ZONE,
                           Z.CAMPAIGN_YEAR,
                           Z.CAMPAIGN,
                           LDC.LDC_ID,
                           LDC.LOCATION_NAME) L
                     ON GZ.ZONE = L.ZONE AND L.FULLCAMPAIGN = GZ.FULL_CAMPAIGN
           WHERE GZ.shipping_type = 1 AND full_campaign = V_FULL_CAMPAIGN
             ) T
   WHERE ACCOUNT = V_ACCOUNT                        --- --- POR REPRESENTANTE

ORDER BY RUTA, ACCOUNT, CODIGO_AVON ASC;

END CASE;

  EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());

      OPEN CUR_REPORT FOR
SELECT NULL ORDER_ID, 
NULL  FULL_CAMPAIGN,
NULL LDC,
NULL POBLACION_LDC, 
NULL ZONA, 
NULL RUTA, 
NULL ACCOUNT, 
NULL NOMBRE, 
NULL RFC, 
NULL CALLE_NUM, 
NULL COLONIA, 
NULL CP, 
NULL MUNICIPIO, 
NULL ESTADO, 
NULL PAIS,
NULL NACIONALIDAD,
NULL CODIGO_SAT,
NULL CODIGO_AVON, 
NULL DESCRIPCION, 
NULL CANTIDAD, 
NULL CLAVE_UNIDAD_MEDIDA, 
NULL UNIDAD_MEDIDA, 
NULL PIEZAS_CAJA, 
NULL PIEZAS_COSMETICOS, 
NULL PESO_INDIVIDUAL, 
NULL PESO_TOTAL, 
NULL PRECIO_CATALOGO, 
NULL MONEDA, 
NULL TOTAL, 
NULL TIPO_ARTICULO
FROM DUAL;

    WHEN OTHERS
    THEN
     OPEN CUR_REPORT FOR
SELECT NULL ORDER_ID, 
NULL  FULL_CAMPAIGN,
NULL LDC,
NULL POBLACION_LDC, 
NULL ZONA, 
NULL RUTA, 
NULL ACCOUNT, 
NULL NOMBRE, 
NULL RFC, 
NULL CALLE_NUM, 
NULL COLONIA, 
NULL CP, 
NULL MUNICIPIO, 
NULL ESTADO, 
NULL PAIS,
NULL NACIONALIDAD,
NULL CODIGO_SAT,
NULL CODIGO_AVON, 
NULL DESCRIPCION, 
NULL CANTIDAD, 
NULL CLAVE_UNIDAD_MEDIDA, 
NULL UNIDAD_MEDIDA, 
NULL PIEZAS_CAJA, 
NULL PIEZAS_COSMETICOS, 
NULL PESO_INDIVIDUAL, 
NULL PESO_TOTAL, 
NULL PRECIO_CATALOGO, 
NULL MONEDA, 
NULL TOTAL, 
NULL TIPO_ARTICULO
FROM DUAL;

        ROLLBACK;
        P_ERROR_CODE := SQLCODE;
        P_ERROR_MESSAGE :=
            CONCAT (CONCAT (SQLERRM, '  '),
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ());
    END SP_SEL_LDC_REPORT;
END PCK_LDC_REPORT;
/

