create TYPE           "STATUS_ORDER_ID_ROW"                                          AS OBJECT 
(
    ORDER_ID NUMBER
)
/

