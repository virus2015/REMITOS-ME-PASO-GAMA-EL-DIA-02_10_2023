create PACKAGE         PCK_DELETE_DATA
    AUTHID CURRENT_USER
AS
    /******************************************************************************
       NAME:       PK_DELETE_DATA
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        30/03/2021      Rossana Reyes      1. Created this package.
       2.0        30/03/2021      Rossana Reyes      1. Add histoc log and historic rebuilding index
    ******************************************************************************/
    FUNCTION FN_ITERATION (PA_OWNER VARCHAR2)
        RETURN NUMBER;

    PROCEDURE SP_BACKUP_DELETE /******************************************************************************
                                  NAME:       SP_BACKUP_DELETE
                                  PURPOSE:    Crear tabla con información de respaldo para su recuperación.
                                  REVISIONS:
                                  Ver        Date        Author           Description
                                  ---------  ----------  ---------------  ------------------------------------
                                  1.0        09/04/2021      Rossana Reyes      1. Created this procedure.
                               ******************************************************************************/
                               (PA_DELETE_DATA_ID   IN     NUMBER, ---DELETING_LOG.DELETE_DATA_ID
                                PA_ITERATION_ID     IN     NUMBER, ---- DELETING_LOG.ITERATION_ID
                                PA_TABLE_NAME       IN     VARCHAR2, ---DELETE_DATA.TABLE_NAME
                                PA_GROUPED_BY       IN     NUMBER, ---DELETE_DATA.GROUPED_BY
                                PA_SQL_DELETE       IN     VARCHAR2, ---DELETE_dATA.EXCECUTE_VARIABLE
                                PA_EXCUTE_VAR       IN     VARCHAR2, ---DELETE_dATA.SQL_DELETE
                                PA_EXECUTION           OUT NUMBER, --  1 - TODO OK, 0 - ALGO SALÍO MAL, 2 - NO HAY DATOS
                                PA_PROCESS             OUT VARCHAR2, -- IMPRIME LOG
                                PA_ROWCOUNT            OUT NUMBER -- IMPRIME CONTEO DE DATOS
                                                                 );

    PROCEDURE SP_DELETE_DATA /******************************************************************************
                                 NAME:       SP_DELETE_DATA
                                 PURPOSE:    Borra datos de tabla en proceso automático de depuración
                                 REVISIONS:
                                 Ver        Date        Author           Description
                                 ---------  ----------  ---------------  ------------------------------------
                                 1.0        12/04/2021      Rossana Reyes      1. Created this procedure.
                              ******************************************************************************/
                             (PA_DELETE_DATA_ID   IN     NUMBER, ---DELETING_LOG.DELETE_DATA_ID
                              PA_ITERATION_ID     IN     NUMBER, ---- DELETING_LOG.ITERATION_ID
                              PA_TABLE_NAME       IN     VARCHAR2, ---DELETE_DATA.TABLE_NAME
                              PA_SQL_DELETE       IN     VARCHAR2, ---DELETE_dATA.EXCECUTE_VARIABLE
                              PA_EXCUTE_VAR       IN     VARCHAR2, ---DELETE_dATA.SQL_DELETE
                              PA_EXECUTION           OUT NUMBER, --  1 - TODO OK, 0 - ALGO SALÍO MAL
                              PA_PROCESS             OUT VARCHAR2 -- IMPRIME LOG
                                                                 );

    PROCEDURE SP_INDEX_TABLE /******************************************************************************
                                NAME:       SP_INDEX_TABLE
                                PURPOSE:    Reconstruye índices tabla en proceso automático de depuración
                                REVISIONS:
                                Ver        Date        Author           Description
                                ---------  ----------  ---------------  ------------------------------------
                                1.0        12/04/2021      Rossana Reyes      1. Created this procedure.
                             ******************************************************************************/
                             (PA_REBUILDINGINDEX_ID   IN     NUMBER, ----DBA_DMS.REBUILDING_INDEXID.REBUILDINGINDEX_ID
                              PA_DELETE_DATA_ID       IN     NUMBER, ---DELETING_LOG.DELETE_DATA_ID
                              PA_ITERATION_ID         IN     NUMBER, ---- DELETING_LOG.ITERATION_ID
                              PA_TABLE_NAME           IN     VARCHAR2, ---DELETE_DATA.TABLE_NAME
                              PA_CONSTRAINT_NAME      IN     VARCHAR2, ---DELETE_DATA.TABLE_NAME
                              PA_EXECUTION               OUT NUMBER, --  1 - TODO OK, 0 - ALGO SALÍO MAL
                              PA_PROCESS                 OUT VARCHAR2 -- IMPRIME LOG
                                                                     );
END PCK_DELETE_DATA;
/

