create PACKAGE BODY         PCK_DELIVERY_WINDOW IS
  /*********************************************************************************
   NAME:    STP_UPD_ROUTES_DELIVERY_DATE
   PURPOSE: UPSERTS DELIVERY_ROUTES TABLE AND RETURNS A TABLE OBJECT WITH ANY ERRORS

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  -----------------------------------------
   1.0        15/04/2021  JUAN C LOZANO     1. Created this Store Procedure.
  *********************************************************************************/
  PROCEDURE STP_UPD_ROUTES_DELIVERY_DATE
  (
    I_INPUT_ROWS DBA_DMS.DELIVERY_ROUTES_UPD_DATE_TBL,
    O_ERROR_FLAG OUT VARCHAR2,
    O_ERROR_MESSAGE OUT VARCHAR2,
    O_ERROR_ROWS OUT DBA_DMS.DELVRY_ROUTES_UPD_DT_ERR_TBL,
    O_ROW_COUNT OUT NUMBER
  ) AS
  BEGIN
    O_ROW_COUNT := 0;
    O_ERROR_FLAG := 'N';

    O_ERROR_ROWS := DBA_DMS.DELVRY_ROUTES_UPD_DT_ERR_TBL();

    -- noinspection SqlWithoutWhere
    DELETE FROM DELIVERY_ROUTES_WORK_TABLE;

    FORALL CURRENT_INDEX IN I_INPUT_ROWS.FIRST .. I_INPUT_ROWS.LAST
      insert into DELIVERY_ROUTES_WORK_TABLE (
        FULL_CAMPAIGN,
        ZONE_ID,
        ROUTE,
        DELIVERY_DATE,
        TRANSFER_FLAG,
        ENABLE_DB
      ) values (
        I_INPUT_ROWS(CURRENT_INDEX).FULL_CAMPAIGN,
        I_INPUT_ROWS(CURRENT_INDEX).ZONE_ID,
        I_INPUT_ROWS(CURRENT_INDEX).ROUTE,
        I_INPUT_ROWS(CURRENT_INDEX).DELIVERY_DATE,
        I_INPUT_ROWS(CURRENT_INDEX).TRANSFER_FLAG,
        1
      );
    commit;
    --caso 1 la fecha mandada esta muy cerca
    update DELIVERY_ROUTES_WORK_TABLE WT set ERROR_MESSAGE = 'Trying to set a date that is too close', IS_WARNING = 1
    where not exists(
      select 1 from ZONE_CAMPAIGNS ZC
      where ZC.ZONE = WT.ZONE_ID and ZC.FULL_CAMPAIGN = WT.FULL_CAMPAIGN
      and current_timestamp at time zone 'America/Mexico_City' between ZC.BILLED_AT-2 and ZC.BILLED_AT
    );
    --caso 2 la zona no existe
    update DELIVERY_ROUTES_WORK_TABLE WT set ERROR_MESSAGE = 'Invalid Zone', IS_WARNING = 0
    where not exists(
      select 1 from ZONE Z
      where Z.ZONE_ID = WT.ZONE_ID
    );
    --caso 3 la campa;a no existe
    update DELIVERY_ROUTES_WORK_TABLE WT set ERROR_MESSAGE = 'Invalid campaign', IS_WARNING = 0
    where not exists(
      select 1 from CAMPAIGNS C
      where (C.CAMPAIGN_YEAR*100+C.CAMPAIGN) = WT.FULL_CAMPAIGN
    );
    --caso 4 falla upsert por transfer_flag invalido
    update DELIVERY_ROUTES_WORK_TABLE set ERROR_MESSAGE = 'Invalid Transfer Flag', IS_WARNING = 0
    where TRANSFER_FLAG = 'T';
    --caso 5 falla upsert por zone_campaign invalido o fechas invalidas
    update DELIVERY_ROUTES_WORK_TABLE WT set ERROR_MESSAGE = 'Does not fit operational calendar', IS_WARNING = 0
    where not exists(
      select 1 from ZONE_CAMPAIGNS ZC
      where ZC.ZONE = WT.ZONE_ID and ZC.FULL_CAMPAIGN = WT.FULL_CAMPAIGN
      and WT.DELIVERY_DATE between ZC.FIRST_ATTEMPT_AT and ZC.LAST_ATTEMPT_AT
    );
    --caso 6 falla insert por llave duplicada en dataset
    update DELIVERY_ROUTES_WORK_TABLE WT set ERROR_MESSAGE = 'Row change requested more than once', IS_WARNING = 0
    where exists(
      select 1 from DELIVERY_ROUTES_WORK_TABLE WT2
      where WT2.ZONE_ID = WT.ZONE_ID and WT2.FULL_CAMPAIGN = WT.FULL_CAMPAIGN and WT2.ROUTE = WT.ROUTE
      group by WT2.ZONE_ID,WT2.FULL_CAMPAIGN, WT2.ROUTE having count(*) > 1
    );
    --caso 7 la fecha mandada ya paso
    update DELIVERY_ROUTES_WORK_TABLE WT set ERROR_MESSAGE = 'Trying to set a date that has already happened', IS_WARNING = 0
    where DELIVERY_DATE < current_timestamp at time zone 'America/Mexico_City';
    COMMIT;
    -- INSERT WHERE NOT EXISTS
    insert INTO DELIVERY_ROUTES(
      DELIVERY_ID,
      FULL_CAMPAIGN,
      ZONE_ID,
      ROUTE,
      DELIVERY_DATE,
      TRANSFER_FLAG,
      ENABLE_DB
    )
    SELECT DBA_DMS.DELIVERY_R_SEQ.nextval,
           DRWT.FULL_CAMPAIGN,
           DRWT.ZONE_ID,
           DRWT.ROUTE,
           DRWT.DELIVERY_DATE,
           DRWT.TRANSFER_FLAG,
           DRWT.ENABLE_DB
    FROM DELIVERY_ROUTES_WORK_TABLE DRWT
    LEFT JOIN DELIVERY_ROUTES DR ON
      DR.FULL_CAMPAIGN = DRWT.FULL_CAMPAIGN AND DR.ZONE_ID = DRWT.ZONE_ID
    AND DR.ROUTE = DRWT.ROUTE
    WHERE DR.FULL_CAMPAIGN IS NULL AND DR.ZONE_ID IS NULL
    AND DR.ROUTE IS NULL AND (ERROR_MESSAGE IS NULL OR DRWT.IS_WARNING = 1);

    UPDATE DELIVERY_ROUTES DR SET (
      FULL_CAMPAIGN,
      ZONE_ID,
      ROUTE,
      DELIVERY_DATE,
      TRANSFER_FLAG,
      ENABLE_DB
    ) = (
      SELECT
        FULL_CAMPAIGN,
        ZONE_ID,
        ROUTE,
        DELIVERY_DATE,
        TRANSFER_FLAG,
        ENABLE_DB
      FROM DELIVERY_ROUTES_WORK_TABLE DRWT1
      WHERE DR.FULL_CAMPAIGN = DRWT1.FULL_CAMPAIGN AND DR.ZONE_ID = DRWT1.ZONE_ID
      AND DR.ROUTE = DRWT1.ROUTE AND (ERROR_MESSAGE IS NULL OR DRWT1.IS_WARNING = 1)
    )
    WHERE EXISTS(
      SELECT 1
      FROM DELIVERY_ROUTES_WORK_TABLE DRWT2
      WHERE DR.FULL_CAMPAIGN = DRWT2.FULL_CAMPAIGN AND DR.ZONE_ID = DRWT2.ZONE_ID
      AND DR.ROUTE = DRWT2.ROUTE AND (DRWT2.ERROR_MESSAGE IS NULL OR DRWT2.IS_WARNING = 1)
    );
    O_ROW_COUNT := SQL%ROWCOUNT;
    COMMIT;

    DELETE FROM DELIVERY_ROUTES_WORK_TABLE WHERE ERROR_MESSAGE IS NULL;
    COMMIT;

    SELECT
      DELVRY_ROUTES_UPD_DT_ERR_ROW(FULL_CAMPAIGN,
      ZONE_ID,
      ROUTE,
      DELIVERY_DATE,
      TRANSFER_FLAG,
      IS_WARNING,
      ERROR_MESSAGE)
    bulk collect into O_ERROR_ROWS
    FROM DELIVERY_ROUTES_WORK_TABLE;

    -- noinspection SqlWithoutWhere
    DELETE FROM DELIVERY_ROUTES_WORK_TABLE;
    COMMIT;

    EXCEPTION
    WHEN OTHERS THEN
       ROLLBACK;
       O_ERROR_FLAG := 'S';
       O_ERROR_MESSAGE := 'Received ' || I_INPUT_ROWS.COUNT || ' Rows and Updated '
                    || O_ROW_COUNT || ' rows.';
       DBA_DMS.PCK_DBA_LOG.INS_DBA_LOG(
         'PCK_DELIVERY_WINDOW.STP_UPD_ROUTES_DELIVERY_DATE',
         'Received ' || I_INPUT_ROWS.COUNT || ' Rows and Updated '
                    || O_ROW_COUNT || ' rows.',
         SQLCODE,
         SQLERRM
       );

  END STP_UPD_ROUTES_DELIVERY_DATE;
END PCK_DELIVERY_WINDOW;
/

