create PACKAGE         PKG_REPRES_NO_PAGO
AS
  
   /* PRC Consulta Repres que Facturaron y deben campaña previa  */
   PROCEDURE SP_REPRES_FACTURO (
      pi_zona         IN     NUMBER,
      po_cod             OUT VARCHAR2,
      po_msg             OUT VARCHAR2,
      repreFactura      OUT SYS_REFCURSOR);
      


END PKG_REPRES_NO_PAGO;
/

