create trigger TRG_PCK_STATUSES
    before insert or update
    on PACKAGE_STATUSES
    for each row
    when (new.status in (31))
BEGIN
    update PACKAGES set TRANSFER_FLAG = (
                      CASE WHEN ( TRANSFER_FLAG = 'F') THEN
                        'F'
                      ELSE
                        'E'
                      END), updated_at = current_timestamp where PACKAGE_ID = :new.PACKAGE_ID and ORDER_ID = :new.ORDER_ID;
END;
/

