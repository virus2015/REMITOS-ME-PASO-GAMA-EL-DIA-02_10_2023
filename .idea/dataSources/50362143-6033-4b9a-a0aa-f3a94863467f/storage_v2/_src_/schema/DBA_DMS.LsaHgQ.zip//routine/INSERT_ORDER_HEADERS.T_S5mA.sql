create procedure Insert_order_headers(var_zone in ORDER_HEADER.zone%Type,
                                                 var_campaign in ORDER_HEADER.campaign%type)
                                                 is
                                                       
   BEGIN
   
    for mi_for in ( select * FROM DBA_SCPI.ORDER_HEADER@SCPIP zz
  where zz.id_order in (
   select ww.order_id from orders ww
   where ww.order_id in (
   SELECT oh.id_order
  FROM DBA_SCPI.ORDER_HEADER@SCPIP OH  
  JOIN DBA_SCPI.CARTON@SCPIP CAR
  ON OH.ID_ORDER = CAR.ID_ORDER
  JOIN DBA_SCPI.PRODUCT@SCPIP PRD
  ON CAR.ID_CARTON = PRD.ID_CARTON    
 WHERE OH.PROCESS_STATUS = 11 
   AND OH.ORDER_STATUS = 2
   AND OH.ZONE IN(var_zone)
   AND OH.CAMPAIGN = var_campaign)))loop
    
   insert into ORDER_HEADER(id_order)values(mi_for.id_order);
   
    end loop;
   
    END Insert_order_headers;
/

