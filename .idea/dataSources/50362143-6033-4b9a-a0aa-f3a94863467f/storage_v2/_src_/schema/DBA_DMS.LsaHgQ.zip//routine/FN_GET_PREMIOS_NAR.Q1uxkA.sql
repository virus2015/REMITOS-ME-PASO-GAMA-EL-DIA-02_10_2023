create FUNCTION         FN_GET_PREMIOS_NAR (
   PI_ORDERID    IN NUMBER,
   PI_CAMPAIGN   IN NUMBER)
   RETURN VARCHAR2
AS
   premios   VARCHAR2 (3);
   vcount    NUMBER;
   vOrderId NUMBER(10) := PI_ORDERID;
   vCampaign NUMBER(6) := PI_CAMPAIGN;

   
BEGIN
   SELECT COUNT (1)
     INTO vcount
     FROM PACKAGES PK, ITEMS IT, ITEM_DATA DI
    WHERE     PK.ORDER_ID = IT.ORDER_ID
          AND PK.PACKAGE_ID = IT.PACKAGE_ID
          AND IT.FSC = DI.FSC
          AND IT.ORDER_ID = vOrderId
          AND TO_CHAR (DI.YEAR || LPAD (DI.CAMPAIGN, 2, 0)) = vCampaign 
          AND PK.PACKAGE_TYPE = 'H'
          AND DI.OFFER_CODE IN ('J', 'I', 'S')
          AND DI.HANDL_TAG IN ('E', 'H');


   IF vcount >= 1
   THEN
      premios := 'T';
   ELSE
      premios := 'F';
   END IF;


   RETURN premios;
END;
/

